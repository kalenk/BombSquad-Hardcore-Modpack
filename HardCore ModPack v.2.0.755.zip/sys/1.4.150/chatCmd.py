﻿# -*- coding: utf-8 -*-
import bs
import bsInternal
import bsPowerup
import bsUtils
import bsSpaz
import bsGame
from bsSpaz import *
import bsUI
import random
import skins
import bsMainMenu, bsTutorial

bsUtils._havePro = bsUtils._haveProOptions = lambda : True

gSettingsEnabled = (hasattr(bs, "get_setting") and hasattr(bs, "set_setting"))

maps={"Doom Shroom":(0.82, 1.10, 1.15), "Hockey Stadium":(1.2,1.3,1.33), \
    "Football Stadium":(1.3, 1.2, 1.0), "Big G":(1.1, 1.2, 1.3), \
    "Roundabout":(1.0, 1.05, 1.1), "Monkey Face":(1.1, 1.2, 1.2), \
    "Bridgit":(1.1, 1.2, 1.3), "Zigzag":(1.0, 1.15, 1.15), \
    "The Pad":(1.1, 1.1, 1.0), "Lake Frigid":(1, 1, 1), \
    "Tip Top":(0.8, 0.9, 1.3), "Crag Castle":(1.15, 1.05, 0.75), \
    "Tower D":(1.15, 1.11, 1.03), "Happy Thoughts":(1.3, 1.23, 1.0), \
    "Step Right Up":(1.2, 1.1, 1.0), "Courtyard":(1.2, 1.17, 1.1), \
    "Rampage":(1.2, 1.1, 0.97)}

if gSettingsEnabled:
    admins, vips, banned, prefixes = bs.get_setting("admins", []), bs.get_setting("vips", []), bs.get_setting("banned", []), bs.get_setting("prefixes", {})
else: 
    admins, vips, banned, prefixes = [], [], [], {}

motion_normal, map_tint, tint_normal = None, None, None

def get_normal_tint():
    global map_tint
    a=bsInternal._getForegroundHostActivity()
    if a is not None:
        if isinstance(a, bsMainMenu.MainMenuActivity): name = "The Pad"
        elif isinstance(a, bsTutorial.TutorialActivity): name = "Rampage"
        else: name = a.getMap().name if hasattr(a, "getMap") else None
        if name is not None and name in maps: map_tint = maps[name]
        else: 
            raise ValueError("Invalid map name: "+name)
    return map_tint

def get_motion():
    global motion_normal
    a=bsInternal._getForegroundHostActivity()
    if a is not None and hasattr(a, "settings"): return bool(a.settings.get("Epic Mode", False)) if motion_normal is None else bool(motion_normal)
    return bool(motion)

def get_tint():
    global tint_normal
    if tint_normal is None: tint_normal = get_normal_tint()
    return tint_normal

def set_tint(tint):
    if tint is None or (isinstance(tint, tuple) and len(tint) == 3): 
        global tint_normal
        tint_normal = tint
    else:
        raise ValueError()

def set_motion(motion):
    if motion is None or isinstance(motion, bool):
        global motion_normal
        motion_normal = motion
    else:
        raise ValueError()

def send_message(msg):
    if len(bsInternal._getGameRoster()) < 1:
        if bsUI.gPartyWindow is not None and bsUI.gPartyWindow() is not None:
            with bs.Context("UI"): bsUI.gPartyWindow()._addMsg(msg=msg, color=(1, 1, 1))
    else: bsInternal._chatMessage(msg)

def is_num(num="0"):
    try:
        int(num)
        return True
    except ValueError:
        return False

def is_account(account, return_account=False):
    def check(account):
        if isinstance(account, unicode):
            for icon in ['googlePlusLogo', 'gameCenterLogo', 'gameCircleLogo', \
                'ouyaLogo', 'localAccount', 'alibabaLogo', \
                'oculusLogo', 'nvidiaLogo']:
                if bs.getSpecialChar(icon) in account: return True
        return False
    if isinstance(account, str):
        try: account = account.decode("utf-8")
        except UnicodeEncodeError: account = unicode(account)
    result = check(account=account)
    if return_account: return account if result else None
    else: return result

def get_account_string(arg):
    a = bsInternal._getForegroundHostActivity()
    if arg is not None:
        account = is_account(arg, True)
        if account is not None: return arg
        if a is not None and is_num(arg) and len(a.players) > int(arg): arg = a.players[int(arg)] 
        if isinstance(arg, bs.Player) and arg.exists(): return arg.getInputDevice()._getAccountName(True)
    return None

def dayCycle():
    if bsInternal._getForegroundHostActivity() is not None:
        tint = get_tint()
        anim={0: tint, 7500:(1.25, 1.21, 1.075),
            30000: (1.25, 1.21, 1.075), 57500: (1.1, 0.86, 0.74),
            67500: (1.1, 0.86, 0.74), 90000: (0, 0.27, 0.51),
            120000: (0, 0.27, 0.51), 142500: (1.3, 1.06, 1.02),
            157500: (1.3, 1.06, 1.02), 180000: (1.3, 1.25, 1.2),
            195500: (1.3, 1.25, 1.2), 220000: tint}
        bsUtils.animateArray(bs.getSharedObject("globals"), "tint", 3, anim, loop=True)

class ChatOptions(object):
    def __init__(self):
        self.is_vip = False
        self.is_admin = False
        self.is_host = False
        self._bots = None
        self.time={"normal":None, "sunrise": (1.3, 1.06, 1.02), "day": (1.3, 1.25, 1.2), "noon": (1.25, 1.21, 1.075), "sunset": (1.1, 0.86, 0.74), "night":(0, 0.27, 0.51)}

    def add_admin(self, admin=False, account=None):
        global admins
        global vips
        if account is not None:
            if admin and account not in admins:
                admins.append(account)
                if gSettingsEnabled: bs.set_setting("admins", admins)
            if not admin and account not in vips:
                vips.append(account)
                if gSettingsEnabled: bs.set_setting("vips", vips)

    def ban(self, account=None):
        if account is not None and account not in banned:
            banned.append(account)
            if gSettingsEnabled: bs.set_setting("banned", banned)
            self.update()

    def set_prefix(self, account=None, prefix='', type='spark'):
        global prefixes
        if account is not None and type in ['slime', 'ice', 'metal', 'rock', 'spark']:
            prefixes.update({account: {type: prefix}})
            if gSettingsEnabled: bs.set_setting("prefixes", prefixes)

    def update(self):
        if bsInternal._getForegroundHostActivity() is not None:
            for i in bsInternal._getGameRoster():
                account = i['displayString'].decode("utf-8")
                id = i['clientID']
                if bs.getSpecialChar('localAccount') in account and (("PC" not in account) and ("Mac" not in account) and ("Linux" not in account) and ("Android" not in account)): banned.append(account)
                if len(banned) > 0 and account in banned: bsInternal._disconnectClient(id, banTime=1800)
            
    def check_player(self, clientID=None):
        global admins
        self.player = None
        self.is_vip, self.is_admin, self.is_host = False, False, False
        host = is_account(bsInternal._getAccountDisplayString(True), True)
        if host not in admins: 
            admins.append(host)
            if gSettingsEnabled: bs.set_setting("admins", admins)
        a, roster = bsInternal._getForegroundHostActivity(), bsInternal._getGameRoster()
        if len(roster) > 0:
            account = {}
            if clientID is not None: account = {i["displayString"].decode("utf-8"): i["clientID"] for i in roster if i["clientID"] == clientID}
            if len(account) > 0:
                clientID = account.values()[0]
                account = account.keys()[0]
                if account in vips: self.is_vip=True
                if account in admins: self.is_vip, self.is_admin = True, True
                if account == host: self.is_host=True
                self.player = [d for d in a.players if d.exists() and d.getInputDevice().getClientID() == clientID]
                self.player = self.player[0] if len(self.player) > 0 else None
        else:
            self.is_admin=True
            self.is_vip=True
            self.is_host=True
            self.player = a.players[0] if len(a.players) > 0 else None

    def get_player_position(self, arg):
        if self.player is not None and self.player.exists() and self.player.isAlive():
            if ('~' in arg) or ('^' in arg):
                for i in range(3):
                    if arg[2+i] in ["~", "^"]: arg[2+i] = self.player.actor.node.position[i]
        return arg

    def opt(self, clientID=None, msg=" "):
        self.check_player(clientID=clientID)
        msg=msg.replace("/", "")
        arg=[i if is_account(i) else i.lower() for i in msg.split(" ")[1:]] if len(msg.split(" ")) > 1 else []
        command=msg.split(" ")[0].lower()
        a=bsInternal._getForegroundHostActivity()
        if a is not None:
            with bs.Context(a):
                arg=self.get_player_position(arg=arg)
                if command in ["h", "help"] and self.is_vip:
                    for i in ["list - список игроков", "summon - призвать объекты", "timeset - установить время", \
                        "skin - установить скин", "punch - сила удара", "hitpoints - очки жизни", \
                        "kick - кикнуть", "ban - забанить", "admin - выдать права админа", \
                        "vip - выдать права vip-пользователя", "end - закончить игру", "sm - замедленный режим игры", \
                        "mp - установить кол-во игроков", "rise - возродить", \
                        "/cmd - пример отправки команды"]: send_message(i)

                elif command in ["l", "list"] and self.is_vip:
                    if len(bsInternal._getGameRoster()) > 0:
                        players, roster = [], bsInternal._getGameRoster()
                        for i in [[c["id"] for c in k["players"]] for k in bsInternal._getGameRoster()]:
                            for d in i: players.append(d)
                        players.sort()
                        for i in roster:
                            data = [(", ").join([r["nameFull"] for r in i["players"]]) if len(i["players"]) > 0 else " - ", (", ").join([str(players.index(r)) for r in [c["id"] for c in i["players"]]]) if len(i["players"]) > 0 else " - "]
                            bsInternal._chatMessage(i["displayString"] + " : "+ data[0] + " : " + data[1])
                    else:
                        pl = a.players
                        if len(pl) > 0:
                            bsInternal._chatMessage(((", ").join([i.getInputDevice().getPlayer().getName(True) for i in pl]) + " : " + (", ").join([str(r) for r in range(len(pl))])))
                        else: send_message(" - ")

                elif command in ['timeset', 'time'] and self.is_vip:
                    if len(arg) > 0:
                        tint = get_tint()
                        self.time.update({"normal": get_normal_tint()})
                        for i in self.time:
                            if arg[0] == i:
                                tint = self.time[i]
                                bs.getSharedObject("globals").tint = self.time[i]
                        if arg[0] == 'cycle':
                            tint = get_normal_tint()
                            bs.getSharedObject('globals').tint = tint
                        set_tint(tint=tint)
                    else:
                        bsInternal._chatMessage('time [normal|sunrise|day|noon|sunset|night|cycle]')
                        bsInternal._chatMessage('timeset cycle - дневной цикл(плавная смена времени)')
                        bsInternal._chatMessage('timeset noon - середина дня')
                        bsInternal._chatMessage('timeset sunset - закат')
    
                elif command in ['summon','s'] and self.is_admin:
                    if len(arg) > 0:
                        if arg[0] in ['bomb','b']:
                            bombs = ['ice', 'impact', 'landMine', 'normal', 'sticky', 'tnt', 'firework', 'killLaKill', 'qq', 'tp', 'poison', 'ball', 'dirt']
                            if len(arg) > 1:
                                spawn={"bombType":"normal", "pos":[0,5,0], "count":1}
                                for i in range(len(spawn)):
                                    if len(arg) > i+1:
                                        name=spawn.keys()[i]
                                        if name == "bombType": spawn.update({name:arg[i+1]})
                                        elif name == "count":
                                            if len(arg) > i+4:
                                                if is_num(arg[i+4]):
                                                    if int(arg[i+4]) > 0: spawn.update({name:int(arg[i+4])})
                                        else:
                                            for k in range(3):
                                                if len(arg) > i+k:
                                                    if is_num(arg[i+k]): spawn["pos"][k] = float(arg[i+k])
                                if spawn["bombType"] in bombs:
                                    for i in range(spawn["count"]):
                                        if i < 31:
                                            if self.player is not None and self.player.exists(): bs.Bomb(position=tuple(spawn["pos"]), bombType=spawn["bombType"], owner=self.player.actor.node).autoRetain()
                                            else: bs.Bomb(position=tuple(spawn["pos"]), bombType=spawn["bombType"]).autoRetain()
                            else:
                                for i in range(int(len(bombs) / 4)):
                                    bmstring = ""
                                    for r in range(4):
                                        if len(bombs) + 1 > (i*4+r): bmstring += (", "+bombs[i*4+r]) if r > 0 else bombs[i*4+r]
                                    send_message(bmstring)
                                send_message("s bomb [название] [позиция(3 числа)] [кол-во]")
                                send_message("s bomb normal 0 5 0 1")
                        elif arg[0] in ['bot']:
                            import inspect
                            bots=[i for i in dir(bsSpaz) if inspect.isclass(eval("bsSpaz."+i)) and issubclass(eval("bsSpaz."+i), bsSpaz.SpazBot)]
                            if len(arg) > 1:
                                spawn = {"botType": "BomberBot", "pos": [0, 5, 0], "count": 1}
                                for i in range(len(spawn)):
                                    name=spawn.keys()[i]
                                    if name == "botType":
                                        if len(arg) > 1:
                                            if not (arg[i+1]+" ").isspace(): spawn.update({name:arg[i+1]})
                                    elif name == "count":
                                        if len(arg) > i+4:
                                            if is_num(arg[i+4]):
                                                if int(arg[i+4]) > 0: spawn.update({name:int(arg[i+4])})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k:
                                                if is_num(arg[i+k]): spawn["pos"][k] = float(arg[i+k])
                                bot=eval([("bsSpaz."+i) for i in bots if i.lower() == spawn["botType"]][0] if len([i for i in bots if i.lower() == spawn["botType"]]) > 0 else "bsSpaz.BomberBot")
                                self._bots = bs.BotSet() if not hasattr(self, '_bots') or self._bots is None else self._bots
                                for i in range(spawn["count"]):
                                    if i < 31: self._bots.spawnBot(bot, pos=tuple(spawn["pos"]), spawnTime=1, onSpawnCall=self._on_spawn)
                            else:
                                for i in range(int(len(bots) / 4)):
                                    skstring = ""
                                    for r in range(4):
                                        if len(bots) + 1 > (i*4+r): skstring += (", "+bots[i*4+r]) if r > 0 else bots[i*4+r]
                                    send_message(skstring)
                                send_message("s bot [название] [позиция(3 числа)] [кол-во]")
                                send_message("s bot BomberBot 0 5 0 1")
                        elif arg[0] in ['flag','f']:
                            if len(arg) > 1:
                                spawn = {"time_out":20, "color":[1,1,0], "pos":[0, 5, 0], "count":1}
                                for i in range(len(spawn)):
                                    name=spawn.keys()[i]
                                    if name == "color":
                                        for k in range(3):
                                            if len(arg) > i+k+6:
                                                if is_num(arg[i+k+6]): spawn["color"][k] = float(arg[i+k+6])
                                    elif name == "count":
                                        if len(arg) > i+3:
                                            if is_num(arg[i+3]):
                                                if int(arg[i+3]) > 0: spawn.update({name:int(arg[i+3])})
                                    elif name == "time_out":
                                        if len(arg) > i+3:
                                            if is_num(arg[i+3]):
                                                if int(arg[i+3]) > 0: spawn.update({name:int(arg[i+3])})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k-2:
                                                if is_num(arg[i+k-2]): spawn["pos"][k] = float(arg[i+k-2])
                                for i in range(spawn["count"]):
                                    if i < 31: bs.Flag(position=tuple(spawn["pos"]), droppedTimeout=spawn["time_out"], color=spawn["color"]).autoRetain()
                            else:
                                send_message("s flag [название] [позиция(3 числа)] [кол-во]")
                                send_message("s bot BomberBot 0 5 0 1")
                                send_message("s bot [название] [позиция(3 числа)] [кол-во]")
                        elif arg[0] in ['powerup','p']:
                            powerups=[i[0] for i in list(bsPowerup.getDefaultPowerupDistribution(True))]
                            if len(arg) > 1:
                                spawn = {"powerupType": "punch", "pos": [0, 5, 0], "count": 1}
                                for i in range(len(spawn)):
                                    name = spawn.keys()[i]
                                    if name == "powerupType":
                                        if len(arg) > i-1:
                                            if not (arg[i-1] + " ").isspace() and arg[i-1] in [k.lower() for k in powerups]:
                                                spawn.update({name: [l for l in powerups if arg[i-1] == l.lower()][0]})
                                    elif name == "count":
                                        if len(arg) > i+5:
                                            if is_num(arg[i+5]):
                                                if int(arg[i+5]) > 0: spawn.update({name: int(arg[i+5])})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k+1:
                                                if is_num(arg[i+k+1]): spawn["pos"][k] = float(arg[i+k+1])
                                for i in range(spawn["count"]):
                                    if i < 31: bs.Powerup(position=tuple(spawn["pos"]),powerupType=spawn["powerupType"]).autoRetain()
                            else:
                                for i in range(int(len(powerups) / 4)):
                                    skstring = ""
                                    for r in range(4):
                                        if len(powerups) + 1 > (i*4+r): skstring += (", "+powerups[i*4+r]) if r > 0 else powerups[i*4+r]
                                    send_message(skstring)
                                send_message("s p [название] [позиция(3 числа)] [кол-во]")
                        elif arg[0] in ['box']:
                            if len(arg) > 1:
                                spawn = {"boxType": "small", "pos": [0, 5, 0], "count": 1}
                                for i in range(len(spawn)):
                                    name = spawn.keys()[i]
                                    if name == "boxType":
                                        if len(arg) > i and arg[i] in ["big", "b"]: spawn.update({name: arg[i]})
                                    elif name == "count":
                                        if len(arg) > i+5 and is_num(arg[i+5]) and int(arg[i+5]) > 0: spawn.update({name: int(arg[i+5])})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k and is_num(arg[i+k]): 
                                                spawn["pos"][k] = float(arg[i+k])
                                for i in range(spawn["count"]):
                                    if i < 31: Box(pos=tuple(spawn["pos"]), scale=1 if spawn["boxType"] in ["s","small"] else 1.38, owner=None).autoRetain()
                            else:
                                send_message("s box [small|big] [позиция] [кол-во] [номер игрока]")
                    else:
                        for i in ["summon [bomb|powerup|bot|box|flag]", "bomb - вызвать бомбу.", "powerup - вызвать усилитель.", "bot - вызвать бота.", "box - вызвать коробку."]: send_message(i)

                elif command in ['skin'] and self.is_vip:
                    skin_names = [skins.get_format_skin_name(i) for i in bsSpaz.appearances.keys()]+["tnt", "shard", "invincible"]
                    if len(arg) > 0:
                        if len(arg) < 2: arg.append(self.player)
                        if arg[0] in skin_names:
                            if isinstance(arg[1], bs.Player): skins.change_skin(skin=arg[0], players=[arg[1]])
                            elif isinstance(arg[1], str):
                                if arg[1] == "all": skins.change_skin(skin=arg[0], players=[i for i in bsInternal._getForegroundHostActivity().players if i.exists()])
                                elif arg[1].isdigit(): skins.change_skin(skin=arg[0], players=[int(arg[1])])
                                elif is_account(arg[1]): skins.change_skin(skin=arg[0], players=[arg[1]])
                        elif arg[0] == "delete":
                            if isinstance(arg[1], bs.Player): skins.delete_skin(arg[1])
                            elif isinstance(arg[1], str):
                                if arg[1] == "all":
                                    if len(bsInternal._getForegroundHostActivity().players) > 0:
                                        for i in bsInternal._getForegroundHostActivity().players: skins.delete_skin(i)
                                elif arg[1].isdigit(): skins.delete_skin(int(arg[1]))
                                elif is_account(arg[1]): skins.delete_skin(arg[1])
                    else:
                        for i in range(int(len(skin_names)/4)):
                            skstring=""
                            for r in range(4):
                                if len(skin_names)+1 > (i*4+r): skstring+=(", "+skin_names[i*4+r]) if r > 0 else skin_names[i*4+r]
                            send_message(skstring)
                        send_message("skin [название] [номер игрока]")
                        send_message("skin bunny 0")
                        send_message("skin pixie")

                elif command in ['ph','punch','hp','hitpoints'] and self.is_admin:
                    if len(arg) > 0:
                        player = None
                        if len(a.players) > 0:
                            if len(arg) < 2: player = [self.player]
                            else:
                                if arg[1].isdigit():
                                    player = [a.players[int(arg[1])]] if len(a.players) > int(arg[1]) else None
                                elif arg[1] == "all":
                                    player = a.players
                            if player is not None:
                                if arg[0].isdigit():
                                    arg[0] = int(arg[0])
                                    if command in ["punch", "ph"]:
                                        if arg[0] > 10: arg[0] = 10
                                    else:
                                        if arg[0] < 1: arg[0] = 1
                                    for i in player:
                                        if i.exists and i.isAlive:
                                            if command in ["punch", "ph"]: i.actor._punchPowerScale = arg[0]
                                            else: i.actor.hitPointsMax, i.actor.hitPoints = arg[0], arg[0]
                    else:
                        if command in ["ph", "punch"]:
                            send_message("punch [сила удара] [номер игрока|all]")
                            send_message("punch 10 0")
                        else:
                            send_message("hitpoints [очки жизни] [номер игрока|all]")
                            send_message("hitpoints 10000 0")
    
                elif command in ['admin','vip'] and self.is_admin:
                    if len(arg) > 0:
                        account = get_account_string(arg[0])
                        if account is not None:
                            self.add_admin(True if command == "admin" else False, account)
                    else:
                        send_message("admin|vip [номер игрока|имя аккаунта]")
                        send_message("vip 0")
                        send_message(u"admin \ue030PC123456")

                elif command in ['prefix'] and self.is_admin:
                    global prefixes
                    if len(arg) > 0:
                        if arg[0] == "delete":
                            if len(arg) > 1: account = get_account_string(arg[1])
                            else: account = get_account_string(self.player)
                            if account is not None and account in prefixes:
                                prefixes.pop(account)
                                if gSettingsEnabled: bs.set_setting("prefixes", prefixes)
                        else:
                            type = arg[1] if len(arg) > 1 else "spark"
                            prefix = "prefix" if len(arg) < 3 else (" ").join(msg.split(" ")[3:])
                            account = get_account_string(arg[0])
                            self.set_prefix(account=account, prefix=prefix, type=type)
                    else:
                        send_message("prefix [номер игрока] [slime|ice|spark|rock|metal] [префикс]")
                        send_message("prefix 0 spark клоун сбежал")

                elif command in ['kick'] and self.is_vip:
                    if len(arg) > 0:
                        account = get_account_string(arg[0])
                        id = None
                        if account is not None:
                            for i in bsInternal._getGameRoster():
                                if i["displayString"].decode("utf-8") == account:
                                    id = i["clientID"]
                                    break
                        if id is not None:
                            bsInternal._disconnectClient(id, 300)
                    else:
                        send_message("kick [номер игрока|имя аккаунта]")
                        send_message("kick 0")
                        send_message(u"kick \ue030PC123456")
    
                elif command in ['ban'] and self.is_admin:
                    if len(arg) > 0:
                        account = get_account_string(arg[0])
                        if account is not None:
                            self.ban(account=account)
                    else:
                        send_message("ban [номер игрока|имя аккаунта]")
                        send_message("ban 0")
                        send_message(u"ban \ue030PC123456")
                    
                elif command in ['end'] and self.is_vip:
                    if hasattr(a, "endGame"): a.endGame()

                elif command in ['sm'] and self.is_vip:
                    bs.getSharedObject("globals").slowMotion = motion = bs.getSharedObject("globals").slowMotion == False
                    set_motion(motion=motion)

                elif command in ['max_players', 'mp'] and self.is_admin:
                    if len(arg) > 0 and is_num(arg[0]) and int(arg[0]) > 0: bsInternal._setPublicPartyMaxSize(int(arg[0]))
                    else:
                        for i in ["mp [кол-во игроков]", "mp 8", "максимальное кол-во игроков сейчас: "+str(bsInternal._getPublicPartyMaxSize())]: send_message(i)

                elif command in ['rise', 'rs'] and self.is_vip:
                    def respawn(player=None):
                        if player is not None and player.exists() and not player.isAlive():
                            player.gameData['respawnTimer'], player.gameData['respawnIcon'] = None, None
                            with bs.Context(a): a.spawnPlayer(player=player)
                    if len(arg) > 0 and is_num(arg[0]) and int(arg[0]) < len(a.players): respawn(a.players[int(arg[0])])
                    elif len(arg) > 0 and arg[0] == "all":
                        for i in a.players: respawn(i)
                    elif self.player is not None: respawn(self.player)
                    else:
                        for i in ["rise [номер игрока|all]", "rise 0", "rise"]: send_message(i)
                        
    def _on_spawn(self, bot):
        bot.targetPointDefault = bs.Vector(0,0,0)

c = ChatOptions()
def cmd(msg="", clientID=None):
    c.opt(msg=msg, clientID=clientID)

def update():
    c.update()

class Box(bs.Actor):
    def __init__(self, pos=(0, 5, 0), scale=1.35, owner=None):
        self.owner = owner
        bs.Actor.__init__(self)
        box_material = bs.Material()
        box_material.addActions(
            conditions=((('weAreYoungerThan', 0),'or',('theyAreYoungerThan', 0)),
            'and', ('theyHaveMaterial', bs.getSharedObject('objectMaterial'))),
            actions=(('modifyNodeCollision', 'collide', True)))
        box_material.addActions(conditions=('theyHaveMaterial',
            bs.getSharedObject('pickupMaterial')),
            actions=(('modifyPartCollision', 'useNodeCollide', False)))
        box_material.addActions(actions=('modifyPartCollision','friction', 1000))
        self.node = bs.newNode('prop', delegate=self, attrs={
            'position': pos,
            'velocity': (0, 0, 0),
            'model': bs.getModel('tnt'),
            'modelScale': scale,
            'body': 'crate',
            'bodyScale': scale,
            'shadowSize': 0.26 * scale,
            'colorTexture': bs.getTexture(random.choice(["flagColor", "frameInset"])),
            'reflection': 'soft',
            'reflectionScale': [0.23],
            'materials': (bs.getSharedObject('footingMaterial'), bs.getSharedObject('objectMaterial'))})

    def getFactory(cls):
        return None

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if isinstance(msg, bs.PickedUpMessage):
            if self.owner is None:
                self.owner=msg.node
                self.node.handleMessage(ConnectToPlayerMessage(msg.node))
            else:
                self.owner=None
                self.node.connectAttr('position', self.node, 'position')
        elif isinstance(msg, ConnectToPlayerMessage):
            if msg.player is not None:
                if msg.player.exists():
                    self.owner=msg.player
                    self.owner.connectAttr('position', self.node, 'position')
        elif isinstance(msg, bs.OutOfBoundsMessage): self.node.delete()
        elif isinstance(msg, bs.DieMessage): self.node.delete()
        elif isinstance(msg, bs.HitMessage):
            self.node.handleMessage("impulse", msg.pos[0], msg.pos[1], msg.pos[2], msg.velocity[0], msg.velocity[1],
                msg.velocity[2], msg.magnitude * 0.2, msg.velocityMagnitude, msg.radius, 0,
                msg.forceDirection[0], msg.forceDirection[1], msg.forceDirection[2])
        else: bs.Actor.handleMessage(self, msg)

class ConnectToPlayerMessage(object):
    def __init__(self, player):
        self.player=player

# -*- coding: utf-8 -*-

completeText = 'Выполнено!'
nowYouCanEnterTheGameText = ', теперь ты можешь войти в игру.'
banAndKickDisabledText = 'В игре находится только хост, бан и кик были временно отключёны.'
banAndKickEnabledText = 'Система бана и кика активна.'
yourNicknameIsBannedOnThisServerText = ', ты забанен на этом сервере.'
yourAccountIsBannedOnThisServerText = ', твой никнейм забанен на этом сервере.'
connectTryText = 'Попытка подключения...'
connectAgainText = 'Подключение отменено. Попытайся снова.'
theseCommndsDisabledInCoopText = 'Такая команда запрещена в ко-оп режиме игры!'
HOW TO INSTALL THIS MODPACK:

1)You need to extract ALL files from archive to BombSquad User Scripts Folder
(to find out these directory, click on "Show Mods Folder" (Settings > Advanced))
2)Then you need to give access to memory to BombSquad-app
3)Start BombSquad
4)Install complete
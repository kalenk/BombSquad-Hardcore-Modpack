# -*- coding: utf-8 -*-
import bs
import bsUI
import bsInternal

# writed by drov.drov

gPopupWindowColor = (0.45, 0.4, 0.55)

commands = ['/kick','/ban','/frozen','/flex', \
    '/dance','/dance2','/admin','/vip','/df','/rise','/curse']

commands_account_needed = ['/kick','/ban','/admin','/vip','/df']

def get_number(clientID):
    roster, activity = bsInternal._getGameRoster(), bsInternal._getForegroundHostActivity()
    choices = []
    if len(roster) > 0:
        players_ids = []
        my_ids = [i['players'] for i in roster if i['clientID'] == clientID]
        my_ids = [i['id'] for i in my_ids[0]] if len(my_ids) > 0 else None
        dt = [[c["id"] for c in i["players"]] for i in roster]
        for i in dt:
            for d in i:
                players_ids.append(d)
        players_ids.sort()
        if len(my_ids) > 0: choices = [players_ids.index(i) for i in my_ids]    
    return choices

def get_account(clientID):
    roster, activity = bsInternal._getGameRoster(), bsInternal._getForegroundHostActivity()
    account = None
    if len(roster) > 0:
        for i in roster: 
            if i['clientID'] == clientID: 
                account = i['displayString'].decode('utf-8')
                break
    elif hasattr(activity, 'players') and len(activity.players) > 0:
        for i in activity.players:
            if hasattr(i, 'getInputDevice') and i.getInputDevice().getClientID() == clientID:
                account = i.getInputDevice()._getAccountName(True)
                break
    return account

def popupWindow(choices=[], pos=(0,0), delegate=None):
    return bsUI.PopupMenuWindow(position=pos,
        scale=2.3 if bsUI.gSmallUI else 1.65 if bsUI.gMedUI else 1.23,
        choices=choices,
        choicesDisplay=[bs.Lstr(value=i) for i in choices],
        currentChoice=None,
        color=gPopupWindowColor,
        delegate=delegate)

def _onPartyMemberPress(self, clientID, isHost, widget):
    if bsInternal._getForegroundHostSession() is not None: choicesDisplay = [bs.Lstr(resource='kickText')] 
    else:
        if bsInternal._getConnectionToHostInfo().get('buildNumber', 0) < 14248: return
        choicesDisplay = [bs.Lstr(resource='kickVoteText')]
    choices = ['kick'] + commands
    for i in commands: choicesDisplay.append(bs.Lstr(value=i))
    self.popupMenuPosition = widget.getScreenSpaceCenter()
    bsUI.PopupMenuWindow(position=self.popupMenuPosition,
                    scale=2.3 if bsUI.gSmallUI else 1.65 if bsUI.gMedUI else 1.23,
                    choices=choices,
                    choicesDisplay=choicesDisplay,
                    currentChoice=None,
                    color=gPopupWindowColor,
                    delegate=self)
    self._popupType = 'commands'
    self._popupPartyMemberClientID = clientID
    self._popupPartyMemberIsHost = isHost

popupMenuOld = bsUI.PartyWindow.popupMenuSelectedChoice

def popupMenuSelectedChoice(self, popupWindow, choice):
    cmd = self._popupType == 'commands'
    if cmd and choice == 'kick': 
        self._popupType = 'partyMemberPress'
        popupMenuOld(self, popupWindow=popupWindow, choice=choice)
    elif cmd:
        if choice in commands_account_needed:
            account = get_account(self._popupPartyMemberClientID)
            if account is not None: bs.textWidget(edit=self._textField, text=choice+' '+account)
        elif choice in commands: 
            result = get_number(self._popupPartyMemberClientID)
            if len(result) > 0:
                self._popupType = 'number'
                bs.textWidget(edit=self._textField, text=choice)
                if len(result) > 1: popupWindow(choices=result, pos=self.popupMenuPosition, delegate=self)
                else: choice = str(result[0])
            else: bs.textWidget(edit=self._textField, text='')
    if self._popupType == 'number': bs.textWidget(edit=self._textField, text=(bs.textWidget(query=self._textField)+' '+choice))
    else: popupMenuOld(self, popupWindow=popupWindow, choice=choice)

bsUI.PartyWindow.popupMenuSelectedChoice = popupMenuSelectedChoice
bsUI.PartyWindow._onPartyMemberPress = _onPartyMemberPress

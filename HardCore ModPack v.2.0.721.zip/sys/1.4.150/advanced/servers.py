import bs
import bsInternal

def connectToParty(address=None):
    bsInternal._log(str(address))
    return True

#bsInternal._connectToParty = connectToParty
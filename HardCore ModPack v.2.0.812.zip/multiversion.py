# -*- coding: utf-8 -*-
import bs
import shutil, os
import time
import bsMainMenu
import bsInternal
import json
import sys

env = bs.getEnvironment()
gSettingsEnabled = (hasattr(bs, "get_setting") and hasattr(bs, "set_setting"))
gAndroid = env['platform'] == 'android'

path = (os.path.sep).join([env['userScriptsDirectory'], 'hardcore', '.data'])
if gAndroid: gInstallPath = '/data/data/net.froemling.bombsquad/files/bombsquad_files/data/scripts'
else: gInstallPath = (os.path.sep).join([env['userScriptsDirectory'], 'sys', str(env["version"])])

installedVersion = 0
installingVersion = 20812
interval = sys.getcheckinterval()

try: from bs import Settings, _gData, force_save
except Exception:
    _gData={"admins":[], "vips":[], "prefixes":{}, "banned": [], \
        "skins": {}, "lobby_connect_menu": False, "show_game_name": True, \
        "admins_prefix": True, "timer_the_disappearance_of_the_effect": True, \
        "powerup_lighting": True, "timer_the_disappearance_of_the_powerup": True, \
        "timer_before_the_bomb_explode": True, "chat_commands_enabled": True, \
        "standart_powerups": False, "auto-update": False, "internet_tab_search_text":"", \
        "in_menu_author_name": True, "party_search_log": False, "powerups": []}
    force_save=["admins", "vips", "banned", "prefixes", "powerups", "skins"]
    class Settings(object):
        def __init__(self, path=None):
            self.path = path if path is not None and os.path.exists(path) else env['configFilePath']
            self.closed = False
            self.load()
            self.mtime = os.path.getmtime(self.path)
        def load(self):
            if not self.closed:
                if not os.path.exists(self.path): raise Exception("Settings file path is not exists; cann\'t update settings data")
                m_time = os.path.getmtime(self.path)
                if hasattr(self, "mtime") and m_time == self.mtime: return
                start_time = time.time()
                try: self.data = json.load(open(self.path))
                except Exception as E:
                    self.data = _gData
                    print("Error loading settings json-file: "+str(E))
                print("loaded in "+str(time.time() - start_time))
            else: raise Exception("Settings were closed")
        def save(self, values=[]):
            if not self.closed:
                start_time = time.time()
                self.load()
                for i in values: self.data.update(i)
                try: json.dump(self.data, open(self.path, "w+"), indent=4, sort_keys=True)
                except Exception as E: print(str(E))
                self.mtime = os.path.getmtime(self.path)
                print("saved in "+str(time.time()-start_time))
                return self.data
            else: raise Exception("Settings were closed")
        def get_setting(self, name="test", default_value=None):
            if not self.closed:
                self.load()
                return self.data.get(name, default_value)
            else: raise Exception("Settings were closed")
        def set_setting(self, name="test", value=True):
            if not self.closed:
                if not hasattr(self, "call"): values = [{name: value}]
                else:
                    values = self.call[0]
                    values.append({name: value})
                if name not in force_save: self.call = [values, bs.Timer(750, bs.Call(self.save, values), timeType="real")]
                else: self.save(values=[{name: value}])
            else: raise Exception("Settings were closed")
        def get_settings(self):
            if not self.closed: return self.data
            else: raise Exception("Settings were closed")
        def close(self):
            if self.closed: return
            if hasattr(self, "data"): del self.data
            if hasattr(self, "path"): del self.path
        def is_closed(self):
            return self.closed
            
temp_path = os.path.join(env['userScriptsDirectory'], 'settings.json')
if not gSettingsEnabled: st = Settings(path=temp_path)

def get_version():
    global installedVersion
    if gSettingsEnabled: installedVersion = bs.get_setting("installed_version", 0)
    else: installedVersion = st.get_setting("installed_version", 0)
    return installedVersion
    
def set_version(version=0):
    global installedVersion
    if gSettingsEnabled: bs.set_setting("installed_version", version)
    else: st.save(values=[{"installed_version": version}])
    installedVersion = version
    
installedVersion = get_version()

try:
    installedText = {"Russian": "Успешно установлено за {} {}", \
        "English": "Successfully installed in {} {}"}
        
    installedText = installedText.get(bs.getLanguage(), installedText.get("English", ""))
except: installedText = "Successfully installed in {} {}"

try:
    waitText = {"Russian": "Пожалуйста, подождите...", \
        "English": "Please, wait..."}
        
    waitText = waitText.get(bs.getLanguage(), waitText.get("English", ""))
except: waitText = "Please, wait..."

try:
    thanksForInstallingText = {"Russian": "Спасибо за установку!", \
        "English": "Thanks for installing!"}
        
    thanksForInstallingText = thanksForInstallingText.get(bs.getLanguage(), \
        thanksForInstallingText.get("English", ""))
except: waitText = "Thanks for installing!"

if bs.getLanguage() == 'Russian':
    def get_article(num=0):
        num = int(str(num)[-1])
        if num == 0 or num in range(5, 10): return "секунд"
        elif num == 1: return "секунду"
        elif num in range(2, 5): return "секунды" 
else: get_article = lambda num : "seconds"

messages = {}
message_num = 0

def add_message(msg='', color=(0,1,0)):
    global messages
    global message_num
    messages.update({message_num: {msg: color}})
    message_num += 1

def messages_sendall(msg=''):
    global messages
    global message_num
    for i in range(message_num): bs.realTimer(100*i, bs.Call(bs.screenMessage, messages[i].keys()[0], messages[i].values()[0]))
    messages = {}
    message_num = 0

def run():
    global timer
    timer = None
    start_time = time.time()
    if not os.path.exists(path): 
        add_message("folder does not exists: .data", color=(1,0,0))
    else:
        if os.path.exists(gInstallPath):
            if (len(os.listdir(gInstallPath)) < 1) or installedVersion < installingVersion: 
                try: shutil.rmtree(gInstallPath)
                except Exception as E: add_message(str(E), color=(1,0,0))
        if not os.path.exists(gInstallPath) and installedVersion < installingVersion:
            def copy(path = None):
                if path is not None and os.path.exists(path):
                    sys.setcheckinterval(100)
                    if gAndroid:
                        temp_path = (os.path.sep).join(gInstallPath.split(os.path.sep)[0:-1]+['scripts_temp'])
                        if os.path.exists(temp_path): 
                            try: shutil.rmtree(temp_path)
                            except Exception as E: add_message(str(E), color=(1,0,0))
                        if not os.path.exists(temp_path):
                            try: shutil.copytree(path, temp_path)
                            except Exception as E: add_message(str(E), color=(1,0,0))
                            try: shutil.move(temp_path, gInstallPath)
                            except Exception as E: add_message(str(E), color=(1,0,0))
                            if os.path.exists(temp_path): 
                                try: shutil.rmtree(temp_path)
                                except Exception as E: add_message(str(E), color=(1,0,0))
                    else:
                        try: shutil.copytree(path, gInstallPath)
                        except: pass
                    sys.setcheckinterval(interval)
                else: add_message("An error in copying files", color=(1,0,0))
            copy(path=path)
            end_time = int(time.time()-start_time)
            try: set_version(installingVersion)
            except Exception as E: add_message(str(E))
            add_message(installedText.format(str(end_time), get_article(end_time)), color=(0,1,0))
            add_message(thanksForInstallingText, color=(0,1,0))
            add_message(bs.Lstr(resource='settingsWindowAdvanced.mustRestartText'), color=(1, 1, 0))
            if not gSettingsEnabled: st.close()
    if 'android' in env['userAgentString'] and hasattr(bs, 'androidRefreshFiles'): bs.androidRefreshFiles()
    bsInternal._addCleanFrameCallback(bs.Call(messages_sendall))
        
def run_with_fade():
    def work():
        bsInternal._fadeScreen(True, 1000, endCall=bs.Call(run))
    if installingVersion > installedVersion: 
        bs.screenMessage(waitText, color=(1, 1, 0))
        bs.realTimer(500, bs.Call(work))
      
timer = None  
def main():
    global timer
    b = bsInternal._getForegroundHostActivity()
    if b is not None: 
        if not bsInternal._havePermission("storage"):
            timer = bs.realTimer(2500, bs.Call(main))
            bs.playSound(bs.getSound('error'))
            bs.screenMessage(bs.Lstr(resource='storagePermissionAccessText'), color=(1, 0, 0))
            bsInternal._requestPermission("storage")
        else: timer = bs.realTimer(2500, bs.Call(run_with_fade))
    else: timer = bs.realTimer(500, bs.Call(main))

try: version_int = int(env['version'].replace(".", ""))
except ValueError: version_int = 14150
if version_int in range(14150, 15000): main()
from bsAchievement import *
import bsAchievement
import bsCoopGame
from bsCoopGame import *
import bs
import bsGame

class DieMessage(object):
    def __init__(self, immediate=False, how="generic"):
        self.immediate = immediate
        self.how = how
        import bsInternal
        if isinstance(bsInternal._getForegroundHostActivity().getSession(), bs.CoopSession):
            for i in gAchievements:
                with bs.Context("current"):
                    try:
                        bsInternal._getForegroundHostActivity()._awardAchievement(i._name, False)
                    except: pass

bsGame.DieMessage = DieMessage
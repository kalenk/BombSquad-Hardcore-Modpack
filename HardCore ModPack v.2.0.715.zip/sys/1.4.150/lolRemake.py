import bs
import bsInternal
import random

class NewLol(object):
    def __init__(self):
        self.texNewBox = bs.getTexture('tnt')
        self.modelNewBox = bs.getModel('tnt')
        self.newBoxMaterial = bs.Material()
        self.newBoxMaterial.addActions(
            conditions=((('weAreYoungerThan',100),
                         'or',('theyAreYoungerThan',100)),
                        'and',('theyHaveMaterial',
                               bs.getSharedObject('objectMaterial'))),
            actions=(('modifyNodeCollision','collide',False)))
        self.newBoxMaterial.addActions(
            conditions=('theyHaveMaterial',
                        bs.getSharedObject('pickupMaterial')),
            actions=(('modifyPartCollision','useNodeCollide', False)))        
        self.newBoxMaterial.addActions(actions=('modifyPartCollision',
                                              'friction', 0.3))
        
class NewBoxPickedUpMessage(object):
    def __init__(self, newBox, node):      
        self.newBox = newBox
        self.node = node

class NewBoxDroppedMessage(object):
    def __init__(self, newBox, node):        
        self.newBox = newBox
        self.node = node

class NewBoxDeathMessage(object):
    def __init__(self, newBox):       
        self.newBox = newBox

class NewBox(bs.Actor):
    def __init__(self, position=(0, 5, 0), gravity = (0,0,0), scale = 1.35, always = False):       
        bs.Actor.__init__(self)
        factory = self.getFactory()

        self.scale = scale
        self.gravity = gravity
        self.pos = position
        self.damage = 0
        self.respawn = always
        self.node = bs.newNode('prop', delegate=self, attrs={
                'position':self.pos,
                'velocity':(0,2,0),
                'extraAcceleration':self.gravity,
                'model':factory.modelNewBox,
                'modelScale':self.scale, 
                'body':'crate',
                'bodyScale':self.scale,
                'shadowSize':0.5*self.scale,
                'colorTexture':factory.texNewBox,
                'reflection':'soft',
                'reflectionScale':[0.23*self.scale],
                'materials':(factory.newBoxMaterial, bs.getSharedObject('footingMaterial'), bs.getSharedObject('objectMaterial'))})

    def getFactory(cls):
        activity = bs.getActivity()
        try:
            return activity._sharedNewLol
        except Exception:
            f = activity._sharedNewLol = NewLol()
            return f #press F to pay respects

    def respawnBox(self, pos):
        if self.scale <= 1.0: NewBox(position = pos, scale = 1, always = True).autoRetain()
        else: NewBox(position = pos, scale = 1.35, always = True).autoRetain()

    def boxBroken(self, pos, vel, mag):
        bs.emitBGDynamics(position=pos, velocity=(vel[0]*mag/200, vel[1]*mag/200, vel[2]*mag/200), count=int(2.1+random.random()*(mag/100)), scale=0.54, spread=0.12, chunkType='splinter');
        if self.damage >= 1000:
            bs.emitBGDynamics(position=pos, velocity=vel, count=int(3.2+random.random()*1.4), scale=0.8, spread=0.3, chunkType='splinter');
            if random.random()>=0.98:
                for i in range(int(self.damage/1000+random.random())):
                    randomType = bs.Powerup.getFactory().getRandomPowerupType()
                    bs.Powerup(position=self.node.position, powerupType=randomType).autoRetain()
            elif (random.random()<0.8) and (random.random()>0.2): 
                bs.emitBGDynamics(position=pos, velocity=(2,1.4,2), count=int(100*(mag/100-random.random())), scale=0.52, spread=0.64, chunkType='spark');
            else: bs.Blast(position=self.node.position, velocity=(0,0,0), blastType="normal", blastRadius=0.5, hitType="explosion", hitSubType="normal")
            self.node.delete()

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()

        if isinstance(msg, bs.DieMessage):
            self.node.delete()
        elif isinstance(msg, bs.HitMessage):
            self.node.handleMessage("impulse", msg.pos[0], msg.pos[1], msg.pos[2], msg.velocity[0], msg.velocity[1], msg.velocity[2], msg.magnitude, msg.velocityMagnitude, msg.radius, 0, msg.forceDirection[0], msg.forceDirection[1], msg.forceDirection[2])
            self.damage += msg.magnitude
            self.boxBroken(msg.pos, msg.velocity, msg.magnitude)
        elif isinstance(msg, bs.OutOfBoundsMessage):
            self.handleMessage(bs.DieMessage(how='fall'))
        elif isinstance(msg, bs.PickedUpMessage):          
            a = self.getActivity()
            if a is not None: a.handleMessage(NewBoxPickedUpMessage(self, msg.node))
        elif isinstance(msg, bs.DroppedMessage):           
            a = self.getActivity()
            if a is not None: a.handleMessage(NewBoxDroppedMessage(self, msg.node))
        else:
            bs.Actor.handleMessage(self, msg)
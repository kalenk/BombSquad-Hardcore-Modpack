import bs
import bsInternal
import random
#For chatCmd /summon box

class Box(bs.Actor):

    def __init__(self, pos=(0,5,0), scale = 1.35, owner = None):

        activity = bs.getActivity()
        factory = self.getFactory()

        self.pos = pos
        self.scale = scale
        self.owner = owner
        self.connect = False
        if self.owner is not None:
            self.connect = True
        self.lastOwner = None
        if self.lastOwner is None:
            self.lastOwner = self.owner

        bs.Actor.__init__(self)

        self.node = bs.newNode('prop', delegate=self, attrs={
                'position':self.pos,
                'velocity':(0,0,0),
                'model':factory.modelBox,
                'modelScale':self.scale, 
                'body':'crate',
                'bodyScale':self.scale,
                'shadowSize':0.36*self.scale,
                'colorTexture':factory.texBox,
                'reflection':'soft',
                'reflectionScale':[0.23],
                'materials':(factory.boxMaterial, bs.getSharedObject('footingMaterial'), bs.getSharedObject('objectMaterial'))})  
        if self.connect: self.checkMessage()
        
    def getFactory(cls):
        activity = bs.getActivity()
        try:
            return activity._sharedLol
        except Exception:
            f = activity._sharedLol = Lol()
            return f

    def checkMessage(self):
        try: self.owner.connectAttr('position', self.node, 'position')
        except: self.lastOwner.connectAttr('position', self.node, 'position')

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()     
        if isinstance(msg, bs.PickedUpMessage):
            if self.connect:
                self.lastOwner = msg.node
                self.owner = msg.node
                self.checkMessage()
        elif isinstance(msg, bs.DroppedMessage):
            if self.connect:
                self.node.delete()
        elif isinstance(msg, bs.OutOfBoundsMessage):
            self.node.delete()
        elif isinstance(msg, bs.HitMessage):
            self.node.handleMessage("impulse", msg.pos[0], msg.pos[1], msg.pos[2], msg.velocity[0], msg.velocity[1], msg.velocity[2], msg.magnitude*0.2, msg.velocityMagnitude, msg.radius, 0, msg.forceDirection[0], msg.forceDirection[1], msg.forceDirection[2])
        else:
            bs.Actor.handleMessage(self, msg)

class Lol(object):
    def __init__(self):
        if random.random() < 0.25:
            self.texBox = bs.getTexture('eggTex1')
        elif random.random() > 0.4:
            self.texBox = bs.getTexture('eggTex2')
        else:
            self.texBox = bs.getTexture('eggTex3')
        self.modelBox = bs.getModel('tnt')
        self.boxMaterial = bs.Material()
        self.boxMaterial.addActions(
            conditions=((('weAreYoungerThan',0),
                         'or',('theyAreYoungerThan',0)),
                        'and',('theyHaveMaterial',
                               bs.getSharedObject('objectMaterial'))),
            actions=(('modifyNodeCollision','collide',True)))
        self.boxMaterial.addActions(
            conditions=('theyHaveMaterial',
                        bs.getSharedObject('pickupMaterial')),
            actions=(('modifyPartCollision','useNodeCollide', False)))        
        self.boxMaterial.addActions(actions=('modifyPartCollision',
                                              'friction', 1000))
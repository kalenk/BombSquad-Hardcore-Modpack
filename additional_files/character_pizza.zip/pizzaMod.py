# -*- coding: utf-8 -*-
import bs
import shutil, os
import bsInternal
import bsSpaz

version = 18

# writed by drov.drov

env = bs.getEnvironment()
gAndroid = env['platform'] == 'android'
gPath = 'data' if not gAndroid else '/data/data/net.froemling.bombsquad/files/bombsquad_files/data'

character = 'Pitsa'
pitsaDir = os.path.join(env['userScriptsDirectory'], 'Pitsa')
file_types = {'.ktx' if gAndroid else '.dds': 'textures', '.bob': 'models', '.ogg': 'audio'}

translates = {
    "Russian": {
        "installStartedText": "Установка персонажа \"{}\"",
        "copyingText": "Копирование файла {}",
        "installCompleteText": "Установка завершена!"},
    "English": {
        "installStartedText": "Installing character \"{}\"",
        "copyingText": "Copying file {}",
        "installCompleteText": "Install complete!"}
    }

time_skip = 200 # time rate while copying 
translates = translates.get(bs.getLanguage(), translates.get("English", {}))

def run(call=None):
    a = bsInternal._getForegroundHostActivity()
    if call is None: call = lambda x : True
    if a is not None: bs.realTimer(time_skip, bs.Call(call))
    else: bs.realTimer(time_skip, bs.Call(run, call))

def install():
    path = os.path.join(gPath, 'pitsaMod.data')
    v = 0
    if os.path.exists(path):
        with open(path, 'r') as f:
            v = f.read()
            f.close()
        try: v = int(v.replace('.', ''))
        except ValueError: v = 0
    if v < version: copyfiles()
    else: add_character()

def copyfiles():
    bs.screenMessage(translates.get("installStartedText", "installing character \"{}\"").format(character), color=(1,0.85,0))
    def copy(dst, src):
        filename = dst.split(os.path.sep)[-1]
        filepath = os.path.join(src, filename)
        if os.path.exists(filepath): os.remove(filepath)
        bs.screenMessage(translates.get("copyingText", "copying... {}").format(filename), color=(1, 1, 0))
        try: shutil.copy(dst, src)
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
    if os.path.exists(pitsaDir) and os.path.isdir(pitsaDir):
        dirs = os.listdir(pitsaDir)
        try:
            for dir in dirs:
                path = os.path.join(pitsaDir, dir)
                if os.path.isdir(path):
                    files = os.listdir(path)
                    for i in range(len(files)):
                        type = None
                        filename = files[i]
                        for p in file_types:
                            if filename.endswith(p): type = file_types[p]
                        if type is not None: 
                            bs.realTimer(time_skip * i + time_skip, bs.Call(copy, os.path.join(path, filename), os.path.join(gPath, type)))
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
        else:
            with open(os.path.join(gPath, 'pitsaMod.data'), 'w+') as f:
                f.write(str(version))
                f.close()
            def end():
                add_character()
                bs.screenMessage(translates.get("installCompleteText", "install complete!").format(character), color=(1,0.85,0))
            bs.realTimer(time_skip * len(files) + time_skip, bs.Call(end))
    else: bs.screenMessage("Can not find path: "+str(pitsaDir), color=(1,0,0))

spazfactorygetmediaold = bsSpaz.SpazFactory._getMedia

def _getMedia(self, character):
    if character == 'Pitsa': 
        t = bsSpaz.appearances[character]
        if not self.spazMedia.has_key(character):
            m = self.spazMedia[character] = {
                'jumpSounds': [bs.getSound(i) for i in t.jumpSounds] if t.jumpSounds is not None else [],
                'attackSounds': [bs.getSound(i) for i in t.attackSounds] if t.attackSounds is not None else [],
                'impactSounds': [bs.getSound(i) for i in t.impactSounds] if t.impactSounds is not None else [],
                'deathSounds': [bs.getSound(i) for i in t.deathSounds] if t.deathSounds is not None else [],
                'pickupSounds': [bs.getSound(i) for i in t.pickupSounds] if t.pickupSounds is not None else [],
                'fallSounds': [bs.getSound(i) for i in t.fallSounds] if t.fallSounds is not None else [],
                'colorTexture': bs.getTexture(t.colorTexture) if t.colorTexture != '' else None,
                'colorMaskTexture':bs.getTexture(t.colorMaskTexture) if t.colorMaskTexture != '' else None,
                'headModel': bs.getModel(t.headModel) if t.headModel != '' else None,
                'torsoModel': bs.getModel(t.torsoModel) if t.torsoModel != '' else None,
                'pelvisModel': bs.getModel(t.pelvisModel) if t.pelvisModel != '' else None,
                'upperArmModel': bs.getModel(t.upperArmModel) if t.upperArmModel != '' else None,
                'foreArmModel': bs.getModel(t.foreArmModel) if t.foreArmModel != '' else None,
                'handModel': bs.getModel(t.handModel) if t.handModel != '' else None,
                'upperLegModel': bs.getModel(t.upperLegModel) if t.upperLegModel != '' else None,
                'lowerLegModel': bs.getModel(t.lowerLegModel) if t.lowerLegModel != '' else None,
                'toesModel': bs.getModel(t.toesModel) if t.toesModel != '' else None
            }
        else: m = self.spazMedia[character]
        return m
    else:
        return spazfactorygetmediaold(self, character)

bsSpaz.SpazFactory._getMedia = _getMedia

def add_character():
    from bsSpaz import Appearance
    t = Appearance(character)
    t.colorTexture = character+"Color"
    t.colorMaskTexture = character+"ColorMask"
    t.headModel = ''
    t.defaultColor = (0.6, 0.6, 0.6)
    t.defaultHighlight = (0, 1, 0)
    t.torsoModel = character+"Torso"
    t.upperArmModel = character+"UpperArm"
    t.foreArmModel = character+"ForeArm"
    t.handModel = character+"Hand"
    t.upperLegModel = character+"UpperLeg"
    t.lowerLegModel = character+"LowerLeg"
    t.toesModel = character+"Toes"
    t.iconTexture = character+"Icon"
    t.iconMaskTexture = character+"IconMask"
    t.style = 'bones'
    t.deathSounds = [character+"Death"]
    t.fallSounds = [character+"Fall"]
    t.attackSounds = [character+"Hit"+str(i+1) for i in range(2)]
    t.jumpSounds = t.pickupSounds = t.impactSounds = [character+str(i+1) for i in range(4)]

run(install)
    
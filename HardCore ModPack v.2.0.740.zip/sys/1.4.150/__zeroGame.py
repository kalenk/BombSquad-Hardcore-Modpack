import bs
import random
import bsUtils
import bsInternal
from bsSpaz import SpazBot
import time

class ZeroBossHitMessage(object):
    def __init__(self, type, subType, player, damage):
        self.type = type
        self.subType = subType
        self.player = player
        self.damage = damage

class ZeroBossDeathMessage(object):
    def __init__(self, badGuy, killerPlayer, how):
        self.badGuy = badGuy
        self.killerPlayer = killerPlayer
        self.how = how

class ZeroBoss(SpazBot):
    color=(0.5, 0.5, 2.5)
    highlight=(-0.5, -0.5, -2.5)
    character = 'Snake Shadow'
    defaultBombType = 'poison'
    punchiness = 0.4
    throwiness = 0.35
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 4
    throwDistMax = 9999
    pointsMult = 12000
    hp = 16000
    ph = 3.8
    defaultBombCount = 5
    def __init__(self):
        SpazBot.__init__(self)
    def __superHandleMessage(self, msg):
        super(SpazBot, self).handleMessage(msg)
    def handleMessage(self, msg):
        if isinstance(msg, bs.HitMessage):
            activity = self._activity()
            if (msg.hitSubType in ['bossBlast', 'impact', 'killLaKill', 'poisonEffect', 'poison', 'landMine']) or (msg.sourcePlayer is None): return True
            if msg.flatDamage:
                dmg = msg.flatDamage * 1.0
            else:
                dmg = 0.22 * self.node.damage
            if activity is not None:
                if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                    if dmg > 0.0:
                        activity.handleMessage(
                            ZeroBossHitMessage(msg.hitType, msg.hitSubType, msg.sourcePlayer, dmg * 1.0))
            if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                self.lastPlayerAttackedBy = msg.sourcePlayer
                self.lastAttackedTime = bs.getGameTime()
                self.lastAttackedType = (msg.hitType, msg.hitSubType)
            self.__superHandleMessage(msg)
        elif isinstance(msg, bs.DieMessage):
            # report normal deaths for scoring purposes
            if not self._dead and not msg.immediate:

                # if this guy was being held at the time of death, the
                # holder is the killer
                if (self.heldCount > 0 and self.lastPlayerHeldBy is not None
                        and self.lastPlayerHeldBy.exists()):
                    killerPlayer = self.lastPlayerHeldBy
                else:
                    # otherwise if they were attacked by someone in the
                    # last few seconds that person's the killer..
                    # otherwise it was a suicide
                    if (self.lastPlayerAttackedBy is not None
                           and self.lastPlayerAttackedBy.exists()
                           and bs.getGameTime() - self.lastAttackedTime < 4000):
                        killerPlayer = self.lastPlayerAttackedBy
                    else:
                        killerPlayer = None
                activity = self._activity()

                if killerPlayer is not None and not killerPlayer.exists():
                    killerPlayer = None
                if activity is not None: activity.handleMessage(ZeroBossDeathMessage(self, killerPlayer, msg.how))
            self.__superHandleMessage(msg) # augment standard behavior
        else:
            SpazBot.handleMessage(self, msg)

class ZeroBossBotSpecial(SpazBot):
    color=(0, 0, 0)
    highlight=(-0.5, -0.5, -2.5)
    character = 'Snake Shadow'
    defaultBombType = 'impact'
    punchiness = 0.4
    throwiness = 0.35
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 4
    throwDistMax = 9999
    pointsMult = 60
    hp = 3250
    ph = 1.2
    defaultBombCount = 1

class ZeroBossBot(SpazBot):
    color=(1,1,1)
    highlight=(3, 3, 3)
    character = 'Snake Shadow'
    defaultBombType = 'killLaKill'
    punchiness = 2.2
    throwiness = 0
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 7
    throwDistMax = 9999
    pointsMult = 30
    hp = 920
    ph = 2.2
    defaultBombCount = 1

def bsGetAPIVersion():
    return 4

def bsGetGames():
    return [ZeroGameUpdated]

def bsGetLevels():
    return [bs.Level('Zero Chance', displayName='${GAME}', gameType=ZeroGameUpdated, settings={'HardCore?':False}, previewTexName='black')]

class ZeroGameUpdated(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'Zero Chance\'s'

    @classmethod
    def getScoreInfo(cls):
        return {'scoreName': 'Score', 'scoreType': 'points'}

    @classmethod
    def getDescription(cls, sessionType):
        return 'Stay alive.'

    @classmethod
    def getSupportedMaps(cls, sessionType):
        return ['Football Stadium']

    @classmethod
    def supportsSessionType(cls, sessionType):
        return True

    @classmethod
    def getSettings(cls, sessionType):
        return []

    def __init__(self, settings):
        bs.TeamGameActivity.__init__(self, settings)        
        self._scoreBoard = bs.ScoreBoard()
        self._bots = bs.BotSet()

    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='Scary')

    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)       
        self.time = 0
        self.st = 1
        self.timeSecond = 0
        self.respawn = 0
        self.maxRespawn = len(bsInternal._getForegroundHostActivity().players) * 5
        self.beDamage = 0
        self._numBots = 0
        self.wantDamage = 4250
        self.kill = 0
        self.hard = False
        self.lastRnd = -1
        self.completed = False
        self.started = False
        self.specialAttackSecondComplete = False
        self.compl = False
        self.stAttack = False
        self.stAttackCompleted = False
        self.wait = False
        self.lastRespawn = 0
        self.boss = None
        self.attackWithoutHeal = 0
        self.randomTime = (28000-(5500*self.st))
        self.lastPunchTime = None
        self._bots.spawnBot(ZeroBoss, pos=(0, 0.5, 0), spawnTime=5000)
        self._updateTimer = bs.Timer(100, bs.Call(self._update), repeat = True)
        self._bossUpdateTimer = bs.Timer(100, bs.Call(self._bossUpdate), repeat = True)
        self._randomAtkTimer = bs.Timer(self.randomTime, bs.Call(self._randomAtk))
        self.healTimer = bs.Timer(1000, bs.Call(self.heal), repeat = True)
        self.tpBossSound = bs.getSound('block')

    def _randomAtk(self):
        if self.st != 0:
            rnd = int(random.randrange(0,6)*self.st)
            if rnd > 11: 
                if self.st >= 2: rnd = random.randrange(3,12)
                elif self.st == 1: rnd = random.randrange(0,11)
            if self.boss is not None:
                if (self.boss.hitPoints <= 100) and (self.st >= 3): self.runAsNaruto()
            if self.lastRnd == rnd: 
                self._randomAtk()
            else:
                self.completed = True
                if rnd == 0: self.horizontalAttack()
                elif rnd == 1: self.verticalAttack()
                elif rnd == 2: self.multiAttack()
                elif rnd == 3: self.circles()
                elif rnd == 4: self.circleAttack()
                elif rnd == 5: self.specialCircleAttack()
                elif rnd == 6 and self.lastRnd < 7: self.spawnBots()
                elif rnd == 7 and self.st >= 3: self.areaAttack()
                elif rnd == 8 and self.st > 1: self.areaAttackMedium()
                elif rnd == 9 and self.st > 1: self.areaAttackOnEnd()
                elif rnd == 10 and self.st > 1 and self.lastRnd < 6: self.areaAttackMedium()
                elif rnd == 11: self.multiAttack()
                elif rnd == 12: 
                    self.circles()
                    self.teleporting()
                else: 
                    self._randomAtk()
                    self.completed = False
                if self.completed:
                    self.attackWithoutHeal += 1
                    self._randomAtkTimer = None
                    self._randomAtkTimer = bs.Timer(self.randomTime, bs.Call(self._randomAtk))
                    self.lastRnd = rnd

    def _update(self):
        self.boss = [i if isinstance(i, ZeroBoss) else None for i in self._bots._botLists][0]
        self.maxRespawn = len(self.players) * 5
        if self.st != 0:
            if self.hard: 
                self.st = 5
                self.randomTime = 3500
            else: 
                self.randomTime = (25000-(5000*self.st))
                if (self.beDamage > 16000): self.st = 4
                elif (self.beDamage > 14000) and (self.beDamage <= 16000): self.st = 3
                elif (self.beDamage >= 5500) and (self.beDamage <= 14000): self.st = 2
                else: self.st = 1

    def spawnPlayer(self, player):
        spaz = self.spawnPlayerSpaz(player)
        spaz.connectControlsToPlayer()
        
    def _bossUpdate(self):
        if self.boss is not None and self.boss.exists():
            if (self.st >= 3) and (self.boss.hitPoints <= 1000):
                self.boss.node.handleMessage("knockout", 500.0)
                self.boss.hitPoints = min(self.boss.hitPoints+5.25, self.boss.hitPointsMax)

    def celebratePlayers(self):
        for i in range(len(self.players)):
            try:
                self.players[i].actor.node.handleMessage("celebrate", 5000.0)
            except: pass

    def heal(self):
        def spawn():
            if self.st > 2: heals = min(len(self.players),2)
            else: heals = 0
            if heals > 0:
                for i in range(heals):
                    randPos = random.choice([(0,3,0),(-12,3,0),(12,3,0),(0,3,-4),(0,3,4)])
                    bs.Powerup(powerupType='health', position = randPos).autoRetain()
        if self.st == 3: ttr = 8
        elif self.st == 4: ttr = 7
        elif self.st == 5: ttr = 20
        else: ttr = ((self.st*2)-1)
        if self.attackWithoutHeal > ttr:
            allHitPoints = 0
            if len(self.players) > 1:
                maxHitPoints = (1000 * (len(self.players)-1))
            elif len(self.players) == 1: maxHitPoints = 300
            else: maxHitPoints = -1
            for i in self.players:
                allHitPoints += i.actor.hitPoints
            if maxHitPoints >= allHitPoints:
                bs.gameTimer(5000, bs.Call(spawn))
                self.attackWithoutHeal = 0

    def checkInAlertPlayers(self, type='', bossPos=(0,0,0)):
        for i in bsInternal._getForegroundHostActivity().players:
            try:
                if type == 'horizontal':
                    if int(i.actor.node.position[0]) in range(-15,15):
                        if int(i.actor.node.position[2]) in range(-2,2):
                            TextOnScreen(owner = i.actor.node)
                elif type == 'vertical':
                    if int(i.actor.node.position[0]) in range(-2,2):
                        if int(i.actor.node.position[2]) in range(-15,15):
                            TextOnScreen(owner = i.actor.node)
                elif type == 'center':
                    if int(i.actor.node.position[0]) in range(-2,2):
                        if int(i.actor.node.position[2]) in range(-2,2):
                            TextOnScreen(owner = i.actor.node)
                elif type == 'custom':
                    if int(i.actor.node.position[0]-bossPos[0]) in range(-3,3):
                        if int(i.actor.node.position[2]-bossPos[2]) in range(-3,3):
                            TextOnScreen(owner = i.actor.node)
                else: TextOnScreen(owner = i.actor.node)
            except: pass

    def spawnBots(self):
        if self._numBots == 0:
            self._numBots += 2
            if self._numBots < 1:
                if (random.random() >= 1) or (self.st >= 2):
                    self._bots.spawnBot(ZeroBossBotSpecial, pos=(-1,0,0), spawnTime=1)
                    self._bots.spawnBot(ZeroBossBotSpecial, pos=(1,0,0), spawnTime=1)
                elif (self.st < 2):
                    self._bots.spawnBot(ZeroBossBot, pos=(0,0,1), spawnTime=1)
                    self._bots.spawnBot(ZeroBossBot, pos=(0,0,-1), spawnTime=1)
            elif self._numBots < 2:
                if (random.random() >= 1) or (self.st >= 2):
                    self._bots.spawnBot(ZeroBossBotSpecial, pos=(0,0,0), spawnTime=1)
                elif (self.st < 2):
                    self._bots.spawnBot(ZeroBossBot, pos=(0,0,0), spawnTime=1)

    def horizontalAttack(self):
        def a():
            ZeroBossBlast(type='horizontal').autoRetain()
        self.checkInAlertPlayers(type='horizontal')
        bs.gameTimer(2000, bs.Call(a))

    def verticalAttack(self):
        def a():
            ZeroBossBlast(type='vertical').autoRetain()
        self.checkInAlertPlayers(type='vertical')
        bs.gameTimer(2000, bs.Call(a))

    def multiAttack(self):
        def a():
            ZeroBossBlast(type='horizontal').autoRetain()
            ZeroBossBlast(type='vertical').autoRetain()
        self.checkInAlertPlayers()
        bs.gameTimer(2000, bs.Call(a))

    def circles(self):
        self.checkInAlertPlayers()
        def a():
            ZeroBossBlast(type='sphere').autoRetain()
        for i in range(35):
            bs.gameTimer(300*(i+20), bs.Call(a))

    def circleAttack(self):
        self.checkInAlertPlayers()
        ZeroBossCircle()

    def specialCircleAttack(self):
        self.checkInAlertPlayers(type='horizontal')
        def a():
            ZeroBossCircle(time=5000, position=(-8,1.5,0), times = 1, radius =0.5)
        def b():
            ZeroBossCircle(time=5000, position=(8,1.5,0), times = 1, radius =0.5)
        def c():
            ZeroBossCircle(time=5000, position=(0,1.5,0), times = 2)
        bs.gameTimer(1, bs.Call(a))
        bs.gameTimer(2001, bs.Call(b))
        bs.gameTimer(4001, bs.Call(c))

    def teleportHard(self):
        if self.boss is not None and self.boss.exists():
            #tpPosition = (self.boss.node.position[0]+random.randint(-12,12), 1, self.boss.node.position[2]+random.randint(-3,3))
            tpPosition = (random.randint(-12,12), 1, random.randint(-3,3))
            if tpPosition[0] > 12: tpPosition = (11, tpPosition[1], tpPosition[2])
            if tpPosition[0] < -12: tpPosition = (-11, tpPosition[1], tpPosition[2])
            if tpPosition[2] > 4: tpPosition = (tpPosition[0], tpPosition[1], 3)
            if tpPosition[2] < -4: tpPosition = (tpPosition[0], tpPosition[1], -3)
            bs.emitBGDynamics(position=self.boss.node.position,velocity=(0.1,-1,0.1),
                count=random.randrange(10, 30), scale=0.35,
                spread=0.2, chunkType='spark')
            self.boss.node.handleMessage('stand', tpPosition[0], tpPosition[1], tpPosition[2], 0)

    def lineTeleport(self):
        if self.boss is not None and self.boss.exists():
            tpPosition = (self.boss.node.position[0]+0.01, 0, 0)
            if tpPosition[0] > 12: tpPosition = (-12, 0, 0)
            bs.emitBGDynamics(position=self.boss.node.position,velocity=(0.1,-1,0.1),
                count=random.randrange(10, 30), scale=0.35,
                spread=0.2, chunkType='spark')
            self.boss.node.handleMessage('stand', tpPosition[0], tpPosition[1], tpPosition[2], 0)

    def runAsNaruto(self):
        self.checkInAlertPlayers()
        def start():
            for i in range(2500):
                bs.gameTimer(1+(i*2), bs.Call(self.teleportHard))
        bs.gameTimer(2000, bs.Call(start))

    def teleporting(self):
        self.checkInAlertPlayers()
        def start():
            for i in range(2000):
                bs.gameTimer(1+(i*5), bs.Call(self.teleportHard))
        bs.gameTimer(2000, bs.Call(start))
            
    def areaAttack(self):
        self.checkInAlertPlayers()
        def bomb():
            bs.Bomb(position=(0,5,0), velocity=(0,0,0), bombType='poison', blastRadius=100, sourcePlayer=None, owner = self.boss.node).autoRetain()
        bs.gameTimer(2000, bs.Call(bomb))

    def areaAttackMedium(self):
        self.checkInAlertPlayers()
        for i in range(int(random.randrange(30,60))):
            bs.gameTimer(100+(i*10), bs.Call(self.spawnMines))

    def spawnMines(self):
        def start():
            bs.emitBGDynamics(position=self.boss.node.position,velocity=(0,-2,0),
                count=random.randrange(50, 70), scale=0.5,
                spread=0.6, chunkType='spark')
            self.teleportHard()
            velocity = random.choice([(0,-2,0), (-2,0,0), (2,0,0), (0,0,-2), (0,0,2)])
            bs.Bomb(position=(self.boss.node.position[0],1,self.boss.node.position[2]), velocity=velocity, bombType='impact', sourcePlayer=None, blastRadius=1).autoRetain()
        start()

    def areaAttackOnEnd(self):
        self.checkInAlertPlayers()
        def bomb():
            for i in range(8):
                bs.Bomb(position=(i,7,i), velocity=(0,0,0), bombType='impact', blastRadius=1, sourcePlayer=None).autoRetain()
                bs.Bomb(position=(-i,7,-i), velocity=(0,0,0), bombType='impact', blastRadius=1, sourcePlayer=None).autoRetain()
                bs.Bomb(position=(-i,7,i), velocity=(0,0,0), bombType='impact', blastRadius=1, sourcePlayer=None).autoRetain()
                bs.Bomb(position=(i,7,-i), velocity=(0,0,0), bombType='impact', blastRadius=1, sourcePlayer=None).autoRetain()
        if self.st == 3:
            bs.gameTimer(2000, bs.Call(bomb))

    def handleMessage(self, m):
        if isinstance(m, bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self, m)
            self.respawn += 1
            if self.respawn > self.maxRespawn: 
                self.endGame()
            else: 
                self._aPlayerHasBeenKilled = True
                player = m.spaz.getPlayer()
                if not player.exists(): return
                self.scoreSet.playerLostSpaz(player)
                respawnTime = 1000+len(self.initialPlayerInfo)*2500
                player.gameData['respawnTimer'] = bs.Timer(respawnTime, bs.Call(self.spawnPlayerIfExists, player))
                player.gameData['respawnIcon'] = bs.RespawnIcon(player, respawnTime)
        elif isinstance(m, ZeroBossDeathMessage):
            self.celebratePlayers()
            bs.gameTimer(5000, bs.Call(self.endGame))
            self.kill += 16000
        elif isinstance(m, bs.SpazBotDeathMessage):
            self._numBots -= 1
            self.kill += 75
        elif isinstance(m, ZeroBossHitMessage):
            self.beDamage += m.damage
            if self.st == 4 and m.type == 'punch': self.boss.hitPoints = min(self.boss.hitPoints+m.damage, self.boss.hitPointsMax)
            if self.boss is not None and self.boss.exists():
                if (m.type == 'punch' and m.damage >= 300.0) or (self.st >= 3 and m.type == 'punch'):
                    if random.randrange(0,3) < 1:
                        try: bs.playSound(self.tpBossSound, 0.5, position=self.boss.node.position)
                        except: pass
                        bs.emitBGDynamics(position=self.boss.node.position,velocity=(0.05,1.4,0.05),
                            count=random.randrange(50, 70), scale=0.5,
                            spread=0.6, chunkType='spark')
                        tpPosition = (self.boss.node.position[0]+random.randint(-12,12), 0, self.boss.node.position[2]+random.randint(-3,3))
                        if tpPosition[0] > 12: tpPosition = (11, tpPosition[1], tpPosition[2])
                        if tpPosition[0] < -12: tpPosition = (-11, tpPosition[1], tpPosition[2])
                        if tpPosition[2] > 4: tpPosition = (tpPosition[0], tpPosition[1], 3)
                        if tpPosition[2] < -4: tpPosition = (tpPosition[0], tpPosition[1], -3)
                        self.boss.node.handleMessage('stand', tpPosition[0], tpPosition[1], tpPosition[2], 0)
                elif (m.type == 'explosion') or (self.st >= 3 and random.randrange(0,1) == 0):
                    if random.randrange(0,5) < 1:
                        try: bs.playSound(self.tpBossSound, 0.5, position=self.boss.node.position)
                        except: pass
                        bs.emitBGDynamics(position=self.boss.node.position,velocity=(0.1,1.6,0.1),
                            count=random.randrange(50, 70), scale=0.5,
                            spread=0.6, chunkType='spark')
                        try: tpPosition = m.player.actor.node.position
                        except: tpPosition = None
                        try: self.checkInAlertPlayers(type='custom',bossPos=tpPosition)
                        except: pass
                        try: self.boss.node.handleMessage('stand', tpPosition[0], tpPosition[1], tpPosition[2], 0)
                        except: pass
        else:
            bs.TeamGameActivity.handleMessage(self, m)

    def endGame(self):
        self.st = 0
        if self.respawn == 0: self.respawn = 1
        results = bs.TeamGameResults()
        for team in self.teams:
            results.setTeamScore(team, int((self.beDamage+self.kill)-(self.respawn*250)))
        self.end(results)

class ZeroBossCircle(object):
    def __init__(self, time=10000, position=(0,1.5,0), times = 2, radius=1):
        self.endCircleTime = time
        self.circlePos = position
        self.times = times
        self.radius = radius
        if self.endCircleTime < 3000: self.endCircleTime = 3000
        def start():
            self.spawn()
        for i in range(self.times):
            bs.gameTimer((self.endCircleTime/2)*(i), bs.Call(start))
        self.light = bs.newNode('light', attrs={'position':self.circlePos,'color':(1,0.35,0),'radius':self.radius})
        bsUtils.animate(self.light, 'intensity', {0:0, 1000:1.5, self.endCircleTime-1000:1.5, self.endCircleTime:0})
        bsUtils.animate(self.light, 'radius', {0:self.radius/1.2, 700:self.radius/1.2, 1000:self.radius, 2000:self.radius/1.2}, loop=True)
        bs.gameTimer(int(self.endCircleTime*1.0), self.light.delete)
    def spawn(self):
        speed = 6
        def bomb0():
            bs.Bomb(position=self.circlePos, velocity=(0,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(0,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb1():
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(speed,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb2():
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,0), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(speed,0,0), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb3():
            bs.Bomb(position=self.circlePos, velocity=(speed,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        mult = self.endCircleTime/10
        bs.gameTimer(mult*1, bs.Call(bomb0))
        bs.gameTimer(mult*2, bs.Call(bomb1))
        bs.gameTimer(mult*3, bs.Call(bomb2))
        bs.gameTimer(mult*4, bs.Call(bomb3))

class ZeroBossBlastExample(object):
    def __init__(self, position=(0,0,0), color=(1,0.75,0), radius=0.3, mult=1.05, startTime=1, endTime=2001):
        self.death = endTime
        self.start = startTime
        self.position = position
        self.color = color
        self.radius = radius
        self.mult = mult
        bs.gameTimer(int(self.start*1.0), self.spawn)
    def spawn(self):
        self.light = bs.newNode('light', attrs={'position':self.position,'color':self.color,'radius':self.radius})
        bsUtils.animate(self.light, 'intensity', {0:0, 1000:1.75, int(self.death*1.0):1.75, int(self.death*1.0)+1000:0})
        bsUtils.animate(self.light, 'radius', {0:self.radius, 3000:self.radius*self.mult, 4500:self.radius}, True)
        bs.gameTimer(int(self.death*1.0)+1000, self.light.delete)

class ZeroBossBlast(bs.Actor):
    def __init__(self,position=(0,1,0),time=5000,type = 'horizontal'):
        bs.Actor.__init__(self)
        factory = self.getFactory()
        self.pos = position
        self.scale = (1,1,1)
        self.time = time
        self.m = type
        if (self.m in ['horizontal','vertical']):
            if self.m == 'horizontal': 
                for i in range(30):
                    ZeroBossBlastExample(position=(-15+i,0,0), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1+(i*30), endTime=(1+int(self.time*1.0)))
                self.scale = (20,10,0.1)
            elif self.m == 'vertical':
                for i in range(20):
                    ZeroBossBlastExample(position=(0,0,-10+i), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1+(i*30), endTime=(1+int(self.time*1.0)))
                self.scale = (0.1,10,20)
            def spawn():
                self.node = bs.newNode('region', delegate=self, attrs={'position':(self.pos[0],self.pos[1]-0.1,self.pos[2]),'scale':self.scale,'type':'box','materials':(factory.newBlastMaterial, bs.getSharedObject('attackMaterial'))})
                bs.gameTimer(int(self.time*1.0), self.node.delete)
            bs.gameTimer(500, bs.Call(spawn))
        elif (self.m in ['sphere']):
            self.scale = (0.6,10,0.6)
            randPos = (random.randrange(-12,12),1,random.randrange(-5,5))
            def spawn():
                self.node = bs.newNode('region', delegate=self, attrs={'position':(randPos[0],randPos[1]-0.1,randPos[2]),'scale':self.scale,'type':'sphere','materials':(factory.newBlastMaterial, bs.getSharedObject('attackMaterial'))})
                bs.gameTimer(int(self.time*1.0), self.node.delete)
            bs.gameTimer(500, bs.Call(spawn))
            ZeroBossBlastExample(position=(randPos[0],randPos[1]-0.1,randPos[2]), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1, endTime=(1+int(self.time*1.0)))

    def getFactory(cls):
        activity = bs.getActivity()
        try: return activity._sharedZeroBossBlastFact
        except Exception:
            f = activity._sharedZeroBossBlastFact = ZeroBossBlastFactory()
            return f

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if isinstance(msg, bs.DieMessage): 
            self.node.delete()
        elif isinstance(msg, NewExplodeHitMessage):
            node = bs.getCollisionInfo("opposingNode")
            if node is not None and node.exists():
                t = self.node.position
                tr = node.position
                if (node.getNodeType() == 'spaz'):
                    node.handleMessage(bs.HitMessage(
                        pos=tr,
                        velocity=(0,0,0),
                        magnitude=550.0,
                        hitType='explosion',
                        hitSubType='bossBlast',
                        radius=100.0,
                        sourcePlayer=bs.Player(None), 
                        kickBack=0))
                    node.handleMessage('impulse',tr[0],tr[1]-2,tr[2],0,0,0,2000,0,200.0,1,0,100,0)
        else:
            bs.Actor.handleMessage(self, msg)

class ZeroBossBlastFactory(object):
    def __init__(self):
        self.blastSound = bs.getSound('activateBeep')
        self.newBlastMaterial = bs.Material()
        self.newBlastMaterial.addActions(
            conditions=(('theyHaveMaterial',
                         bs.getSharedObject('objectMaterial'))),
            actions=(('modifyPartCollision','collide',True),
                     ('modifyPartCollision','physical',False),
                     ('message','ourNode','atConnect',NewExplodeHitMessage())))

class NewExplodeHitMessage(object):
    def __init__(self):
        pass

class TextOnScreen(object):
    def __init__(self, color=(3,0,0), scale=0.0095, time=2000, position='player', opacity=1, text='Alert!', owner=None):
        self.color = color
        self.scale = scale
        self.end = time
        self.owner = owner
        self.pos = position if position != 'player' else (0,0,0)
        self.flatness = opacity
        self.text = text
        if self.owner is not None:
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 2.325, 0), 'operation': 'add'})
            self.owner.connectAttr('position', m, 'input2')                        
            self._text = bs.newNode('text', owner=self.owner, attrs={'text':self.text, 'inWorld':True, 'position':self.pos, 'flatness':0, 'color':self.color, 'scale':0, 'hAlign':'center'})
            m.connectAttr('output', self._text, 'position')
        else: self._text = bs.newNode('text', attrs={'text':self.text, 'inWorld':True, 'position':self.pos, 'flatness':0, 'color':self.color, 'scale':0, 'hAlign':'center'})
        bsUtils.animate(self._text, 'scale', {0:0, 250:self.scale, int(self.end*1.0):self.scale, int(self.end*1.0)+500:0.0})
        bsUtils.animate(self._text, 'opacity', {0:self.flatness/1.5, 250:self.flatness, 500:self.flatness/1.5}, loop = True)
        bs.gameTimer(int(self.end*1.0)+500, self._text.delete)
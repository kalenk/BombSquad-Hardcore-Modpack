import json
import os
import bs
import bsInternal

env = bs.getEnvironment()
_gData={"admins":[], "vips":[], "lobby_connect_menu":False, "show_game_name":True, \
    "admins_prefix":True, "timer_the_disappearance_of_the_effect":True, \
    "powerup_lighting":True, "timer_the_disappearance_of_the_powerup":True, \
    "timer_before_the_bomb_explode":True, "chat_commands_enabled":True, \
    "standart_powerups":False, "auto-update":False}

gSettingsPath=os.path.join(env["userScriptsDirectory"], "settings.json")

def set_setting(name=None, value=True):
    data=get_settings(path=gSettingsPath)
    data.update({name: value})
    json.dump(data, open(gSettingsPath, "w+"))

def check_settings_file():
    if not os.path.exists(gSettingsPath): rewrite_settings()
    else:
        data = get_settings(path=gSettingsPath)
        for i in bs.getDefaultPowerupDistribution(True):
            if i[0] not in _gData:
                _gData.update({i[0]: True})
        for i in _gData:
            if data.get(i) is None:
                reload_settings(data=data) # FIXME
                rewrite_settings()
                break

def reload_settings(data=None):
    if data is not None:
        for i in data: _gData.update({i: data[i]})

def rewrite_settings():
    json.dump(_gData, open(gSettingsPath, "w+"))
    bs.screenMessage("settings file was broken, rewriting it..")

def get_settings(path=None):
    if path is None: path = gSettingsPath
    if not isinstance(path, str): path = str(path)
    if path is not None:
        if os.path.exists(path):
            try: return json.load(open(path))
            except Exception: return _gData
    return {}

def get_setting(name=None, default_value=None):
    data=get_settings(path=gSettingsPath)
    return data.get(name) if data.get(name) is not None else default_value

def write_log(path=None):
    if path is None: path=os.path.join(env["userScriptsDirectory"], "log.txt")
    if path.endswith(".txt"):
        with open(path, "w+") as f:
            f.write(bsInternal._getLog())
            f.close()
    else:
        for i in ["path isn\'t exists: "+path, "see more in advanced.__init__.write_log()"]: bsInternal._log(i)
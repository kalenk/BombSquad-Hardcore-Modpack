import bs
import random
import bsUtils
import bsInternal
from bsSpaz import SpazBot

class ZeroBossHitMessage(object):
    def __init__(self, type, subType, player, damage):
        self.type = type
        self.subType = subType
        self.player = player
        self.damage = damage


class ZeroBossDeathMessage(object):
    def __init__(self, badGuy, killerPlayer, how):
        self.badGuy = badGuy
        self.killerPlayer = killerPlayer
        self.how = how

class ZeroBoss(SpazBot):
    color=(0.5, 0.5, 2.5)
    highlight=(-0.5, -0.5, -2.5)
    character = 'Snake Shadow'
    defaultBombType = 'poison'
    punchiness = 0.4
    throwiness = 0.35
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 4
    throwDistMax = 9999
    pointsMult = 12000
    hp = 16000
    ph = 3.8
    defaultBombCount = 5
    def __init__(self):
        SpazBot.__init__(self)
    def __superHandleMessage(self, msg):
        super(SpazBot, self).handleMessage(msg)
    def handleMessage(self, msg):
        if isinstance(msg, bs.HitMessage):
            activity = self._activity()
            if (msg.hitSubType in ['bossBlast', 'impact', 'killLaKill', 'poisonEffect', 'poison', 'landMine']) or (msg.sourcePlayer is None): return True
            if msg.flatDamage:
                dmg = msg.flatDamage * 1.0
            else:
                dmg = 0.22 * self.node.damage
            if activity is not None:
                if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                    if dmg > 0.0:
                        activity.handleMessage(
                            ZeroBossHitMessage(msg.hitType, msg.hitSubType, msg.sourcePlayer, dmg * 1.0))
            if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                self.lastPlayerAttackedBy = msg.sourcePlayer
                self.lastAttackedTime = bs.getGameTime()
                self.lastAttackedType = (msg.hitType, msg.hitSubType)
            self.__superHandleMessage(msg)
        elif isinstance(msg, bs.DieMessage):
            # report normal deaths for scoring purposes
            if not self._dead and not msg.immediate:

                # if this guy was being held at the time of death, the
                # holder is the killer
                if (self.heldCount > 0 and self.lastPlayerHeldBy is not None
                        and self.lastPlayerHeldBy.exists()):
                    killerPlayer = self.lastPlayerHeldBy
                else:
                    # otherwise if they were attacked by someone in the
                    # last few seconds that person's the killer..
                    # otherwise it was a suicide
                    if (self.lastPlayerAttackedBy is not None
                           and self.lastPlayerAttackedBy.exists()
                           and bs.getGameTime() - self.lastAttackedTime < 4000):
                        killerPlayer = self.lastPlayerAttackedBy
                    else:
                        killerPlayer = None
                activity = self._activity()

                if killerPlayer is not None and not killerPlayer.exists():
                    killerPlayer = None
                if activity is not None: activity.handleMessage(ZeroBossDeathMessage(self, killerPlayer, msg.how))
            self.__superHandleMessage(msg) # augment standard behavior
        else:
            SpazBot.handleMessage(self, msg)


class ZeroBossBotSpecial(SpazBot):
    color=(0, 0, 0)
    highlight=(-0.5, -0.5, -2.5)
    character = 'Snake Shadow'
    defaultBombType = 'impact'
    punchiness = 0.4
    throwiness = 0.35
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 4
    throwDistMax = 9999
    pointsMult = 60
    hp = 3250
    ph = 1.2
    defaultBombCount = 1

class ZeroBossBot(SpazBot):
    color=(1,1,1)
    highlight=(3, 3, 3)
    character = 'Snake Shadow'
    defaultBombType = 'killLaKill'
    punchiness = 2.2
    throwiness = 0
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 7
    throwDistMax = 9999
    pointsMult = 30
    hp = 920
    ph = 2.2
    defaultBombCount = 1

class AttackTakingMessage(object):
    def __init__(self):
        pass

class Attack(object):
    def __init__(self, position=(0, 0, 0)):
        self.position = position

    @classmethod
    def run(self, method=None, attack_mode=(0, 100)):
        if method is not None:
            if isinstance(attack_mode, tuple) and len(attack_mode) > 0:
                for i in attack_mode: bs.gameTimer(i, bs.Call(method))
            else: bs.gameTimer(1000, bs.Call(method))

class CircledFloor(Attack):
    def __init__(self, position=(0, 0, 0)):
        self.mat = bs.Material()
        self.mat.addActions(
            conditions=(('theyHaveMaterial', bs.getSharedObject('objectMaterial'))),
            actions=(('modifyPartCollision', 'collide', True),
                    ('modifyPartCollision', 'physical', False),
                    ('message', 'ourNode', 'atConnect', AttackTakingMessage())))
        self.pos = position
        self.run(self.spawn, (1000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 6000, 6500))
    def spawn(self):
        if getattr(self, "pos", None) is not None:
            l = bs.newNode('light', attrs={'position': self.pos, 'color': (1, 0.75, 0.15), 'radius': 0.1})
            bsUtils.animate(l, 'intensity', {0: 0, 100: 1.75, 1500: 1.75, 2000: 0})
            bsUtils.animate(l, 'radius', {0: 0.1, 3000: 0.105, 2000: 0.1}, True)
            bs.gameTimer(2500, l.delete)
            c = bs.newNode('region', delegate=None, attrs={'position': (self.pos[0], self.pos[1] - 0.1, self.pos[2]),
                'scale': (1, 1, 1),
                'type': 'sphere',
                'materials': (self.mat, bs.getSharedObject('attackMaterial'))})
            def check():
                node = bs.getCollisionInfo("opposingNode")
                if node is not None and node.exists:
                    node.handleMessage(bs.HitMessage(
                        pos=(node.position[0], node.position[1]+0.5, node.position[2]),
                        velocity=(0, 0, 0),
                        magnitude=10000,
                        hitType="punch",
                        hitSubType="superPunch",
                        radius=10,
                        sourcePlayer=None,
                        kickBack=0))
            bs.Timer(50, bs.Call(check), True)
            bs.gameTimer(2500, c.delete)

class ZeroGame(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'Zero Chance\'s'

    @classmethod
    def getDescription(cls, sessionType):
        return 'Stay alive.'

    @classmethod
    def supportsSessionType(cls, sessionType):
        return True if (issubclass(sessionType, bs.FreeForAllSession)) else False

    def __init__(self, settings={}):
        settings['map'] = "Football"
        self._newWaveSound = bs.getSound('scoreHit01')
        self._winSound = bs.getSound("score")
        self._cashRegisterSound = bs.getSound('cashRegister')
        self._bots = bs.BotSet()

    def onTransitionIn(self):
        bs.CoopGameActivity.onTransitionIn(self, music='Scary')
        self._scoreBoard = bs.ScoreBoard(
            label=bs.Lstr(resource='scoreText'),
            scoreSplit=0.5)
        self._score = bs.SecureInt(0)

    def onTransitionOut(self):
        bs.CoopGameActivity.onTransitionOut()

    def onBegin(self):
        bs.CoopGameActivity.onBegin(self)
        self._bots.spawnBot(ZeroBoss, pos=(0, 0.5, 0), spawnTime=5000)
        self.healTimer = bs.gameTimer(30000, bs.Call(self.health), repeat = True)

    def health(self):
        bs.Powerup(
            position=self.getMap().powerupSpawnPoints[0],
            powerupType="health").autoRetain()

    def spawnPlayer(self, player):
        spaz = self.spawnPlayerSpaz(player)
        spaz.connectControlsToPlayer()

    def __superHandleMessage(self, m):
        super(ZeroGame, self).handleMessage(m)

    def handleMessage(self, m):
        if isinstance(m, bs.PlayerSpazDeathMessage):
            player = m.spaz.getPlayer()
            if player is None:
                bs.printError('FIXME: getPlayer() should no longer ever be returning None')
                return
            if not player.exists():
                return
            self.scoreSet.playerLostSpaz(player)
            bs.gameTimer(2000, bs.Call(self.spawnPlayer, player))
        elif isinstance(m, bs.ZeroBossDeathMessage): self.celebrate(5000)
        elif isinstance(m, bs.SpazBotDeathMessage): pass
        elif isinstance(m, bs.ZeroBossHitMessage): pass
        else: self.__superHandleMessage(m)

    def doEnd(self, outcome):
        if outcome == 'defeat':
            self.fadeToRed()
        self.end(
            delay=2000,
            results={'outcome': outcome, 'score': self._score.get(),
                     'playerInfo': self.initialPlayerInfo})

    def endGame(self):
        self._bots.finalCelebrate()
        bs.gameTimer(1, bs.WeakCall(self.doEnd, 'defeat'))
        bs.playMusic(None)

class ZeroBossCircle(object):
    def __init__(self, time=10000, position=(0,1.5,0), times = 2, radius=1):
        self.endCircleTime = time
        self.circlePos = position
        self.times = times
        self.radius = radius
        if self.endCircleTime < 3000: self.endCircleTime = 3000
        def start():
            self.spawn()
        for i in range(self.times):
            bs.gameTimer((self.endCircleTime/2)*(i), bs.Call(start))
        self.light = bs.newNode('light', attrs={'position':self.circlePos,'color':(1,0.35,0),'radius':self.radius})
        bsUtils.animate(self.light, 'intensity', {0:0, 1000:1.5, self.endCircleTime-1000:1.5, self.endCircleTime:0})
        bsUtils.animate(self.light, 'radius', {0:self.radius/1.2, 700:self.radius/1.2, 1000:self.radius, 2000:self.radius/1.2}, loop=True)
        bs.gameTimer(int(self.endCircleTime*1.0), self.light.delete)
    def spawn(self):
        speed = 6
        def bomb0():
            bs.Bomb(position=self.circlePos, velocity=(0,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(0,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb1():
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(speed,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb2():
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,0), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(speed,0,0), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb3():
            bs.Bomb(position=self.circlePos, velocity=(speed,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        mult = self.endCircleTime/10
        bs.gameTimer(mult*1, bs.Call(bomb0))
        bs.gameTimer(mult*2, bs.Call(bomb1))
        bs.gameTimer(mult*3, bs.Call(bomb2))
        bs.gameTimer(mult*4, bs.Call(bomb3))

class TextOnScreen(object):
    def __init__(self, color=(3,0,0), scale=0.0095, time=2000, position='player', opacity=1, text='Alert!', owner=None):
        self.color = color
        self.scale = scale
        self.end = time
        self.owner = owner
        self.pos = position if position != 'player' else (0,0,0)
        self.flatness = opacity
        self.text = text
        if self.owner is not None:
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 2.325, 0), 'operation': 'add'})
            self.owner.connectAttr('position', m, 'input2')                        
            self._text = bs.newNode('text', owner=self.owner, attrs={'text':self.text, 'inWorld':True, 'position':self.pos, 'flatness':0, 'color':self.color, 'scale':0, 'hAlign':'center'})
            m.connectAttr('output', self._text, 'position')
        else: self._text = bs.newNode('text', attrs={'text':self.text, 'inWorld':True, 'position':self.pos, 'flatness':0, 'color':self.color, 'scale':0, 'hAlign':'center'})
        bsUtils.animate(self._text, 'scale', {0:0, 250:self.scale, int(self.end*1.0):self.scale, int(self.end*1.0)+500:0.0})
        bsUtils.animate(self._text, 'opacity', {0:self.flatness/1.5, 250:self.flatness, 500:self.flatness/1.5}, loop = True)
        bs.gameTimer(int(self.end*1.0)+500, self._text.delete)

﻿# -*- coding: utf-8 -*-
import bs
import bsInternal
import bsPowerup
import bsUtils
import bsSpaz
from bsSpaz import *
import bsUI
import time
import random
from skins import PermissionEffect
import skins
import advanced

bsUtils._havePro = lambda : True
bsUtils._haveProOptions = lambda : True

def send_message(msg):
    if len(bsInternal._getGameRoster()) == 0:
        if bsUI.gPartyWindow is not None and bsUI.gPartyWindow() is not None:
            with bs.Context("UI"):
                bsUI.gPartyWindow()._addMsg(msg=msg, color=(1, 1, 1))
    else: bsInternal._chatMessage(msg)

maps={"Doom Shroom":(0.82, 1.10, 1.15), "Hockey Stadium":(1.2,1.3,1.33), \
    "Football Stadium":(1.3, 1.2, 1.0), "Big G":(1.1, 1.2, 1.3), \
    "Roundabout":(1.0, 1.05, 1.1), "Monkey Face":(1.1, 1.2, 1.2), \
    "Bridgit":(1.1, 1.2, 1.3), "Zigzag":(1.0, 1.15, 1.15), \
    "The Pad":(1.1, 1.1, 1.0), "Lake Frigid":(1, 1, 1), \
    "Tip Top":(0.8, 0.9, 1.3), "Crag Castle":(1.15, 1.05, 0.75), \
    "Tower D":(1.15, 1.11, 1.03), "Happy Thoughts":(1.3, 1.23, 1.0), \
    "Step Right Up":(1.2, 1.1, 1.0), "Courtyard":(1.2, 1.17, 1.1), \
    "Rampage":(1.2, 1.1, 0.97)}

commands=['/name','/arg','/cmd','/help','/summon','/s','/list', \
    '/l','/mp','/max_players','/punch','/ph','/hp','/hitpoints','/particle','/time','/timeset',\
    '/tp','/teleport','/admin','/full','/set','/h','/hello','/ban','/kick','/clear', \
    '/server', '/clans','/prefix','/pos','/skin','/end', \
    '/remove']

def get_account_string(arg):
    if is_num(arg): return str(bsInternal._getForegroundHostActivity().players[int(arg)].getInputDevice()._getAccountName(True).encode('utf-8'))
    elif ChatOptions().isAccount(arg): return arg
    elif isinstance(arg, bs.Player): return str(arg.getInputDevice()._getAccountName(True).encode('utf-8'))
    else: return None

def is_vector(position):
    result = 0
    for i in position:
        if is_num(i): result += 1
    if result == len(position): return True
    return False

def is_num(val):
    try: return True if str(val).encode("utf-8").replace("-","").replace(".","").isdigit() else False
    except UnicodeDecodeError: return False

def is_account(account):
    for icon in ['googlePlusLogo', 'gameCenterLogo', 'gameCircleLogo', \
        'ouyaLogo', 'localAccount', 'alibabaLogo', \
        'oculusLogo', 'nvidiaLogo']:
        if str(bs.getSpecialChar(icon).encode('utf-8')) in str(account): return True
    return False

def get_normal_tint():
    a=bsInternal._getForegroundHostActivity()
    if a is not None:
        import bsMainMenu
        if isinstance(bsInternal._getForegroundHostActivity(), bsMainMenu.MainMenuActivity): name = "The Pad"
        else: name = a.getMap().name
        if name is not None:
            if name in maps:
                for i in maps:
                    if i == name: globals().update({"tint_real": maps[i]})
            else: bsInternal._log("error map name: "+name+", see more in chatCmd.get_normal_tint()")
    return globals().get("tint_real", None)

def get_motion():
    a=bsInternal._getForegroundHostActivity()
    motion = False
    if a is not None:
        motion = a._inheritsSlowMotion if globals().get("motion_normal", None) is None else globals().get("motion_normal", None)
    return motion

admins = bs.get_setting("admins", [])
vips = bs.get_setting("vips", [])
prefixes = bs.get_setting("prefixes", {})
in_alert = bs.get_setting("in_alert", {})
banned = bs.get_setting("banned", [])
globals().update({"tint_normal": get_normal_tint()})
globals().update({"motion_normal": get_motion()})

def dayCycle():
    if bsInternal._getForegroundHostActivity() is not None:
        tint = get_tint()
        anim={0: tint, 7500:(1.25, 1.21, 1.075),
            30000: (1.25, 1.21, 1.075), 57500: (1.1, 0.86, 0.74),
            67500: (1.1, 0.86, 0.74), 90000: (0, 0.27, 0.51),
            120000: (0, 0.27, 0.51), 142500: (1.3, 1.06, 1.02),
            157500: (1.3, 1.06, 1.02), 180000: (1.3, 1.25, 1.2),
            195500: (1.3, 1.25, 1.2), 220000: tint}
        bsUtils.animateArray(bs.getSharedObject("globals"), "tint", 3, anim, loop=True)

class ChatOptions(object):
    def __init__(self):
        self.is_vip = False
        self.is_admin = False
        self.is_host = False
        self.server_search = False
        self._bots = None
        self.time={"normal":None, "sunrise": (1.3, 1.06, 1.02), "day": (1.3, 1.25, 1.2), "noon": (1.25, 1.21, 1.075), "sunset": (1.1, 0.86, 0.74), "night":(0, 0.27, 0.51)}

    def add_admin(self, admin=False, account=None, save=False):
        if account is not None:
            if save:
                setting_name = 'vips' if not admin else 'admins'
                data=bs.get_setting(setting_name, [])
                if account not in data: data.append(account)
                bs.set_setting(setting_name, value=data)
                account=account.encode('utf-8')
                users_list = vips if not admin else admins
                if account not in users_list: users_list.append(account)
                if admin: admins=users_list
                else: vips=users_list
            else:
                users_list=vips if not admin else admins
                if account not in users_list: users_list.append(account)
                if admin: admins=users_list
                else: vips=users_list

    def update(self):
        if bsInternal._getForegroundHostActivity() is not None:
            for i in bsInternal._getGameRoster():
                account = i['displayString']
                id = i['clientID']
                if len(banned) > 0:
                    if account in banned:
                        msg="" if banned.get(account) == "auto" else ("по причине: "+ banned.get(account))
                        bs.screenMessage(message=str(account)+" изгнан "+msg, color=(1,1,0), transient=True, clients=[id])
                        bsInternal._disconnectClient(id, banTime=300)
            
    def check_player(self, nickname):
        try: nickname=nickname.encode("utf-8")
        except UnicodeDecodeError: nickname=str(nickname)
        a=bsInternal._getForegroundHostActivity()
        host = bsInternal._getAccountDisplayString(True).encode('utf-8')
        if host not in admins: admins.append(host)
        optional_users=bs.get_setting("admins", default_value=[])+bs.get_setting("vips", default_value=[])
        for i in optional_users:
            if len(optional_users) > 0:
                if i in bs.get_setting("admins", default_value=[]):
                    if i.encode('utf-8') not in admins: admins.append(i.encode('utf-8'))
                else:
                    if i.encode('utf-8') not in vips: vips.append(i.encode('utf-8'))
        self.player=None
        self.is_admin=False
        self.is_vip=False
        self.is_host=False
        if a is not None:
            if len(bsInternal._getGameRoster()) > 0:
                players=[i["players"][0] for i in bsInternal._getGameRoster() if len(i["players"]) > 0]
                for i in bsInternal._getGameRoster():
                    account=i["displayString"]
                    profile_name=i["players"][0]["name"] if len(i["players"]) > 0 else i["displayString"]
                    if nickname == profile_name:
                        if account in vips: self.is_vip=True
                        elif account in admins:
                            self.is_admin=True
                            self.is_vip=True
                        if account == host: self.is_host=True
                        self.player=[q for q in a.players if q.getName(True).encode('utf-8') == [i["nameFull"] for i in players if i["name"] == nickname][0]][0]
            else:
                self.is_admin=True
                self.is_vip=True
                self.is_host=True
                self.player=a.players[0] if len(a.players) > 0 else None

    def get_player_position(self, command, arg):
        if self.player is not None:
            if command in ["tp", "teleport", "s", "summon"]:
                if ('~' in arg) or ('^' in arg):
                    if command in ["s", "summon"]: mult=4
                    elif command in ["tp", "teleport"]: mult=3
                    if len(arg) > mult:
                        for i in range(3):
                            if arg[mult-2+i] in ["~", "^"]:
                                if self.player.exists() and self.player.isAlive(): arg[mult-2+i]=self.player.actor.node.position[i]
        return arg

    def opt(self, nickname=" ", msg=" "):
        self.check_player(nickname=nickname)
        self.update()
        msg=msg.lower().replace("/", "")
        arg=msg.split(" ")[1:] if len(msg.split(" ")) > 1 else []
        command=msg.split(" ")[0]
        a=bsInternal._getForegroundHostActivity()
        if 1:
            if a is not None:
                with bs.Context(a):
                    arg=self.get_player_position(command=command, arg=arg)
                    if command in ["l","list"] and self.is_vip:
                        if len(bsInternal._getGameRoster()) > 0:
                            for i in bsInternal._getGameRoster():
                                players=[[r["nameFull"] for r in i["players"]], [d["id"] for d in i["players"]]]
                                players_string=""
                                player_nums=""
                                for k in players:
                                    if k == players[0]:
                                        for l in k:
                                            if l == k[0]: players_string+=l
                                            else: players_string+=(", "+l)
                                    else:
                                        for l in k:
                                            if l == k[0]: player_nums+=str(l)
                                            else: player_nums+=(", "+str(l))
                                bsInternal._chatMessage(i["displayString"] +" : "+player_nums+" : "+players_string)

                    elif command in ['timeset', 'time'] and self.is_vip:
                        if len(arg) > 0:
                            tint = get_tint()
                            self.time.update({"normal": get_normal_tint()})
                            for i in self.time.keys():
                                if arg[0] == i:
                                    bs.getSharedObject("globals").tint = self.time[i]
                                    tint = self.time[i]
                            if arg[0] == 'cycle':
                                tint = get_normal_tint()
                                bs.getSharedObject('globals').tint = tint
                            set_tint(tint=tint)
                        else:
                            bsInternal._chatMessage('/timeset [normal|sunrise|day|noon|sunset|night|cycle]')
                            bsInternal._chatMessage('/timeset cycle - дневной цикл(плавная смена времени)')
                            bsInternal._chatMessage('/timeset noon - середина дня')
                            bsInternal._chatMessage('/timeset sunset - закат')
    
                    elif command in ['summon','s'] and self.is_admin:
                        if len(arg) > 0:
                            if arg[0] in ['bomb','b']:
                                spawn={"bombType":"normal", "pos":[0,5,0], "count":1}
                                for i in range(len(spawn)):
                                    if len(arg) > i+1:
                                        name=spawn.keys()[i]
                                        if name == "bombType": spawn.update({name:arg[i+1]})
                                        elif name == "count":
                                            if len(arg) > i+4:
                                                if is_num(arg[i+4]):
                                                    if int(arg[i+4]) > 0: spawn.update({name:int(arg[i+4])})
                                        else:
                                            for k in range(3):
                                                if len(arg) > i+k:
                                                    if is_num(arg[i+k]): spawn["pos"][k] = float(arg[i+k])
                                for i in range(spawn["count"]):
                                    if i < 30:
                                        if self.player is not None:
                                            if self.player.exists(): bs.Bomb(position=tuple(spawn["pos"]), bombType=spawn["bombType"], owner=self.player.actor.node).autoRetain()
                                            else: bs.Bomb(position=tuple(spawn["pos"]), bombType=spawn["bombType"]).autoRetain()
                                        else: bs.Bomb(position=tuple(spawn["pos"]), bombType=spawn["bombType"]).autoRetain()
                            elif arg[0] in ['bot']:
                                import inspect
                                bots=[i for i in dir(bsSpaz) if inspect.isclass(eval("bsSpaz."+i)) and issubclass(eval("bsSpaz."+i), bsSpaz.SpazBot)]
                                if len(arg) > 1:
                                    spawn = {"botType": "BomberBot", "pos": [0, 5, 0], "count": 1}
                                    for i in range(len(spawn)):
                                        name=spawn.keys()[i]
                                        if name == "botType":
                                            if len(arg) > 1:
                                                if not (arg[i+1]+" ").isspace(): spawn.update({name:arg[i+1]})
                                        elif name == "count":
                                            if len(arg) > i+4:
                                                if is_num(arg[i+4]):
                                                    if int(arg[i+4]) > 0: spawn.update({name:int(arg[i+4])})
                                        else:
                                            for k in range(3):
                                                if len(arg) > i+k:
                                                    if is_num(arg[i+k]): spawn["pos"][k] = float(arg[i+k])
                                    bot=eval([("bsSpaz."+i) for i in bots if i.lower() == spawn["botType"]][0] if len([i for i in bots if i.lower() == spawn["botType"]]) > 0 else "bsSpaz.BomberBot")
                                    self._bots = bs.BotSet() if self._bots is None else self._bots
                                    for i in range(spawn["count"]):
                                        if i < 31: self._bots.spawnBot(bot, pos=tuple(spawn["pos"]), spawnTime=1, onSpawnCall=self._on_spawn)
                                else:
                                    for i in range(int(len(bots) / 4)):
                                        skstring = ""
                                        for r in range(4):
                                            if len(bots) + 1 > (i*4+r): skstring += (", "+bots[i*4+r]) if r > 0 else bots[i*4+r]
                                        send_message(skstring)
                                    send_message("/s bot [название] [позиция(3 числа)] [кол-во]")
                            elif arg[0] in ['flag','f']:
                                spawn = {"time_out":20, "color":[1,1,0], "pos":[0, 5, 0], "count":1}
                                for i in range(len(spawn)):
                                    name=spawn.keys()[i]
                                    if name == "color":
                                        for k in range(3):
                                            if len(arg) > i+k+6:
                                                if is_num(arg[i+k+6]): spawn["color"][k] = float(arg[i+k+6])
                                    elif name == "count":
                                        if len(arg) > i+3:
                                            if is_num(arg[i+3]):
                                                if int(arg[i+3]) > 0: spawn.update({name:int(arg[i+3])})
                                    elif name == "time_out":
                                        if len(arg) > i+3:
                                            if is_num(arg[i+3]):
                                                if int(arg[i+3]) > 0: spawn.update({name:int(arg[i+3])})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k-2:
                                                if is_num(arg[i+k-2]): spawn["pos"][k] = float(arg[i+k-2])
                                for i in range(spawn["count"]):
                                    if i < 31: bs.Flag(position=tuple(spawn["pos"]), droppedTimeout=spawn["time_out"], color=spawn["color"]).autoRetain()
                            elif arg[0] in ['powerup','p']:
                                powerups=[i[0] for i in list(bsPowerup.getDefaultPowerupDistribution())]
                                if len(arg) > 1:
                                    spawn = {"powerupType": "punch", "pos": [0, 5, 0], "count": 1}
                                    for i in range(len(spawn)):
                                        name = spawn.keys()[i]
                                        if name == "powerupType":
                                            if len(arg) > i-1:
                                                if not (arg[i-1] + " ").isspace() and arg[i-1] in [k.lower() for k in powerups]:
                                                    spawn.update({name: [l for l in powerups if arg[i-1] == l.lower()][0]})
                                        elif name == "count":
                                            if len(arg) > i+5:
                                                if is_num(arg[i+5]):
                                                    if int(arg[i+5]) > 0: spawn.update({name: int(arg[i+5])})
                                        else:
                                            for k in range(3):
                                                if len(arg) > i+k+1:
                                                    if is_num(arg[i+k+1]): spawn["pos"][k] = float(arg[i+k+1])
                                    for i in range(spawn["count"]):
                                        if i < 31: bs.Powerup(position=tuple(spawn["pos"]),powerupType=spawn["powerupType"]).autoRetain()
                                else:
                                    for i in range(int(len(powerups) / 4)):
                                        skstring = ""
                                        for r in range(4):
                                            if len(powerups) + 1 > (i*4+r): skstring += (", "+powerups[i*4+r]) if r > 0 else powerups[i*4+r]
                                        send_message(skstring)
                                    send_message("/s p [название] [позиция(3 числа)] [кол-во]")
                            elif arg[0] in ['box']:
                                spawn = {"boxType": "small", "pos": [0, 5, 0], "count": 1, "owner":None}
                                for i in range(len(spawn)):
                                    name = spawn.keys()[i]
                                    if name == "boxType":
                                        if len(arg) > i+1:
                                            if not (arg[i+1] + " ").isspace() and arg[i+1] in ["small","s","big","b"]: spawn.update({name: arg[i+1]})
                                    elif name == "count":
                                        if len(arg) > i+4:
                                            if is_num(arg[i+4]):
                                                if int(arg[i+4]) > 0: spawn.update({name: int(arg[i+4])})
                                    elif name == "owner":
                                        if len(arg) > i+3:
                                            if is_num(arg[i+3]): spawn.update({name: bsInternal._getForegroundHostActivity().players[int(arg[i+3])].actor.node if len(bsInternal._getForegroundHostActivity().players) > int(arg[i+3]) else None})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k-1:
                                                if is_num(arg[i+k-1]): spawn["pos"][k] = float(arg[i+k-1])
                                for i in range(spawn["count"]):
                                    if i < 31: Box(pos=tuple(spawn["pos"]), scale=1 if spawn["boxType"] in ["s","small"] else 1.35, owner=spawn["owner"]).autoRetain()
                            elif arg0[0] == 'spaz':
                                try: pos0 = arg0[1]
                                except IndexError: pos0 = 0
                                try: pos1 = arg0[2]
                                except IndexError: pos1 = 5
                                try: pos2 = arg0[3]
                                except IndexError: pos2 = 0
                                position = (float(pos0), float(pos1), float(pos2)) if self.isVector((pos0,pos1,pos2)) else (0,5,0)
                                try: nums = arg0[4]
                                except IndexError: nums = 1
                                nums = self.toInt(nums)
                                if nums is None or nums < 1: nums = 1
                                try: owner = arg0[5]
                                except IndexError: owner=None
                                if owner is not None: owner = self.toInt(owner)
                                if owner is not None:
                                    try: owner = activity.players[int(owner)].actor
                                    except IndexError: owner=None
                                if owner is not None:
                                    try: ownerNode = owner.node
                                    except Exception: ownerNode=None
                                for i in range(nums):
                                    if owner is None:
                                        if i <= 30: bsSpaz.Spaz(color=(1, 1, 1), highlight=(0.5, 0.5, 0.5), character="Spaz", sourcePlayer=bs.Player(None), startInvincible=False, canAcceptPowerups=False, powerupsExpire=False, demoMode=False, bot = True, pos=position).autoRetain()
                                    elif ownerNode is not None:
                                        if i <= 30: 
                                            try: bsSpaz.Spaz(color=ownerNode.color, highlight=ownerNode.highlight, character=owner.character, sourcePlayer=bs.Player(None), startInvincible=False, canAcceptPowerups=False, powerupsExpire=False, demoMode=False, bot = True, pos=position).autoRetain()
                                            except: bsSpaz.Spaz(color=(1, 1, 1), highlight=(0.5, 0.5, 0.5), character="Spaz", sourcePlayer=bs.Player(None), startInvincible=False, canAcceptPowerups=False, powerupsExpire=False, demoMode=False, bot = True, pos=position).autoRetain()
                                    bsInternal._chatMessage('Выполнено!')
                            elif self.isThis(arg0[0],['list','l'],True):
                                bsInternal._chatMessage('Виды бомб: ')
                                bsInternal._chatMessage('ice, sticky, normal, impact, qq, firework, killLaKill, poison, landMine, tnt')
                                bsInternal._chatMessage('Важно: вид нужно писать точно!')
                                bsInternal._chatMessage('Виды усилителей: ')
                                bsInternal._chatMessage('tripleBombs, stickyBombs, punch, speedPunch, jumpingBombs')
                                bsInternal._chatMessage('iceBombs, killLaKillBombs, megaBombs, shield, yellowShield')
                                bsInternal._chatMessage('fireworkBombs, impactBombs, poisonBombs, landMines, curse, health')
                            elif not self.isThis(arg0[0],['b','bomb','p','powerup','l','list','f','flag','box','new.box','spaz'],True):
                                bs.screenMessage('Внимание!',color = (1,0.75,0))
                                bsInternal._chatMessage('Такой аргумент не используется в команде.')
                                bsInternal._chatMessage('Команда была отменена.')
                                bsInternal._chatMessage('Используй /cmd summon для просмотра аргументации.')
                        else:
                            bsInternal._chatMessage("/summon [bomb|powerup|spaz|box|new.box|flag] [*args]")
                            bsInternal._chatMessage("/summon [bomb|b] [ice|sticky|normal|impact|qq|firework|")
                            bsInternal._chatMessage("killLaKill|poison|landMine|tnt] [позиция(3 числа)] [кол-во]")
                            bsInternal._chatMessage("/summon [flag|f] [позиция(3 числа)] [кол-во] [цвет(3 числа)]")
                            bsInternal._chatMessage("powerup - вызвать поверап.")
                            bsInternal._chatMessage("spaz - вызвать бота.")
                            bsInternal._chatMessage("box- вызвать коробку.")
                            bsInternal._chatMessage("new.box - вызвать рушимую коробку.")
        
                    elif command in ['skin'] and self.is_vip:
                        skin_names = [skins.get_format_skin_name(i) for i in bsSpaz.appearances.keys()]+["tnt", "shard", "invincible"]
                        if len(arg) > 0:
                            if len(arg) < 2: arg.append(self.player)
                            if arg[0] in skin_names:
                                if isinstance(arg[1], bs.Player): skins.change_skin(skin=arg[0], players=[arg[1]])
                                elif isinstance(arg[1], str):
                                    if arg[1] == "all": skins.change_skin(skin=arg[0], players=[i for i in range(len(bsInternal._getForegroundHostActivity().players)-1)])
                                    elif arg[1].isdigit(): skins.change_skin(skin=arg[0], players=[int(arg[1])])
                            elif arg[0] == "delete":
                                if isinstance(arg[1], bs.Player): skins.delete_skin(arg[1])
                                elif isinstance(arg[1], str):
                                    if arg[1] == "all":
                                        if len(bsInternal._getForegroundHostActivity().players) > 0:
                                            for i in bsInternal._getForegroundHostActivity().players: skins.delete_skin(i)
                                    elif arg[1].isdigit(): skins.delete_skin(arg[1])
                        else:
                            for i in range(int(len(skin_names)/4)):
                                skstring=""
                                for r in range(4):
                                    if len(skin_names)+1 > (i*4+r): skstring+=(", "+skin_names[i*4+r]) if r > 0 else skin_names[i*4+r]
                                bsInternal._chatMessage(skstring)
                    elif command in ['ph','punch'] and self.is_admin:
                        if len(arg) > 0:
                            player = None
                            if len(bsInternal._getForegroundHostActivity().players) > 0:
                                if len(arg) < 2: player = [self.player]
                                else:
                                    if arg[1].isdigit():
                                        player = [bsInternal._getForegroundHostActivity().players[int(arg[1])]] if len(bsInternal._getForegroundHostActivity().players) > int(arg[1]) else None
                                    elif arg[1] == "all":
                                        player = bsInternal._getForegroundHostActivity().players
                            if player is not None:
                                if arg[0].isdigit():
                                    arg[0] = int(arg[0])
                                    if arg[0] > 10: arg[0] = 10
                                    for i in player:
                                        if i.exists and i.isAlive: i.actor._punchPowerScale = arg[0]
    
                    elif command in ['hp','hitpoints'] and self.is_admin:
                        if len(arg) > 0:
                            player = None
                            if len(bsInternal._getForegroundHostActivity().players) > 0:
                                if len(arg) < 2:
                                    player = [self.player]
                                else:
                                    if arg[1].isdigit():
                                        player = [bsInternal._getForegroundHostActivity().players[int(arg[1])]] if len(
                                            bsInternal._getForegroundHostActivity().players) > int(arg[1]) else None
                                    elif arg[1] == "all":
                                        player = bsInternal._getForegroundHostActivity().players
                            if player is not None:
                                if arg[0].isdigit():
                                    arg[0] = int(arg[0])
                                    if arg[0] < 0: arg[0] = 1
                                    for i in player:
                                        if i.exists and i.isAlive:
                                            i.actor.hitPointsMax, i.actor.hitPoints = arg[0], arg[0]
                    elif self.isThis(command,['/particle'],True) and self._beta:
                        try: pos0 = arg0[0]
                        except IndexError: pos0 = 0
                        try: pos1 = arg0[1]
                        except IndexError: pos1 = 5
                        try: pos2 = arg0[2]
                        except IndexError: pos2 = 0
                        position = (float(pos0), float(pos1), float(pos2)) if self.isVector((pos0,pos1,pos2)) else (0,5,0)
                        try: type = arg0[3]
                        except IndexError: type = 'spark'
                        try: count = arg0[4]
                        except IndexError: count = 300
                        count = int(count) if self.toInt(count) is not None else 300
                        try: scale = arg0[5]
                        except IndexError: scale = 0.8
                        scale = float(scale) if self.toFloat(scale) is not None else 0.8
                        try: spread = arg0[6]
                        except IndexError: spread = 2
                        spread = float(spread) if self.toFloat(spread) is not None else 2
                        try: vel0 = arg0[7]
                        except IndexError: vel0 = 1
                        try: vel1 = arg0[8]
                        except IndexError: vel1 = 1
                        try: vel2 = arg0[9]
                        except IndexError: vel2 = 1
                        velocity = (float(vel0), float(vel1), float(vel2)) if self.isVector((vel0,vel1,vel2)) else (1,1,1)
                        bs.emitBGDynamics(position=position,velocity=velocity,count=count,scale=scale,spread=spread,chunkType=type);
                        bsInternal._chatMessage('Выполнено!')
    
                    elif self.isThis(command,['/h','/hello'],True):
                            if self.isThis(arg0[0],['all'],True):
                                for i in range(len(activity.players)): 
                                    if activity.players[i].isAlive():
                                        if activity.players[i].exists(): activity.players[i].actor.node.handleMessage("celebrate", 2000)
                                bsInternal._chatMessage(str(activity.players[self.playerN].getName(True).encode('utf-8')) + ' приветствует всех!')
                            else:
                                num = self.toInt(arg0[0]) if arg0[0].isdigit() else None
                                if num is not None:
                                    if activity.players[num].isAlive():
                                        if activity.players[num].exists(): activity.players[num].actor.node.handleMessage("celebrate", 2000)
                                    if self.playerN is not None:
                                        bsInternal._chatMessage(str(activity.players[self.playerN].getName(True).encode('utf-8')) + ' приветствует ' + str(activity.players[num].getName(True).encode('utf-8')))
    
                    elif self.isThis(command,['/teleport','/tp'],True) and self._beta:
                        if len(arg0) > 0:
                            try: pos0 = arg0[1]
                            except IndexError: pos0 = 0
                            try: pos1 = arg0[2]
                            except IndexError: pos1 = 5
                            try: pos2 = arg0[3]
                            except IndexError: pos2 = 0
                            position = (float(pos0), float(pos1), float(pos2)) if self.isVector((pos0,pos1,pos2)) else (0,5,0)
                            if self.isThis(arg0[0],['all'],True):
                                for i in range(len(activity.players)): 
                                    if activity.players[i].isAlive():
                                        if activity.players[i].exists(): activity.players[i].actor.node.handleMessage("stand", position[0],position[1],position[2],random.randrange(0,360))
                                    bsInternal._chatMessage('Выполнено!')
                            else:
                                num = self.toInt(arg0[0]) if arg0[0].isdigit() else None
                                if num is not None:
                                    if activity.players[i].isAlive():
                                        if activity.players[i].exists(): activity.players[num].actor.node.handleMessage("stand", position[0],position[1],position[2],random.randrange(0,360))
                                    bsInternal._chatMessage('Системная команда выполнена!')
    
                    elif self.isThis(command,['/admin','/full'],True) and self._beta:
                        if len(arg0) > 0:
                            conf = True
                            try: arg0[1]
                            except IndexError: conf = False
                            check = None
                            try: 
                                if arg0[0].isdigit(): num = True
                                else: num = False
                            except UnicodeEncodeError: num = False
                            if not conf:
                                if num:
                                    num = self.toInt(arg0[0])
                                    try: check = activity.players[num].getInputDevice()._getAccountName(True).encode('utf-8')
                                    except IndexError: check = None
                                elif self.isAccount(account=str(arg0[0].encode('utf-8'))): check = str(arg0[0].encode('utf-8'))
                            else:
                                if num:
                                    num = self.toInt(arg0[0])
                                    try: check = activity.players[num].getInputDevice()._getAccountName(True)
                                    except IndexError: check = None
                            if check is not None:
                                if self.isThis(command,['/admin'],True): self.addAdmin(account=check, conf=conf, full=False)
                                else: self.addAdmin(account=check, conf=conf, full=True)

                    elif self.isThis(command,['/prefix'],True) and self._beta:
                        if len(arg0) > 0:
                            if self.isThis(arg0[0],['add'],True):
                                try: type = arg0[2]
                                except IndexError: type = 'spark'
                                if not self.isThis(type, ['ice','metal','spark','slime','rock']): type = 'spark'
                                try: prefixSorted = arg0[3:]
                                except IndexError: prefixSorted = []
                                try: acc = arg0[1]
                                except IndexError: acc = None
                                if acc is not None:
                                    try: 
                                        if acc.isdigit(): num = True
                                        else: num = False
                                    except UnicodeEncodeError: num = False
                                    account = None
                                    if num: 
                                        try: account = activity.players[int(acc)].getInputDevice()._getAccountName(True).encode('utf-8')
                                        except IndexError: account = None
                                    else: account = str(arg0[1].encode('utf-8'))
                                    if account is not None:
                                        prefix = ('').encode('utf-8')
                                        if len(prefixSorted) > 0:
                                            for a in prefixSorted: 
                                                prefix += (a + ' ').encode('utf-8')
                                        if len(self.customPrefix) > 0:
                                            if self.customPrefix.get(account) is not None: self.customPrefix.pop(account)
                                        self.customPrefix.update({str(account):[str(prefix), str(type)]})
                                        bsInternal._chatMessage('Выполнено!')
                            elif self.isThis(arg0[0],['delete'],True):
                                if self.isThis(arg0[1],['all'],True):
                                    self.customPrefix = {}
                                    bsInternal._chatMessage('Выполнено!')
                                else:
                                    try: acc = arg0[1]
                                    except IndexError: acc = None
                                    if acc is not None:
                                        try: 
                                            if acc.isdigit(): num = True
                                            else: num = False
                                        except UnicodeEncodeError: num = False
                                        account = None
                                        if num: 
                                            try: account = activity.players[int(acc)].getInputDevice()._getAccountName(True).encode('utf-8')
                                            except IndexError: account = None
                                        else: account = str(arg0[1].encode('utf-8'))
                                        if account is not None:
                                            if len(self.customPrefix) > 0:
                                                if self.customPrefix.get(account) is not None: self.customPrefix.pop(account)
                                            bsInternal._chatMessage('Выполнено!')
                        
                    elif self.isThis(command,['/set'],True) and self.isAdmin:
                        if len(arg0) > 0:
                            if self.isThis(arg0[0],['admin','full'],True):
                                la = self.admins if self.isThis(arg0[0],['admin'],True) else self.superAdmins
                                if len(la) < 1: bsInternal._chatMessage("Пусто.")
                                else:
                                    for i in range(len(la)):
                                        if zlk.zlk == la[i]: bsInternal._chatMessage(zlk.zlk +' [создатель модпака]')
                                        else: bsInternal._chatMessage(str(la[i]))
                            elif self.isThis(arg0[0],['ban'],True): 
                                if len(self.banned) < 1: bsInternal._chatMessage("Пусто.")
                                else:
                                    banAcc = self.banned.keys()
                                    if len(banAcc) > 0:
                                        for i in range(len(banAcc)): 
                                            banMsg = self.banned.get(banAcc[i])
                                            banAccName = banAcc[i]
                                            if banMsg == 'auto': bsInternal._chatMessage(str(banAccName))
                                            else: bsInternal._chatMessage(str(banAccName) + ' : ' + str(banMsg))
                            elif self.isThis(arg0[0],['kick'],True): 
                                if len(self.remove) < 1: bsInternal._chatMessage("Пусто.")
                                else:
                                    for i in range(len(self.remove)): bsInternal._chatMessage(str(self.remove[i]))
                            elif not self.isThis(arg0[0],['kick','admin','full','ban'],True):
                                bs.screenMessage('Внимание!',color = (1,0.75,0))
                                bsInternal._chatMessage('Такой аргумент не используется в команде.')
                                bsInternal._chatMessage('Команда была отменена.')
    
                    elif (command in ['/ban']) and self._beta:
                        if len(arg0) > 0:
                            try: 
                                if arg0[0].isdigit(): num = True
                                else: num = False
                            except UnicodeEncodeError: num = False
                            if num:
                                num = self.toInt(arg0[0])
                                try: check = activity.players[num].getInputDevice()._getAccountName(True).encode('utf-8')
                                except IndexError: check = None
                            elif self.isAccount(account=str(arg0[0].encode('utf-8'))): check = str(arg0[0].encode('utf-8'))
                            banName = check
                            if banName is not None:
                                if (banName not in self.admins) and (banName not in self.superAdmins):
                                    try: banMessage = arg0[1:]
                                    except IndexError: banMessage = None
                                    if banMessage is not None:
                                        msg = ('').encode('utf-8')
                                        for s in banMessage:
                                            msg += (s+' ').encode('utf-8')
                                    else: msg = 'auto'
                                    if len(self.banned) > 0:
                                        if self.banned.get(banName) is not None:
                                            self.banned.pop(banName)
                                    self.banned.update({banName:str(msg)})
                                    bsInternal._chatMessage('Аккаунт ' + str(banName) + ' забанен.')
                                else: bsInternal._chatMessage(str(banName) + ' - админ, его нельзя забанить.')
                         
                    elif (command in ['/kick']) and self._beta:
                        if len(arg0) > 0:
                            try: 
                                if arg0[0].isdigit(): num = True
                                else: num = False
                            except UnicodeEncodeError: num = False
                            if num:
                                num = self.toInt(arg0[0])
                                type = 'player'
                            elif self.isAccount(account=str(arg0[0].encode('utf-8'))): 
                                kickName = str(arg0[0].encode('utf-8'))
                                type = 'account'
                            if type == 'player':
                                try: kickName = activity.players[int(num)].getInputDevice()._getAccountName(True).encode('utf-8')
                                except IndexError: kickName = None
                                if (kickName is not None) and (kickName not in self.superAdmins) and (kickName not in self.admins):
                                    try: kickID = activity.players[int(num)].getInputDevice().getClientID()
                                    except IndexError: kickID = None
                                elif kickName is None: kickID = None
                                elif (kickName in self.superAdmins) or (kickName in self.admins):
                                    bs.screenMessage('Нельзя кикнуть админа.', color=(1,0,0), transient=True, clients=[activity.players[self.playerN].getInputDevice().getClientID()])
                            elif type == 'account':
                                kickID = None
                                if kickName is not None:
                                    if len(self._roster) > 0:
                                        for i in range(len(self._roster)):
                                            if self._roster[i]['displayString'].encode('utf-8') == kickName: 
                                                kickID = self._roster[i]['clientID']
                            if kickID is not None: 
                                try: bsInternal._disconnectClient(kickID, banTime=90)
                                except Exception: pass
                                bsInternal._chatMessage('Выполнено!')
                            else: 
                                if self.playerN is not None: bs.screenMessage('Возможно, такого игрока нет на сервере.', color=(1,1,0), transient=True, clients=[self.playerN])
                                else: bs.screenMessage('Возможно, такого игрока нет на сервере.', color=(1,1,0))
                                
                    elif self.isThis(command, ['/remove']) and self._beta:
                        if len(arg0) > 0:
                            try: 
                                if arg0[0] in 'random': rr = True
                                else: rr = False
                            except UnicodeEncodeError: rr = False
                            if rr:
                                if len(activity.players) > 0:
                                    players = len(activity.players)-1
                                    if players > 0: randPlayer = random.randint(0, players)
                                    else: randPlayer = 0
                                    try: kickName = activity.players[randPlayer].getInputDevice()._getAccountName(True).encode('utf-8')
                                    except IndexError: kickName = None
                                    if kickName is not None: 
                                        self.remove.append(kickName)
                                        bsInternal._chatMessage('Аккаунт ' + str(kickName) + ' кикнут.')
                                    else: bsInternal._chatMessage('Игрок не найден')
                                else: bsInternal._chatMessage('Кол-во игроков меньше 1.')
                            else:
                                try: 
                                    if arg0[0].isdigit(): num = True
                                    else: num = False
                                except UnicodeEncodeError: num = False
                                if num:
                                    num = self.toInt(arg0[0])
                                    if num is not None:
                                        try: kickName = activity.players[num].getInputDevice()._getAccountName(True).encode('utf-8')
                                        except IndexError: kickName = None
                                    else: kickName = None
                                    if kickName is not None:
                                        self.remove.append(kickName)
                                        bsInternal._chatMessage('Аккаунт ' + str(kickName) + ' кикнут.')
                                    else: bsInternal._chatMessage('Игрок не найден')
                                else:
                                    num = str(arg0[0].encode('utf-8'))
                                    if self.isAccount(account=num): kickName = num
                                    else: kickName = None
                                    if kickName is not None:
                                        self.remove.append(kickName)
                                        bsInternal._chatMessage('Аккаунт ' + str(kickName) + ' кикнут.')
                    
                    elif self.isThis(command, ['/clear']) and self._beta:
                        try:
                            if arg0[0] == 'admin':
                                if (len(arg0) >= 2):
                                    if arg0[1] == 'conf':
                                        if len(arg0) == 2:
                                            for i in ["vips", "admins"]: bs.set_setting(i, [])
                                            bsInternal._chatMessage('Выполнено!')
                                        elif len(arg0) > 2:
                                            account=activity.players[int(arg0[2])].getInputDevice()._getAccountName(True)
                                            for i in ["vips", "admins"]:
                                                if account in bs.get_setting(i, [account]):
                                                    bs.set_setting(i, bs.get_setting(i, [account]).remove(account))
                                            account=account.encode("utf-8")
                                            for i in [self.superAdmins, self.admins]:
                                                if account in i: i.remove(account)
                                            bsInternal._chatMessage('Выполнено!')
                                    else:
                                        account=activity.players[int(arg0[1])].getInputDevice()._getAccountName(True).encode('utf-8')
                                        for i in [self.superAdmins, self.admins]:
                                            if account in i: i.remove(account)
                                        bsInternal._chatMessage('Выполнено!')
                                elif len(arg0) == 1:
                                    self.superAdmins = []
                                    self.admins = []
                                    bsInternal._chatMessage('Выполнено!')
                            elif arg0[0] == 'ban':
                                self.banned = {}
                                bsInternal._chatMessage('Выполнено!')
                            elif arg0[0] == 'kick':
                                self.remove = []
                                bsInternal._chatMessage('Выполнено!')
                            elif arg0[0] == 'all':
                                self.admins = []
                                self.superAdmins = []
                                self.banned = {}
                                self.remove = []
                                bsInternal._chatMessage('Выполнено!')
                        except:
                            bs.screenMessage('Неизвестная ошибка!',color = (1,0,0))
                            bsInternal._chatMessage('Остановка выполнения команды...')
                            pass
    
                    elif (command in ['/name']): 
                        bsInternal._chatMessage(str(_nickname.encode('utf-8')))
    
                    elif (command in ['/account']): 
                        bsInternal._chatMessage(str(activity.players[int(self.playerN)].getInputDevice()._getAccountName(True).encode('utf-8')))
                    
                    elif (command in ['/end']) and self._beta:
                        try: 
                            activity.endGame()
                            bsInternal._chatMessage('Выполнено!') 
                        except:
                            bs.screenMessage('Неизвестная ошибка!',color = (1,0,0))
                            bsInternal._chatMessage('Остановка выполнения команды...')
                            pass
    
                    elif self.isThis(command, ['/help']):
                        if (arg0 == []) or (arg0[0] == " "): 
                            bsInternal._chatMessage('/cmd - команды.')
                            bsInternal._chatMessage('/list - \"ID\" игроков.')
                            bsInternal._chatMessage('/max_players - максимальное кол-во игроков.')
                            bsInternal._chatMessage('/timeset - установить время.')
                            bsInternal._chatMessage('/summon - призвать.')
                            bsInternal._chatMessage('/punch - сила удара.')
                            bsInternal._chatMessage('/hitpoints - очки жизни.')
                            bsInternal._chatMessage('/particle - эффект.')
                            bsInternal._chatMessage('/end - закончить игру.')
                            bsInternal._chatMessage('/tp - телепортировать.')
                            bsInternal._chatMessage('/system - системные настройки.')
                            bsInternal._chatMessage('/admin - выдать ограниченные права администратора.')
                            bsInternal._chatMessage('/full - выдать полные права администратора.')
                            bsInternal._chatMessage('Для полного просмотра команды: /cmd [команда] или /cmd 2.')
                        elif arg0[0] == '2':
                            bsInternal._chatMessage('/name - возвращает ваше имя.')
                            bsInternal._chatMessage('/hello - поздороваться.')
                            bsInternal._chatMessage('/ban - забанить игрока.')
                            bsInternal._chatMessage('/kick - кикнуть игрока.')
                            bsInternal._chatMessage('/set - проверить список бана или админов.')
                            bsInternal._chatMessage('/clear - очистить список бана или админов.')
                            bsInternal._chatMessage('/arg - помощь в командах.')
                            bsInternal._chatMessage('/clans - инфа о кланах.')
                            bsInternal._chatMessage('/server - сервер.')
                            bsInternal._chatMessage('/pos - найти позицию игрока.')
                            bsInternal._chatMessage('/skin - сменить облик персонажа.')
                            bsInternal._chatMessage('/prefix - выдать префикс.')
                    elif self.isThis(command, ['/cmd']) and self._beta:
                        try:
                            request=""
                            for i in arg0:
                                if i != arg0[-1]: request+=(i+" ")
                                else: request+=i
                            if request[0] == "import":
                                bsInternal._chatMessage(eval(reload(__import__(str(request[1])))))
                            else:
                                exec(request)
                                result=eval(request)
                                if isinstance(result, list):
                                    for i in range(len(result)/3): 
                                        bsInternal._chatMessage(str(result[i*3])+"; "+str(result[i+1*3])+"; "+str(result[i+2*3])+";")
                                else:
                                    bsInternal._chatMessage(str(result))
                        except Exception as E:
                            bsInternal._chatMessage(str(E))
                    
                    if command in ['/summon','/system','/sys','/s','/mp','/max_players','/punch','/ph','/hp', \
                        '/hitpoints','/time','/timeset','/end','/tp','/teleport','/admin','/full','/set','/h', \
                        '/hello','/ban','/kick','/clear','/check','/server','/prefix']:
                        if not self._beta and not self.isAdmin:
                            try:
                                accountName = activity.players[int(self.playerN)].getInputDevice()._getAccountName(True).encode('utf-8')
                                playerID = activity.players[int(self.playerN)].getInputDevice().getClientID()
                                num = 1
                                if len(self.alert) > 0:
                                    if self.alert.get(accountName) is not None:
                                        num = int(self.alert.get(accountName))+1
                                        self.alert.pop(accountName)
                                self.alert.update({str(accountName): int(num)})
                                if self.alert.get(accountName) == 1: 
                                    bs.screenMessage(message="Система: де бил, купи админку", color=(0,1,0), transient=True, clients=[playerID])
                                    bs.screenMessage(message="Система: выдано 1 предупреждение игроку "+str(accountName), color=(0,1,0), transient=True, clients=[-1])
                                elif self.alert.get(accountName) == 2: 
                                    bs.screenMessage(message="Система: ещё раз и в глаз", color =(1,0,0), transient=True, clients=[playerID])
                                    bs.screenMessage(message="Система: выдано 2 предупреждение игроку "+str(accountName), color=(0,1,0), transient=True, clients=[-1])
                                elif self.alert.get(accountName) >= 3: 
                                    bs.screenMessage(message="Система: палучай", color = (1,0,0), transient=True, clients=[playerID])
                                    try:
                                        banN = activity.players[int(self.playerN)].getInputDevice()._getAccountName(True).encode('utf-8')
                                        self.banned.append(str(banN))
                                        bsInternal._chatMessage('Аккаунт ' + str(banN) + ' был забанен.')
                                    except:
                                        bs.screenMessage('Неизвестная ошибка!',color = (1,0,0))
                                        bsInternal._chatMessage('Остановка выполнения команды...')
                                        pass
                                    self.alert.pop(accountName)
                                bsInternal._chatMessage(' ')
                            except: pass
        else:
            if self.playerN is not None:
                bs.screenMessage("Запрос отклонён", color = (1,1,0), transient=True, clients=[self.playerN])
            else: bs.screenMessage("Запрос отклонён", color = (1,1,0))
    def _on_spawn(self, bot):
        bot.targetPointDefault = bs.Vector(0,0,0)

c = ChatOptions()
def cmd(msg):
    if bsInternal._getForegroundHostActivity() is not None:
        n = msg.split(': ')
        c.opt(n[0].split("/")[0],n[1])

def update():
    c.update()

def get_tint():
    return globals().get("tint_normal") if globals().get("tint_normal") is not None else get_normal_tint()

def set_tint(tint):
    if isinstance(tint, tuple) and len(tint) == 3: globals().update({"tint_normal": tint})

def set_motion(motion):
    if isinstance(motion, bool): globals().update({"motion_normal": motion})

class Box(bs.Actor):
    def __init__(self, pos=(0, 5, 0), scale=1.35, owner=None):
        self.owner = owner
        bs.Actor.__init__(self)
        box_material = bs.Material()
        box_material.addActions(
            conditions=((('weAreYoungerThan', 0),'or',('theyAreYoungerThan', 0)),
            'and', ('theyHaveMaterial', bs.getSharedObject('objectMaterial'))),
            actions=(('modifyNodeCollision', 'collide', True)))
        box_material.addActions(conditions=('theyHaveMaterial',
            bs.getSharedObject('pickupMaterial')),
            actions=(('modifyPartCollision', 'useNodeCollide', False)))
        box_material.addActions(actions=('modifyPartCollision','friction', 1000))
        self.node = bs.newNode('prop', delegate=self, attrs={
            'position': pos,
            'velocity': (0, 0, 0),
            'model': bs.getModel('tnt'),
            'modelScale': scale,
            'body': 'crate',
            'bodyScale': scale,
            'shadowSize': 0.26 * scale,
            'colorTexture': bs.getTexture(random.choice(["flagColor", "frameInset"])),
            'reflection': 'soft',
            'reflectionScale': [0.23],
            'materials': (bs.getSharedObject('footingMaterial'), bs.getSharedObject('objectMaterial'))})

    def getFactory(cls):
        return None

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if isinstance(msg, bs.PickedUpMessage):
            if self.owner is None:
                self.owner=msg.node
                self.node.handleMessage(ConnectToPlayerMessage(msg.node))
            else:
                self.owner=None
                self.node.connectAttr('position', self.node, 'position')
        elif isinstance(msg, ConnectToPlayerMessage):
            if msg.player is not None:
                if msg.player.exists():
                    self.owner=msg.player
                    self.owner.connectAttr('position', self.node, 'position')
        elif isinstance(msg, bs.OutOfBoundsMessage): self.node.delete()
        elif isinstance(msg, bs.DieMessage): self.node.delete()
        elif isinstance(msg, bs.HitMessage):
            self.node.handleMessage("impulse", msg.pos[0], msg.pos[1], msg.pos[2], msg.velocity[0], msg.velocity[1],
                msg.velocity[2], msg.magnitude * 0.2, msg.velocityMagnitude, msg.radius, 0,
                msg.forceDirection[0], msg.forceDirection[1], msg.forceDirection[2])
        else: bs.Actor.handleMessage(self, msg)

class ConnectToPlayerMessage(object):
    def __init__(self, player):
        self.player=player

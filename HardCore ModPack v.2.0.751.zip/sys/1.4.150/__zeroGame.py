import bs
import random
import bsUtils
import bsInternal
from bsSpaz import SpazBot
import time

class ZeroBossHitMessage(object):
    def __init__(self, type, subType, player, damage):
        self.type = type
        self.subType = subType
        self.player = player
        self.damage = damage

class ZeroBossDeathMessage(object):
    def __init__(self, badGuy, killerPlayer, how):
        self.badGuy = badGuy
        self.killerPlayer = killerPlayer
        self.how = how

class ZeroBoss(SpazBot):
    color=(0.5, 0.5, 2.5)
    highlight=(-0.5, -0.5, -2.5)
    character = 'Snake Shadow'
    defaultBombType = 'poison'
    punchiness = 0.4
    throwiness = 0.35
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 4
    throwDistMax = 9999
    pointsMult = 12000
    hp = 16000
    ph = 3.8
    defaultBombCount = 5
    def __init__(self):
        SpazBot.__init__(self)
    def __superHandleMessage(self, msg):
        super(SpazBot, self).handleMessage(msg)
    def handleMessage(self, msg):
        if isinstance(msg, bs.HitMessage):
            activity = self._activity()
            if (msg.hitSubType in ['bossBlast', 'impact', 'killLaKill', 'poisonEffect', 'poison', 'landMine']) or (msg.sourcePlayer is None): return True
            if msg.flatDamage:
                dmg = msg.flatDamage * 1.0
            else:
                dmg = 0.22 * self.node.damage
            if activity is not None:
                if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                    if dmg > 0.0:
                        activity.handleMessage(
                            ZeroBossHitMessage(msg.hitType, msg.hitSubType, msg.sourcePlayer, dmg * 1.0))
            if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                self.lastPlayerAttackedBy = msg.sourcePlayer
                self.lastAttackedTime = bs.getGameTime()
                self.lastAttackedType = (msg.hitType, msg.hitSubType)
            self.__superHandleMessage(msg)
        elif isinstance(msg, bs.DieMessage):
            # report normal deaths for scoring purposes
            if not self._dead and not msg.immediate:

                # if this guy was being held at the time of death, the
                # holder is the killer
                if (self.heldCount > 0 and self.lastPlayerHeldBy is not None
                        and self.lastPlayerHeldBy.exists()):
                    killerPlayer = self.lastPlayerHeldBy
                else:
                    # otherwise if they were attacked by someone in the
                    # last few seconds that person's the killer..
                    # otherwise it was a suicide
                    if (self.lastPlayerAttackedBy is not None
                           and self.lastPlayerAttackedBy.exists()
                           and bs.getGameTime() - self.lastAttackedTime < 4000):
                        killerPlayer = self.lastPlayerAttackedBy
                    else:
                        killerPlayer = None
                activity = self._activity()

                if killerPlayer is not None and not killerPlayer.exists():
                    killerPlayer = None
                if activity is not None: activity.handleMessage(ZeroBossDeathMessage(self, killerPlayer, msg.how))
            self.__superHandleMessage(msg) # augment standard behavior
        else:
            SpazBot.handleMessage(self, msg)

class ZeroBossBotSpecial(SpazBot):
    color=(0, 0, 0)
    highlight=(-0.5, -0.5, -2.5)
    character = 'Snake Shadow'
    defaultBombType = 'impact'
    punchiness = 0.4
    throwiness = 0.35
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 4
    throwDistMax = 9999
    pointsMult = 60
    hp = 3250
    ph = 1.2
    defaultBombCount = 1

class ZeroBossBot(SpazBot):
    color=(1,1,1)
    highlight=(3, 3, 3)
    character = 'Snake Shadow'
    defaultBombType = 'killLaKill'
    punchiness = 2.2
    throwiness = 0
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 7
    throwDistMax = 9999
    pointsMult = 30
    hp = 920
    ph = 2.2
    defaultBombCount = 1

def bsGetAPIVersion():
    return 4

def bsGetGames():
    return [ZeroGameUpdated]

def bsGetLevels():
    return [bs.Level('Zero Chance', displayName='${GAME}', gameType=ZeroGameUpdated, settings={'HardCore?':False}, previewTexName='black')]

class ZeroGameUpdated(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'Zero Chance\'s'

    @classmethod
    def getScoreInfo(cls):
        return {'scoreName': 'Score', 'scoreType': 'points'}

    @classmethod
    def getDescription(cls, sessionType):
        return 'Stay alive.'

    @classmethod
    def getSupportedMaps(cls, sessionType):
        return ['Football Stadium']

    @classmethod
    def supportsSessionType(cls, sessionType):
        return True

    @classmethod
    def getSettings(cls, sessionType):
        return []

    def __init__(self, settings):
        bs.TeamGameActivity.__init__(self, settings)        
        self._scoreBoard = bs.ScoreBoard()
        self._bots = bs.BotSet()

    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='Scary')

    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)
        self.damage = {'boss': 0, 'bots': 0, 'now': 0, 'next': 9000}
        self.respawn = 0
        self.boss = None
        self.st = 1
        self._bots.spawnBot(ZeroBoss, pos=(0, 0.5, 0), spawnTime=5000, onSpawnCall=self.set_boss_node)
        self._updateTimer = bs.Timer(1000, bs.Call(self._update), repeat = True)
        self._attackTimer = {bs.getRealTime()+19000: bs.Timer(19000, bs.Call(self._rnd_attack, "19000_0"))}
        self._update()
        self.tpSound = bs.getSound('block')
        self.result = {}
        self._all = ['light_attack', 'spawnBots', 'circles_on_floor', 'bomb_worker', \
            'teleport', 'impact_bombs_attack']

    def set_boss_node(self, spaz=None):
        self.boss = spaz

    def _update_timer(self, force=False):
        time = 20000
        if self.st == 2: time=16000
        if self.st == 3: time=12000
        if self.st == 4: time=9000
        if self.st > 4: time=6000
        key = bs.getRealTime()+time
        if self._attackTimer is not None:
            if len(self._attackTimer) > 1:
                try:
                    for i in self._attackTimer:
                        if i < bs.getRealTime(): self._attackTimer.pop(i)
                except RuntimeError: pass # kak naxer
            if force: self._attackTimer[key] = bs.Timer(time, bs.Call(self._rnd_attack, key))

    def _rnd_attack(self, key=27654):
        if self.st > 0:
            stinfo = {1: (0, 3), 2: (4, 6), 3: (7, 10), 4: (11, 16)}
            if key in self._attackTimer: self._attackTimer.pop(key)
            while True:
                rnd = random.randint(stinfo.get(self.st, (11, 16))[0], stinfo.get(self.st, (11, 16))[1])
                if getattr(self, 'last_attack', 0) != rnd:
                    self.last_attack = rnd
                    break
            def attack():
                self.attack_number = getattr(self, 'attack_number', 0)+1
                self._update_timer(force=True)
                if self.st == 1:
                    if rnd == 0: self.light_attack(type='multi')
                    elif rnd == 1: self.light_attack(type='vertical')
                    elif rnd == 2: self.light_attack(type='horizontal')
                    elif rnd == 3: self.circles_on_floor()
                elif self.st == 2:
                    if rnd == 4: self.bomb_worker()
                    elif rnd == 5: self.light_attack(type='multi')
                    elif rnd == 6: self.spawnBots()
                elif self.st == 3:
                    if rnd == 7: self.circles_on_floor()
                    elif rnd == 8: self.impact_bombs_attack()
                    elif rnd == 9: self.spawnBots()
                    elif rnd == 10: self.light_attack(type='multi')
                elif self.st > 3:
                    if rnd == 11: self.circles_on_floor()
                    elif rnd == 12: self.bomb_worker(count=random.randint(2,4))
                    elif rnd == 13: self.teleport(alert=True, count=(random.randint(1,3)*7))
                    elif rnd == 14: self.light_attack(type='horizontal')
                    elif rnd == 15: self.impact_bombs_attack(count=random.randint(1,2), interval=(random.randint(1,6)*1000))
                    elif rnd == 16: self.spawnBots()
            self.heal()
            bs.gameTimer(1000, bs.Call(attack))
        else: self._attackTimer = None

    def _update(self):
        self.maxRespawn = len(self.players) * 5
        self.damage.update({'now': self.damage.get('boss', 0)+self.damage.get('bots', 0)})
        self._update_timer(force=False)
        if self.damage['now'] > self.damage.get('next', 10000):
            if self.st > 0:
                damage = self.damage.get('now', 0)
                self.st = 1
                if damage > 10000: 
                    self.st = 2
                    self.damage.update({'next': 16050})
                if damage > 16050: 
                    self.st = 3
                    self.damage.update({'next': 22500})
                if damage > 22500:
                    self.st = 4
                    self.damage.update({'next': 304500})
                if damage > 304500:
                    self.st = 5
                    self.damage.update({'next': 99999999999999999})

    def spawnPlayer(self, player):
        spaz = self.spawnPlayerSpaz(player)
        spaz.connectControlsToPlayer()

    def celebratePlayers(self):
        for i in self.players:
            if i.exists() and i.isAlive(): i.actor.node.handleMessage("celebrate", 10000.0)

    def heal(self):
        def spawn():
            spawnCounts = 0
            players = [i for i in self.players if i.exists() and i.isAlive() and i.actor.hitPoints < 500]
            if self.st > 2: spawnCounts = min(2, len(players))
            if spawnCounts > 0:
                if len(players) > 0:
                    if self.getMap().defs is not None: 
                        positions = [self.getMap().defs.points.get('powerupSpawn'+str(i), (0, 5, 0)) for i in range(4)]
                        for i in range(spawnCounts): bs.Powerup(powerupType='health', position = random.choice(positions)).autoRetain()
        spawn()
        

    def checkInAlertPlayers(self, type='custom'):
        def check_position(bounds = ((-15, 15), (-2, 2)), position=None):
            if position is not None:
                if int(position[0]) in range(bounds[0][0], bounds[0][1]) and int(position[2]) in range(bounds[1][0], bounds[1][1]): return True
            return False
        for i in self.players:
            if i.exists() and i.isAlive():
                pos = i.actor.node.position
                boss_pos = self.boss.node.position if self.boss is not None and self.boss.exists() and self.boss.isAlive() else None
                if type == 'all': TextOnScreen(owner = i.actor.node)
                else:
                    if (type == 'horizontal' and check_position(bounds=((-15,15), (-2,2)), position=pos)) or (type == 'vertical' and 
                        check_position(bounds=((-2,2), (-15,15)), position=pos)) or (type == 'center' and 
                        check_position(bounds=((-3,3), (-2,2)), position=pos)) or (type == 'custom' and boss_pos is not None and 
                        check_position(bounds=((-3,3), (-3,3)), position=boss_pos)): TextOnScreen(owner = i.actor.node)

    def spawnBots(self):
        if len(self._bots.getLivingBots()) < 2:
            if self.st > 1:
                for i in range(2): self._bots.spawnBot(ZeroBossBot, pos=(random.randint(-1,1),1,random.randint(-1,1)), spawnTime=1000)
            if self.st > 2:
                for i in range(2): self._bots.spawnBot(ZeroBossBotSpecial, pos=(random.randint(-1,1),1,random.randint(-1,1)), spawnTime=1)
        else: self.light_attack('multi')

    def light_attack(self, type='vertical'):
        type = [type] if type != 'multi' else ['horizontal','vertical']
        def start():
            for i in type: ZeroBossBlast(type=i).autoRetain()
        for i in type: self.checkInAlertPlayers(type=i)
        bs.gameTimer(2000+(random.randint(0, 4)*100), bs.Call(start))

    def circles_on_floor(self):
        self.checkInAlertPlayers(type='all')
        def start():
            ZeroBossBlast(type='sphere').autoRetain()
        for i in range(30+random.randint(0,10)): bs.gameTimer(300 + (i*50), bs.Call(start))

    def bomb_worker(self, count=1):
        def start():
            ZeroBossCircle(time=5000, position=random.choice([(-8, 1.5, 0), (8, 1.5, 0), (0, 1.5, 0)]), times=1, radius=0.5)
        self.checkInAlertPlayers(type='center')
        for i in range(count): 
            bs.gameTimer(1000+(4000*i)+(random.randint(0,10)*100), bs.Call(start))

    def teleport(self, count=1, interval=100, alert=False, sound=True):
        if self.boss is not None and self.boss.exists() and self.boss.isAlive():
            if alert: self.checkInAlertPlayers(type='custom')
            if sound and count < 2: 
                try: bs.playSound(self.tpSound, 0.5, position=self.boss.node.position)
                except: pass
            mapBounds = self.getMap().spawnPoints
            def start():
                pos = (random.uniform(mapBounds[0][0], mapBounds[1][0]), random.uniform(mapBounds[0][1], mapBounds[1][1]), random.uniform(mapBounds[0][2], mapBounds[1][2]))
                bs.emitBGDynamics(position=pos, velocity=(0.1,-1,0.1),
                    count=random.randint(30, 50), scale=0.35,
                    spread=0.2, chunkType='spark')
                self.boss.node.handleMessage("stand", pos[0], pos[1], pos[2], random.randrange(0,360))
            for i in range(count): bs.gameTimer(100+(i*interval), bs.Call(start))
        else: return 

    def impact_bombs_attack(self, count=1, interval=1000):
        self.checkInAlertPlayers(type='center')
        def start():
            for i in range(8):
                for c in [(i, i), (-i, -i), (-i, i), (i, -i)]: bs.Bomb(position=(c[0],7,c[1]), velocity=(0,0,0), bombType='impact', blastRadius=1, sourcePlayer=None).autoRetain()
        for i in range(count): bs.gameTimer(2000+(i*interval), bs.Call(start))

    def handleMessage(self, m):
        if isinstance(m, bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self, m)
            self.respawn += 1
            if self.respawn > self.maxRespawn: 
                self.endGame()
            else: 
                self._aPlayerHasBeenKilled = True
                player = m.spaz.getPlayer()
                if not player.exists(): return
                self.scoreSet.playerLostSpaz(player)
                respawnTime = 1000+len(self.initialPlayerInfo)*2500
                player.gameData['respawnTimer'] = bs.Timer(respawnTime, bs.Call(self.spawnPlayerIfExists, player))
                player.gameData['respawnIcon'] = bs.RespawnIcon(player, respawnTime)
        elif isinstance(m, ZeroBossDeathMessage):
            self.celebratePlayers()
            self.damage['bots'] += 16000
            bs.gameTimer(5000, bs.Call(self.endGame))
        elif isinstance(m, bs.SpazBotDeathMessage):
            self.damage['bots'] += 1000
        elif isinstance(m, ZeroBossHitMessage):
            self.damage['boss'] += m.damage*1.0
            if m.player is not None and m.player.exists(): 
                if hasattr(m.player, 'getTeam'): team=m.player.getTeam()
                else: team = None
                if team is not None: team.gameData.update({'score': team.gameData.get('score', 0)+m.damage})
            if self.boss is not None and self.boss.exists() and self.boss.isAlive():
                if self.st > 3 and m.type == 'punch': 
                    self.boss.hitPoints = min(self.boss.hitPoints+(m.damage*0.3), self.boss.hitPointsMax)
                if self.boss.hitPoints < 3000: 
                    if self.st > 3: 
                        self.teleport(count=28, interval=50)
                        self.boss.hitPoints = min(self.boss.hitPoints+(m.damage*0.75), self.boss.hitPointsMax)
                    else: 
                        if m.type == 'punch' or m.type == 'explosion': 
                            self.boss.node.handleMessage('knockout', int(m.damage))
                            self.boss.hitPoints = min(self.boss.hitPoints+(m.damage*0.4), self.boss.hitPointsMax)
                        self.teleport()
                else:
                    if m.type == 'punch' and m.damage > 400 and self.st > 1: self.teleport()
                    if m.type == 'explosion' and m.damage > 1000 and self.st > 2: self.teleport()
        else:
            bs.TeamGameActivity.handleMessage(self, m)

    def endGame(self):
        self.st = 0
        results = bs.TeamGameResults()
        for team in self.teams:
            results.setTeamScore(team, int(max(0, team.gameData.get('score', 0)+self.damage['bots']*0.72+self.damage['boss']-(self.respawn*1000))))
        self._attackTimer = None
        self._updateTimer = None
        self.end(results)

class ZeroBossCircle(object):
    def __init__(self, time=10000, position=(0,1.5,0), times = 2, radius=1):
        self.endCircleTime = time
        self.circlePos = position
        self.times = times
        self.radius = radius
        if self.endCircleTime < 3000: self.endCircleTime = 3000
        def start():
            self.spawn()
        for i in range(self.times):
            bs.gameTimer((self.endCircleTime/2)*(i), bs.Call(start))
        self.light = bs.newNode('light', attrs={'position':self.circlePos,'color':(1,0.35,0),'radius':self.radius})
        bsUtils.animate(self.light, 'intensity', {0:0, 1000:1.5, self.endCircleTime-1000:1.5, self.endCircleTime:0})
        bsUtils.animate(self.light, 'radius', {0:self.radius/1.2, 700:self.radius/1.2, 1000:self.radius, 2000:self.radius/1.2}, loop=True)
        bs.gameTimer(int(self.endCircleTime*1.0), self.light.delete)
    def spawn(self):
        speed = 6
        def bomb0():
            bs.Bomb(position=self.circlePos, velocity=(0,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(0,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb1():
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(speed,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb2():
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,0), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(speed,0,0), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb3():
            bs.Bomb(position=self.circlePos, velocity=(speed,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        mult = self.endCircleTime/10
        bs.gameTimer(mult*1, bs.Call(bomb0))
        bs.gameTimer(mult*2, bs.Call(bomb1))
        bs.gameTimer(mult*3, bs.Call(bomb2))
        bs.gameTimer(mult*4, bs.Call(bomb3))

class ZeroBossBlastExample(object):
    def __init__(self, position=(0,0,0), color=(1,0.75,0), radius=0.3, mult=1.05, startTime=1, endTime=2001):
        self.death = endTime
        self.start = startTime
        self.position = position
        self.color = color
        self.radius = radius
        self.mult = mult
        bs.gameTimer(int(self.start*1.0), self.spawn)
    def spawn(self):
        self.light = bs.newNode('light', attrs={'position':self.position,'color':self.color,'radius':self.radius})
        bsUtils.animate(self.light, 'intensity', {0:0, 1000:1.75, int(self.death*1.0):1.75, int(self.death*1.0)+1000:0})
        bsUtils.animate(self.light, 'radius', {0:self.radius, 3000:self.radius*self.mult, 4500:self.radius}, True)
        bs.gameTimer(int(self.death*1.0)+1000, self.light.delete)

class ZeroBossBlast(bs.Actor):
    def __init__(self,position=(0,1,0),time=5000,type = 'horizontal'):
        bs.Actor.__init__(self)
        factory = self.getFactory()
        self.pos = position
        self.scale = (1,1,1)
        self.time = time
        self.m = type
        if (self.m in ['horizontal','vertical']):
            if self.m == 'horizontal': 
                for i in range(30):
                    ZeroBossBlastExample(position=(-15+i,0,0), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1+(i*30), endTime=(1+int(self.time*1.0)))
                self.scale = (20,10,0.1)
            elif self.m == 'vertical':
                for i in range(20):
                    ZeroBossBlastExample(position=(0,0,-10+i), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1+(i*30), endTime=(1+int(self.time*1.0)))
                self.scale = (0.1,10,20)
            def spawn():
                self.node = bs.newNode('region', delegate=self, attrs={'position':(self.pos[0],self.pos[1]-0.1,self.pos[2]),'scale':self.scale,'type':'box','materials':(factory.newBlastMaterial, bs.getSharedObject('attackMaterial'))})
                bs.gameTimer(int(self.time*1.0), self.node.delete)
            bs.gameTimer(500, bs.Call(spawn))
        elif (self.m in ['sphere']):
            self.scale = (0.6,10,0.6)
            randPos = (random.randrange(-12,12),1,random.randrange(-5,5))
            def spawn():
                self.node = bs.newNode('region', delegate=self, attrs={'position':(randPos[0],randPos[1]-0.1,randPos[2]),'scale':self.scale,'type':'sphere','materials':(factory.newBlastMaterial, bs.getSharedObject('attackMaterial'))})
                bs.gameTimer(int(self.time*1.0), self.node.delete)
            bs.gameTimer(500, bs.Call(spawn))
            ZeroBossBlastExample(position=(randPos[0],randPos[1]-0.1,randPos[2]), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1, endTime=(1+int(self.time*1.0)))

    def getFactory(cls):
        activity = bs.getActivity()
        try: return activity._sharedZeroBossBlastFact
        except Exception:
            f = activity._sharedZeroBossBlastFact = ZeroBossBlastFactory()
            return f

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if isinstance(msg, bs.DieMessage): 
            self.node.delete()
        elif isinstance(msg, NewExplodeHitMessage):
            node = bs.getCollisionInfo("opposingNode")
            if node is not None and node.exists():
                t = self.node.position
                tr = node.position
                if (node.getNodeType() == 'spaz'):
                    node.handleMessage(bs.HitMessage(
                        pos=tr,
                        velocity=(0,0,0),
                        magnitude=550.0,
                        hitType='explosion',
                        hitSubType='bossBlast',
                        radius=100.0,
                        sourcePlayer=bs.Player(None), 
                        kickBack=0))
                    node.handleMessage('impulse',tr[0],tr[1]-2,tr[2],0,0,0,2000,0,200.0,1,0,100,0)
        else:
            bs.Actor.handleMessage(self, msg)

class ZeroBossBlastFactory(object):
    def __init__(self):
        self.blastSound = bs.getSound('activateBeep')
        self.newBlastMaterial = bs.Material()
        self.newBlastMaterial.addActions(
            conditions=(('theyHaveMaterial',
                         bs.getSharedObject('objectMaterial'))),
            actions=(('modifyPartCollision','collide',True),
                     ('modifyPartCollision','physical',False),
                     ('message','ourNode','atConnect',NewExplodeHitMessage())))

class NewExplodeHitMessage(object):
    def __init__(self):
        pass

class TextOnScreen(object):
    def __init__(self, color=(3,0,0), scale=0.0095, time=2000, position='player', opacity=1, text='Alert!', owner=None):
        self.color = color
        self.scale = scale
        self.end = time
        self.owner = owner
        self.pos = position if position != 'player' else (0,0,0)
        self.flatness = opacity
        self.text = text
        if self.owner is not None:
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 2.325, 0), 'operation': 'add'})
            self.owner.connectAttr('position', m, 'input2')                        
            self._text = bs.newNode('text', owner=self.owner, attrs={'text':self.text, 'inWorld':True, 'position':self.pos, 'flatness':0, 'color':self.color, 'scale':0, 'hAlign':'center'})
            m.connectAttr('output', self._text, 'position')
        else: self._text = bs.newNode('text', attrs={'text':self.text, 'inWorld':True, 'position':self.pos, 'flatness':0, 'color':self.color, 'scale':0, 'hAlign':'center'})
        bsUtils.animate(self._text, 'scale', {0:0, 250:self.scale, int(self.end*1.0):self.scale, int(self.end*1.0)+500:0.0})
        bsUtils.animate(self._text, 'opacity', {0:self.flatness/1.5, 250:self.flatness, 500:self.flatness/1.5}, loop = True)
        bs.gameTimer(int(self.end*1.0)+500, self._text.delete)
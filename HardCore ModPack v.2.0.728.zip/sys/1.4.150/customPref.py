# -*- coding: utf-8 -*-
prefixes = {'\xee\x80\xa0DrovGamedev':['Я @, ты @', 'spark', 'True']}
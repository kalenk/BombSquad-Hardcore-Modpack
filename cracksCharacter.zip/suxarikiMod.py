# -*- coding: utf-8 -*-
import bs
import shutil, os
import bsInternal
import bsSpaz

version = 4

# writed by drov.drov

env = bs.getEnvironment()
gAndroid = env['platform'] == 'android'
gPath = 'data' if not gAndroid else '/data/data/net.froemling.bombsquad/files/bombsquad_files/data'

character_name = '3 Korochki'
working_path = os.path.join(env['userScriptsDirectory'], '3Korochki')
version_path = os.path.join(gPath, character_name.lower()+'Mod.data')
file_types = {'.ktx' if gAndroid else '.dds': 'textures', '.bob': 'models', '.ogg': 'audio'}
time_skip = 100 # time rate while copying 

translates = {
    "Russian": {
        "installStartedText": "Установка персонажа \"{}\"",
        "copyingText": "Копирование файла {}",
        "installCompleteText": "Установка завершена!"},
    "English": {
        "installStartedText": "Installing character \"{}\"",
        "copyingText": "Copying file {}",
        "installCompleteText": "Install complete!"}
    }
translates = translates.get(bs.getLanguage(), translates.get("English", {}))

def run(call=None):
    a = bsInternal._getForegroundHostActivity()
    if call is None: call = lambda x : True
    if a is not None: bs.realTimer(time_skip, bs.Call(call))
    else: bs.realTimer(time_skip, bs.Call(run, call))

def install():
    v = 0
    if os.path.exists(version_path):
        with open(version_path, 'r') as f:
            v = f.read()
            f.close()
        try: v = int(v.replace('.', ''))
        except ValueError: v = 0
    if v < version: copyfiles()
    else: on_end()

def copyfiles():
    bs.screenMessage(translates.get("installStartedText", "installing character \"{}\"").format(character_name), color=(1,0.85,0))
    def copy(dst, src):
        filename = dst.split(os.path.sep)[-1]
        filepath = os.path.join(src, filename)
        if os.path.exists(filepath): os.remove(filepath)
        bs.screenMessage(translates.get("copyingText", "copying... {}").format(filename), color=(1, 1, 0))
        try: shutil.copy(dst, src)
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
    if os.path.exists(working_path) and os.path.isdir(working_path):
        try:
            for root, dirs, files in os.walk(working_path):
                for i in range(len(files)):
                    file = root+os.path.sep+files[i]
                    type = None
                    filename = file.split(os.path.sep)[-1]
                    for t in file_types:
                        if filename.endswith(t): 
                            type = file_types[t]
                            break
                    if type is not None: 
                        bs.realTimer(time_skip * i + time_skip, bs.Call(copy, file, gPath+os.path.sep+type))
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
        else:
            with open(version_path, 'w+') as f:
                f.write(str(version))
                f.flush()
                f.close()
            def end():
                on_end()
                bs.screenMessage(translates.get("installCompleteText", "install complete!").format(character_name), color=(1,0.85,0))
            bs.realTimer(time_skip * len(files) + time_skip, bs.Call(end))
    else: bs.screenMessage("Can not find path: "+str(pitsaDir), color=(1,0,0))


spazfactorygetmediaold = bsSpaz.SpazFactory._getMedia
def _getMedia(self, character):
    if character == '3 Korochki': 
        t = bsSpaz.appearances[character]
        if not self.spazMedia.has_key(character):
            m = self.spazMedia[character] = {
                'jumpSounds': [bs.getSound(i) for i in t.jumpSounds] if t.jumpSounds is not None else [],
                'attackSounds': [bs.getSound(i) for i in t.attackSounds] if t.attackSounds is not None else [],
                'impactSounds': [bs.getSound(i) for i in t.impactSounds] if t.impactSounds is not None else [],
                'deathSounds': [bs.getSound(i) for i in t.deathSounds] if t.deathSounds is not None else [],
                'pickupSounds': [bs.getSound(i) for i in t.pickupSounds] if t.pickupSounds is not None else [],
                'fallSounds': [bs.getSound(i) for i in t.fallSounds] if t.fallSounds is not None else [],
                'colorTexture': bs.getTexture(t.colorTexture) if t.colorTexture != '' else None,
                'colorMaskTexture':bs.getTexture(t.colorMaskTexture) if t.colorMaskTexture != '' else None,
                'headModel': bs.getModel(t.headModel) if t.headModel != '' else None,
                'torsoModel': bs.getModel(t.torsoModel) if t.torsoModel != '' else None,
                'pelvisModel': bs.getModel(t.pelvisModel) if t.pelvisModel != '' else None,
                'upperArmModel': bs.getModel(t.upperArmModel) if t.upperArmModel != '' else None,
                'foreArmModel': bs.getModel(t.foreArmModel) if t.foreArmModel != '' else None,
                'handModel': bs.getModel(t.handModel) if t.handModel != '' else None,
                'upperLegModel': bs.getModel(t.upperLegModel) if t.upperLegModel != '' else None,
                'lowerLegModel': bs.getModel(t.lowerLegModel) if t.lowerLegModel != '' else None,
                'toesModel': bs.getModel(t.toesModel) if t.toesModel != '' else None
            }
        else: m = self.spazMedia[character]
        return m
    else:
        return spazfactorygetmediaold(self, character)
bsSpaz.SpazFactory._getMedia = _getMedia

def on_end():
    global character_name
    from bsSpaz import Appearance
    t = Appearance(character_name)
    character_name = character_name.replace(" ", "")
    t.colorTexture = character_name+"Color"
    t.colorMaskTexture = character_name+"ColorMask"
    t.headModel = ''
    t.defaultColor = (0.6, 0.6, 0.6)
    t.defaultHighlight = (0, 1, 0)
    t.torsoModel = character_name+"Torso"
    t.upperArmModel = character_name+"UpperArm"
    t.foreArmModel = character_name+"ForeArm"
    t.handModel = ''
    t.upperLegModel = character_name+"UpperLeg"
    t.lowerLegModel = character_name+"LowerLeg"
    t.toesModel = character_name+"Toes"
    t.iconTexture = character_name+"Icon"
    t.iconMaskTexture = character_name+"IconMask"
    t.style = 'bones'
    t.deathSounds = [character_name+"Death"]
    t.fallSounds = [character_name+"Fall"]
    t.attackSounds = [character_name+"Hit"+str(i) for i in range(1, 3)]
    t.jumpSounds = t.pickupSounds = t.impactSounds = [character_name+str(i) for i in range(1, 5)]

run(install)
    
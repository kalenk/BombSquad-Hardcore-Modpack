from .text import *
from .servers import *
from .settings import *
import bs, bsInternal

def get_nickname_by_client_id(clientID=-1):
    roster, activity = bsInternal._getGameRoster(), bsInternal._getForegroundHostActivity()
    nickname, is_account = None, False
    if not isinstance(clientID, int): raise ValueError("clientID must be integer.")
    if len(roster) > 0:
        client = [i for i in roster if i["clientID"] == clientID]
        client = client[0] if len(client) > 0 else None
        if client is not None:
            if len(client["players"]) > 0: nickname = client["players"][0]["name"]
            else: nickname, is_account = client["displayString"], True
    elif clientID == -1:
        if len(activity.players) > 0: nickname = activity.players[0].getName()
        else: nickname, is_account = bsInternal._getAccountName(), True
    if nickname is not None and len(nickname) > 10 and not is_account: nickname = nickname[:10] + "..."
    return nickname


import bs
import bsInternal
import json, os, copy

def sort_settings(data={}):
    return sorted(data.items(), key=lambda dr : (dr[1] not in [False, True], dr[0]))

def _make_iterencode(markers, _default, _encoder, _indent, _floatstr,
        _key_separator, _item_separator, _sort_keys, _skipkeys, _one_shot,
        ValueError=ValueError,
        basestring=basestring,
        dict=dict,
        float=float,
        id=id,
        int=int,
        isinstance=isinstance,
        list=list,
        long=long,
        str=str,
        tuple=tuple):

    def _iterencode_list(lst, _current_indent_level):
        if not lst:
            yield '[]'
            return
        if markers is not None:
            markerid = id(lst)
            if markerid in markers:
                raise ValueError("Circular reference detected")
            markers[markerid] = lst
        buf = '['
        if _indent is not None:
            _current_indent_level += 1
            newline_indent = '\n' + (' ' * (_indent * _current_indent_level))
            separator = _item_separator + newline_indent
            buf += newline_indent
        else:
            newline_indent = None
            separator = _item_separator
        first = True
        for value in lst:
            if first:
                first = False
            else:
                buf = separator
            if isinstance(value, basestring):
                yield buf + _encoder(value)
            elif value is None:
                yield buf + 'null'
            elif value is True:
                yield buf + 'true'
            elif value is False:
                yield buf + 'false'
            elif isinstance(value, (int, long)):
                yield buf + str(value)
            elif isinstance(value, float):
                yield buf + _floatstr(value)
            else:
                yield buf
                if isinstance(value, (list, tuple)):
                    chunks = _iterencode_list(value, _current_indent_level)
                elif isinstance(value, dict):
                    chunks = _iterencode_dict(value, _current_indent_level)
                else:
                    chunks = _iterencode(value, _current_indent_level)
                for chunk in chunks:
                    yield chunk
        if newline_indent is not None:
            _current_indent_level -= 1
            yield '\n' + (' ' * (_indent * _current_indent_level))
        yield ']'
        if markers is not None:
            del markers[markerid]

    def _iterencode_dict(dct, _current_indent_level):
        if not dct:
            yield '{}'
            return
        if markers is not None:
            markerid = id(dct)
            if markerid in markers:
                raise ValueError("Circular reference detected")
            markers[markerid] = dct
        yield '{'
        if _indent is not None:
            _current_indent_level += 1
            newline_indent = '\n' + (' ' * (_indent * _current_indent_level))
            item_separator = _item_separator + newline_indent
            yield newline_indent
        else:
            newline_indent = None
            item_separator = _item_separator
        first = True
        if _sort_keys:
            items = sort_settings(dct)
        else:
            items = dct.iteritems()
        for key, value in items:
            if isinstance(key, basestring):
                pass
            # JavaScript is weakly typed for these, so it makes sense to
            # also allow them.  Many encoders seem to do something like this.
            elif isinstance(key, float):
                key = _floatstr(key)
            elif key is True:
                key = 'true'
            elif key is False:
                key = 'false'
            elif key is None:
                key = 'null'
            elif isinstance(key, (int, long)):
                key = str(key)
            elif _skipkeys:
                continue
            else:
                raise TypeError("key " + repr(key) + " is not a string")
            if first:
                first = False
            else:
                yield item_separator
            yield _encoder(key)
            yield _key_separator
            if isinstance(value, basestring):
                yield _encoder(value)
            elif value is None:
                yield 'null'
            elif value is True:
                yield 'true'
            elif value is False:
                yield 'false'
            elif isinstance(value, (int, long)):
                yield str(value)
            elif isinstance(value, float):
                yield _floatstr(value)
            else:
                if isinstance(value, (list, tuple)):
                    chunks = _iterencode_list(value, _current_indent_level)
                elif isinstance(value, dict):
                    chunks = _iterencode_dict(value, _current_indent_level)
                else:
                    chunks = _iterencode(value, _current_indent_level)
                for chunk in chunks:
                    yield chunk
        if newline_indent is not None:
            _current_indent_level -= 1
            yield '\n' + (' ' * (_indent * _current_indent_level))
        yield '}'
        if markers is not None:
            del markers[markerid]

    def _iterencode(o, _current_indent_level):
        if isinstance(o, basestring):
            yield _encoder(o)
        elif o is None:
            yield 'null'
        elif o is True:
            yield 'true'
        elif o is False:
            yield 'false'
        elif isinstance(o, (int, long)):
            yield str(o)
        elif isinstance(o, float):
            yield _floatstr(o)
        elif isinstance(o, (list, tuple)):
            for chunk in _iterencode_list(o, _current_indent_level):
                yield chunk
        elif isinstance(o, dict):
            for chunk in _iterencode_dict(o, _current_indent_level):
                yield chunk
        else:
            if markers is not None:
                markerid = id(o)
                if markerid in markers:
                    raise ValueError("Circular reference detected")
                markers[markerid] = o
            o = _default(o)
            for chunk in _iterencode(o, _current_indent_level):
                yield chunk
            if markers is not None:
                del markers[markerid]

    return _iterencode

json.encoder._make_iterencode = _make_iterencode

quit_old = bs.quit
_gData={"admins":[], "vips":[], "lobby_connect_menu":False, "show_game_name":True, \
    "admins_prefix":True, "timer_the_disappearance_of_the_effect":True, \
    "powerup_lighting":True, "timer_the_disappearance_of_the_powerup":True, \
    "timer_before_the_bomb_explode":True, "chat_commands_enabled":True, \
    "standart_powerups":False, "auto-update":False, "internet_tab_search_text":"", \
    "in_menu_author_name": True, "party_search_log": False}
        
env = bs.getEnvironment()
gSettingsPath=os.path.join(env["userScriptsDirectory"], "settings.json")

class Settings(object):
	def __init__(self, path):
		self.path = path if os.path.exists(path) else None
		self._reload()
		self.calls = 0
		self.call = {0: None}
	def set_setting(self, setting="test", value=True):
		self.calls += 1
		self.data.update({setting: value})
		if self.call.keys()[0] < self.calls: self.call = {self.calls: bs.Timer(2000, bs.Call(self._save), timeType='real') if setting not in ["banned","skins","prefixes","admins","vips"] else self._save()}
	def get_setting(self, setting="test", defaultValue=None):
		return self.data.get(setting, defaultValue)
	def get_all(self):
		return self.data
	def _save(self):
		try: json.dump(self.data, open(self.path, "w+"), indent=4, sort_keys=True)
		except Exception: print("save settings-file error")
	def _reload(self):
		try: self.data = json.load(open(self.path)) if self.path is not None else _gData
		except Exception:
			self.data = _gData
        
st = Settings(path=gSettingsPath)
def set_setting(name=None, value=True):
    st.set_setting(setting=name, value=value)
    
def get_setting(name=None, default_value=None):
	return st.get_setting(setting=name, defaultValue=default_value)
    
def get_settings(path=None):
    return st.get_all()

def reload_settings(data=None):
    if data is not None:
        for i in data: _gData.update({i: data[i]})

def rewrite_settings():
    json.dump(_gData, open(gSettingsPath, "w+"), indent=4, sort_keys=True)
    st._reload()

def check_settings_file():
    if not os.path.exists(gSettingsPath): rewrite_settings()
    else:
        data = st.get_all()
        powerups = [i[0] for i in bs.getDefaultPowerupDistribution(True)]
        _gData.update({"powerups": powerups})
        for i in _gData:
            if data.get(i) is None:
                reload_settings(data=data)
                rewrite_settings()
                break
    
def write_log(path=None):
    if path is None: path=os.path.join(env["userScriptsDirectory"], "log.txt")
    if os.path.exists(path) and path.endswith(".txt"):
        with open(path, "w+") as f:
            f.write(bsInternal._getLog())
            f.close()
    else:
        for i in ["path isn\'t exists: "+path, "see more in advanced.__init__.write_log()"]: 
            bsInternal._log(i)
        raise ValueError()
        
def save_settings():
    st._save()
    write_log()
            
def quit(soft=True, back=False):
    save_settings()
    quit_old(soft=soft, back=back)
    
bs.quit = quit
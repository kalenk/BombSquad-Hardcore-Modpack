# -*- coding: utf-8 -*-
import bs
import random
import bsUtils
import bsInternal
from bsSpaz import SpazBot, SpazBotDeathMessage, SpazBotPunchedMessage, gDefaultBotColor, gDefaultBotHighlight, _BombDiedMessage
import time

class DirtBombOutMessage(object):
    pass

class ExplodeMessage(object):
    pass

class ExplodeHitMessage(object):
    def __init__(self):
        pass

class PoisonBombHitMessage(object):
    def __init__(self):
        pass

class OtherEffect(object):
    def __init__(self, text = "Effect is None", player = None, color = (1,1,1), opacity = 1, effectTime = 1000):
        self.node = player
        if "get_setting" not in dir(bs) or not bs.get_setting(name="timer_the_disappearance_of_the_effect", default_value=False): return
        if self.node is not None and self.node.exists():
            pos = [bs.newNode('math', owner=self.node, attrs={'input1': (0.8, 1, 0), 'operation': 'add'}), bs.newNode('math', owner=self.node, attrs={'input1': (0.8, 0.2, 0), 'operation': 'add'})]
            for i in pos: self.node.connectAttr('position', i, 'input2')
            effect = [bs.newNode('text', owner = self.node, attrs={'text': text, 'inWorld': True, 'shadow': 0.15, 'flatness': opacity, 'color': color, 'scale': 0, 'hAlign': 'center'}), \
                bs.newNode('shield', owner = self.node, attrs={'radius': 0, 'color': (0,10,0), 'hurt': 0, 'alwaysShowHealthBar': True})]
            for i in range(2): pos[i].connectAttr('output', effect[i], 'position')
            bsUtils.animate(effect[0], 'scale', {0:0, 300:0.0085})
            bsUtils.animate(effect[1], 'hurt', {0: 0, effectTime: 1})
            for i in effect: bs.gameTimer(effectTime, i.delete)

class PoisonEffect(object):
    def __init__(self, owner=None):
        self.node = owner
        light = bs.newNode('light', owner=self.node, attrs={'radius': 0.095, 'volumeIntensityScale': 1.28, 'color': (0, 1.4, 0.2)})
        def stop():
            if hasattr(light, "radius"): bsUtils.animate(light, "radius", {0: light.radius, 500: 0})
            self.timer = None
            bs.gameTimer(500, light.delete)
        def poison():
            if self.node.exists(): self.node.handleMessage(bs.HitMessage(pos=self.node.position, velocity=(0, 0, 0), magnitude=2.6, hitType='explosion',
                hitSubType='poisonEffect', radius=1, sourcePlayer=bs.Player(None), kickBack=0))
            else: stop()
        if self.node is not None and self.node.exists():
            self.timer = bs.Timer(10, bs.Call(poison), True)
            bs.gameTimer(10000, bs.Call(stop))
        self.node.connectAttr('position', light, 'position')


class InGameSpaz(bs.Spaz):
    def __init__(self, color=(1, 1, 1), highlight=(0.5, 0.5, 0.5), character="Spaz", sourcePlayer=None, startInvincible=True, canAcceptPowerups=True, powerupsExpire=False, demoMode=False):
        bs.Spaz.__init__(self, color=color, highlight=highlight, character=character, sourcePlayer=sourcePlayer, startInvincible=startInvincible, canAcceptPowerups=canAcceptPowerups, powerupsExpire=powerupsExpire, demoMode=demoMode)
    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if PoisonBombHitMessage is not None and isinstance(msg, PoisonBombHitMessage):
            PoisonEffect(owner = self.node), OtherEffect(text = "Poisoned", player = self.node, color = (0,2,0), opacity = 0.8, effectTime = 10000)
        elif isinstance(msg, bs.HitMessage) and hasattr(msg, "hitSubType") and msg.hitSubType == "poisonEffect": 
            mag = msg.magnitude * 1.0
            damage = self.node.damage * 0.22
            self.node.handleMessage(
                "impulse", msg.pos[0], msg.pos[1], msg.pos[2],
                msg.velocity[0], msg.velocity[1], msg.velocity[2],
                mag, velocityMag, msg.radius, 0,
                msg.forceDirection[0], msg.forceDirection[1],
                msg.forceDirection[2])
            self.hitPoints -= damage
            self.node.hurt = 1.0 - float(self.hitPoints)/self.hitPointsMax
        else: bs.Spaz.handleMessage(self, msg)

class InGamePlayerSpaz(InGameSpaz):
    def __init__(self, color=(1, 1, 1), highlight=(0.5, 0.5, 0.5), character="Spaz", player=None, powerupsExpire=True):
        if player is None: player = bs.Player(None)
        InGameSpaz.__init__(self, color=color, highlight=highlight,
            character=character, sourcePlayer=player,
            startInvincible=True, powerupsExpire=powerupsExpire)
        self.lastPlayerAttackedBy = None
        self.lastAttackedTime = 0
        self.lastAttackedType = None
        self.heldCount = 0
        self.lastPlayerHeldBy = None
        self._player = player
        if player.exists():
            playerNode = bs.getActivity()._getPlayerNode(player)
            self.node.connectAttr('torsoPosition', playerNode, 'position')
    def __superHandleMessage(self, msg):
        super(InGamePlayerSpaz, self).handleMessage(msg)

    def getPlayer(self):
        """
        Return the bs.Player associated with this spaz.
        Note that while a valid player object will always be
        returned, there is no guarantee that the player is still
        in the game.  Call bs.Player.exists() on the return value
        before doing anything with it.
        """
        return self._player

    def connectControlsToPlayer(self, enableJump=True, enablePunch=True,
                                enablePickUp=True, enableBomb=True,
                                enableRun=True, enableFly=True):
        """
        Wire this spaz up to the provided bs.Player.
        Full control of the character is given by default
        but can be selectively limited by passing False
        to specific arguments.
        """
        player = self.getPlayer()
        # reset any currently connected player and/or the player we're wiring up
        if self._connectedToPlayer is not None:
            if player != self._connectedToPlayer: player.resetInput()
            self.disconnectControlsFromPlayer()
        else: player.resetInput()

        player.assignInputCall('upDown', self.onMoveUpDown)
        player.assignInputCall('leftRight', self.onMoveLeftRight)
        player.assignInputCall('holdPositionPress', self._onHoldPositionPress)
        player.assignInputCall('holdPositionRelease',self._onHoldPositionRelease)

        if enableJump:
            player.assignInputCall('jumpPress', self.onJumpPress)
            player.assignInputCall('jumpRelease', self.onJumpRelease)
        if enablePickUp:
            player.assignInputCall('pickUpPress', self.onPickUpPress)
            player.assignInputCall('pickUpRelease', self.onPickUpRelease)
        if enablePunch:
            player.assignInputCall('punchPress', self.onPunchPress)
            player.assignInputCall('punchRelease', self.onPunchRelease)
        if enableBomb:
            player.assignInputCall('bombPress', self.onBombPress)
            player.assignInputCall('bombRelease', self.onBombRelease)
        if enableRun:
            player.assignInputCall('run', self.onRun)
        if enableFly:
            player.assignInputCall('flyPress', self.onFlyPress)
            player.assignInputCall('flyRelease', self.onFlyRelease)

        self._connectedToPlayer = player

        
    def disconnectControlsFromPlayer(self):
        """
        Completely sever any previously connected
        bs.Player from control of this spaz.
        """
        if self._connectedToPlayer is not None:
            self._connectedToPlayer.resetInput()
            self._connectedToPlayer = None
            # send releases for anything in case its held..
            self.onMoveUpDown(0)
            self.onMoveLeftRight(0)
            self._onHoldPositionRelease()
            self.onJumpRelease()
            self.onPickUpRelease()
            self.onPunchRelease()
            self.onBombRelease()
            self.onRun(0.0)
            self.onFlyRelease()
        else:
            print ('WARNING: disconnectControlsFromPlayer() called for'
                   ' non-connected player')
    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if isinstance(msg, PoisonBombHitMessage):
            PoisonEffect(owner = self.node)
            OtherEffect(text = "Poisoned", player = self.node, color = (0,2,0), opacity = 0.8, effectTime = 10000)
        elif isinstance(msg, bs.PickedUpMessage):
            self.__superHandleMessage(msg) # augment standard behavior
            self.heldCount += 1
            pickedUpBy = msg.node.sourcePlayer
            if pickedUpBy is not None and pickedUpBy.exists():
                self.lastPlayerHeldBy = pickedUpBy
        elif isinstance(msg, bs.HitMessage) and hasattr(msg, "hitSubType") and msg.hitSubType == "poisonEffect": 
            mag = msg.magnitude * 1.0
            damage = self.node.damage * 0.22
            self.node.handleMessage(
                "impulse", msg.pos[0], msg.pos[1], msg.pos[2],
                msg.velocity[0], msg.velocity[1], msg.velocity[2],
                mag, velocityMag, msg.radius, 0,
                msg.forceDirection[0], msg.forceDirection[1],
                msg.forceDirection[2])
            self.hitPoints -= damage
            self.node.hurt = 1.0 - float(self.hitPoints)/self.hitPointsMax
        elif isinstance(msg, bs.DroppedMessage):
            self.__superHandleMessage(msg) # augment standard behavior
            self.heldCount -= 1
            if self.heldCount < 0:
                print "ERROR: spaz heldCount < 0"
            # let's count someone dropping us as an attack..
            try: pickedUpBy = msg.node.sourcePlayer
            except Exception: pickedUpBy = None
            if pickedUpBy is not None and pickedUpBy.exists():
                self.lastPlayerAttackedBy = pickedUpBy
                self.lastAttackedTime = bs.getGameTime()
                self.lastAttackedType = ('pickedUp', 'default')
        elif isinstance(msg, bs.DieMessage):

            # report player deaths to the game
            if not self._dead:

                # immediate-mode or left-game deaths don't count as 'kills'
                killed = (msg.immediate==False and msg.how!='leftGame')

                activity = self._activity()

                if not killed:
                    killerPlayer = None
                else:
                    # if this player was being held at the time of death,
                    # the holder is the killer
                    if (self.heldCount > 0
                            and self.lastPlayerHeldBy is not None
                            and self.lastPlayerHeldBy.exists()):
                        killerPlayer = self.lastPlayerHeldBy
                    else:
                        # otherwise, if they were attacked by someone in the
                        # last few seconds, that person's the killer..
                        # otherwise it was a suicide.
                        # FIXME - currently disabling suicides in Co-Op since
                        # all bot kills would register as suicides; need to
                        # change this from lastPlayerAttackedBy to something
                        # like lastActorAttackedBy to fix that.
                        if (self.lastPlayerAttackedBy is not None
                                and self.lastPlayerAttackedBy.exists()
                                and bs.getGameTime() - self.lastAttackedTime \
                                < 4000):
                            killerPlayer = self.lastPlayerAttackedBy
                        else:
                            # ok, call it a suicide unless we're in co-op
                            if (activity is not None
                                    and not isinstance(activity.getSession(),
                                                       bs.CoopSession)):
                                killerPlayer = self.getPlayer()
                            else:
                                killerPlayer = None
                            
                if killerPlayer is not None and not killerPlayer.exists():
                    killerPlayer = None

                # only report if both the player and the activity still exist
                if (killed and activity is not None
                    and self.getPlayer().exists()):
                    activity.handleMessage(bs.PlayerSpazDeathMessage(self, killed, killerPlayer, msg.how))
                    
            self.__superHandleMessage(msg) # augment standard behavior

        # keep track of the player who last hit us for point rewarding
        elif isinstance(msg, bs.HitMessage):
            if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                self.lastPlayerAttackedBy = msg.sourcePlayer
                self.lastAttackedTime = bs.getGameTime()
                self.lastAttackedType = (msg.hitType, msg.hitSubType)
            self.__superHandleMessage(msg) # augment standard behavior
            activity = self._activity()
            if activity is not None:
                activity.handleMessage(bs.PlayerSpazHurtMessage(self))
        else:
            InGameSpaz.handleMessage(self, msg)

class InGameSpazBot(InGameSpaz):
    character = 'Spaz'
    punchiness = 0.3
    throwiness = 0.9
    static = False
    bouncy = True
    run = True
    chargeDistMin = 0.0 # when we can start a new charge
    chargeDistMax = 2.0 # when we can start a new charge
    runDistMin = 0.0 # how close we can be to continue running
    chargeSpeedMin = 0.3
    chargeSpeedMax = 1.0
    throwDistMin = 2.0
    throwDistMax = 5.0
    throwRate = 1.0
    defaultBombType = 'normal'
    defaultBombCount = 1
    startCursed = False
    color=gDefaultBotColor
    highlight=gDefaultBotHighlight
    hp = 1000
    ph = 1.2

    def __init__(self):
        bs.SpazBot.__init__(self)
        self.hitPoints = self.hitPointsMax = self.hp
        self._punchPowerScale = self.ph
    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if PoisonBombHitMessage is not None and isinstance(msg, PoisonBombHitMessage):
            PoisonEffect(owner = self.node), OtherEffect(text = "Poisoned", player = self.node, color = (0,2,0), opacity = 0.8, effectTime = 10000)
        else: InGameSpaz.handleMessage(self, msg)

class PoisonBombBlast(bs.Blast):
    def __init__(self, position=(0,1,0), velocity=(0,0,0), sourcePlayer=None, hitType='explosion', hitSubType='normal'):
        bs.Actor.__init__(self)
        factory = bs.Bomb.getFactory()
        self.sourcePlayer = sourcePlayer
        self.hitType = hitType;
        self.hitSubType = hitSubType;
        self.blastMaterial = bs.Material()
        self.blastMaterial.addActions(
            conditions=(('theyHaveMaterial',
                         bs.getSharedObject('objectMaterial'))),
            actions=(('modifyPartCollision','collide',True),
                     ('modifyPartCollision','physical',False),
                     ('message','ourNode','atConnect',ExplodeHitMessage())))
        self.radius = 2
        self.node = bs.newNode('region', delegate=self, attrs={
            'position':(position[0], position[1]-0.1, position[2]),
            'scale':(2,2,2),
            'type':'sphere',
            'materials':(self.blastMaterial, bs.getSharedObject('attackMaterial'))})
        bs.gameTimer(10, self.node.delete)
        explosion = bs.newNode("explosion", attrs={
            'position':position,
            'velocity':(velocity[0],max(-1.0,velocity[1]),velocity[2]),
            'radius':self.radius,
            'big':False})
        explosion.color = (1,0.8,0)
        bs.gameTimer(1000, explosion.delete)
        bs.emitBGDynamics(
            position=position, velocity=velocity,
            count=int(4.0+random.random()*4), emitType='tendrils',
            tendrilType='smoke')
        bs.emitBGDynamics(position=position, emitType='distortion', spread=2.0)
        def _doEmit():
            bs.emitBGDynamics(position=position, velocity=velocity, count=30, 
                spread=2.0, scale=0.4, chunkType='rock', emitType='stickers');
        bs.gameTimer(50, _doEmit)

        def _doEmit():
            bs.emitBGDynamics(position=position, velocity=velocity,
                              count=int(4.0+random.random()*8),
                              chunkType='rock');
            bs.emitBGDynamics(position=position, velocity=velocity,
                              count=int(4.0+random.random()*8),
                              scale=0.5,chunkType='rock');
            bs.emitBGDynamics(position=position, velocity=velocity,
                              count=30,
                              scale=0.7,
                              chunkType='spark', emitType='stickers');
            bs.emitBGDynamics(position=position, velocity=velocity,
                              count=int(18.0+random.random()*20),
                              scale=0.8,
                              spread=1.5, chunkType='spark');
                
            if random.random() < 0.1:
                def _emitExtraSparks():
                    bs.emitBGDynamics(position=position, velocity=velocity,
                                      count=int(10.0+random.random()*20),
                                      scale=0.8, spread=1.5,
                                      chunkType='spark');
                bs.gameTimer(20,_emitExtraSparks)
                        
        bs.gameTimer(50,_doEmit)

        light = bs.newNode('light', attrs={
            'position': position,
            'volumeIntensityScale': 10.0,
            'color': (1, 0.3, 0.1)})

        s = random.uniform(0.6,0.9)
        scorchRadius = lightRadius = self.radius
        iScale = 1.6
        bsUtils.animate(light,"intensity", {
            0:0, 10:0.5, 20:1.0, 2000:0.5, 2750:0})
        bsUtils.animate(light,"radius", {
            0:0, 10:0.5, 20:1.0, 2000:0.5, 2750:0})
        bs.gameTimer(2750,light.delete)
        scorch = bs.newNode('scorch', attrs={
            'position':position,
            'size':scorchRadius*0.5,
            'big':False})
        scorch.color = (light.color[0]-0.05, light.color[1]-0.05, light.color[2]-0.07)
        bsUtils.animate(scorch,"presence",{3000:1, 8000:1, 13000:0})
        bs.gameTimer(13000,scorch.delete)
            
        p = light.position
        bs.playSound(factory.getRandomExplodeSound(),position=p)
        bs.playSound(factory.debrisFallSound,position=p)
        bs.shakeCamera(1.0)

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()

        if isinstance(msg, bs.DieMessage):
            self.node.delete()

        elif isinstance(msg, ExplodeHitMessage):
            node = bs.getCollisionInfo("opposingNode")
            if node is not None and node.exists():
                t = self.node.position
                node.handleMessage(bs.HitMessage(
                    pos=t,
                    velocity=(0,0,0),
                    magnitude=800.0,
                    hitType=self.hitType,
                    hitSubType=self.hitSubType,
                    radius=self.radius,
                    sourcePlayer=self.sourcePlayer, 
                    kickBack = 0))
                node.handleMessage(PoisonBombHitMessage())
        else:
            bs.Actor.handleMessage(self, msg)


class PoisonBomb(bs.Bomb):
    def __init__(self, position=(0,5,0), velocity=(0,1,0), sourcePlayer=None, owner=None):
        bs.Actor.__init__(self)
        self._exploded = False
        self._explodeCallbacks = []
        self.poisonTex = bs.getTexture('bombColor')
        self.poisonModel = bs.getModel('bomb')
        self.sourcePlayer = sourcePlayer
        factory = self.getFactory()
        materials = (factory.bombMaterial, bs.getSharedObject('objectMaterial')) + (factory.normalSoundMaterial,)
        fuseTime = 4500
        if owner is None: owner=bs.Node(None)
        self.node = bs.newNode('bomb', delegate=self, attrs={
            'position':position,
            'velocity':velocity,
            'body':'sphere',
            'model': self.poisonModel,
            'shadowSize':0.3,
            'colorTexture': self.poisonTex,
            'reflection':'soft',
            'reflectionScale':(1,1.5,1),
            'materials':materials})
        sound = bs.newNode('sound', owner=self.node, attrs={
            'sound':factory.fuseSound,
            'volume':0.25})
        self.node.connectAttr('position', sound, 'position')
        bsUtils.animate(self.node, 'fuseLength', {0:1.0, fuseTime:0.0})
        bs.gameTimer(fuseTime, bs.WeakCall(self.handleMessage, ExplodeMessage()))
        if "get_setting" in dir(bs) and bs.get_setting(name="timer_before_the_bomb_explode", default_value=False):
            m = bs.newNode('math', attrs={'input1': (0, 0.45, 0), 'operation': 'add'})
            self.node.connectAttr('position', m, 'input2')
            self._timer = bs.newNode('text', owner = self.node, attrs={'text':bs.Lstr(value='⌬'),'inWorld':True, 'position':(0,0,0), 'shadow':0.3, 'flatness':2.0, 'color':(3,0,0),'scale':0, 'hAlign':'center'})                                             
            m.connectAttr('output', self._timer, 'position')        
            bsUtils.animate(self._timer, 'scale', {0: 0.0, 240: 0.014})
            bsUtils.animateArray(self._timer, 'color',3, {0: (0,3,0), fuseTime: (3,0,0)},False)
            bs.gameTimer(fuseTime, bs.Call(self._timerDelete))
        bsUtils.animate(self.node,"modelScale",{0:0, 200:1.3, 260:1})
    def _timerDelete(self):
        self._timer = None
    def _handleHit(self, msg):
        isPunch = (msg.srcNode.exists() and msg.srcNode.getNodeType() == 'spaz')
        if not self._exploded and not isPunch:
            if msg.sourcePlayer not in [None]:
                self.sourcePlayer = msg.sourcePlayer
                self.hitType = msg.hitType
                self.hitSubType = msg.hitSubType

            bs.gameTimer(100+int(random.random()*100),
                         bs.WeakCall(self.handleMessage, ExplodeMessage()))
        self.node.handleMessage(
            "impulse", msg.pos[0], msg.pos[1], msg.pos[2],
            msg.velocity[0], msg.velocity[1], msg.velocity[2],
            msg.magnitude, msg.velocityMagnitude, msg.radius, 0,
            msg.velocity[0], msg.velocity[1], msg.velocity[2])

        if msg.srcNode.exists():
            pass

    def _handleDie(self,m):
        self.node.delete()
        if hasattr(self, "_timer") and self._timer is not None: self._timerDelete()

    def handleMessage(self, msg):
        if isinstance(msg, ExplodeMessage): self.explode()
        elif isinstance(msg, bs.PickedUpMessage):
            if self.sourcePlayer is not None: self.sourcePlayer = msg.node.sourcePlayer
        elif isinstance(msg, bs.HitMessage): self._handleHit(msg)
        elif isinstance(msg, bs.DieMessage): self._handleDie(msg)
        elif isinstance(msg, bs.OutOfBoundsMessage): self._handleOOB(msg)
        else: bs.Actor.handleMessage(self, msg)

    def explode(self):
        if self._exploded: return
        self._exploded = True
        activity = self.getActivity()
        if activity is not None and self.node.exists():
            blast = PoisonBombBlast(position=self.node.position, velocity=self.node.velocity,
                sourcePlayer=self.sourcePlayer,
                hitType='explosion',
                hitSubType='poison').autoRetain()
            for c in self._explodeCallbacks: c(self,blast)
        bs.gameTimer(1, bs.WeakCall(self.handleMessage, bs.DieMessage()))

class ZeroBossHitMessage(object):
    def __init__(self, type, subType, player, damage):
        self.type = type
        self.subType = subType
        self.player = player
        self.damage = damage

class ZeroBossDeathMessage(object):
    def __init__(self, badGuy, killerPlayer, how):
        self.badGuy = badGuy
        self.killerPlayer = killerPlayer
        self.how = how

class ZeroBoss(SpazBot):
    color=(0.5, 0.5, 2.5)
    highlight=(-0.5, -0.5, -2.5)
    character = 'Snake Shadow'
    defaultBombType = 'poison'
    punchiness = 0.4
    throwiness = 0.35
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 4
    throwDistMax = 9999
    pointsMult = 12000
    hp = 16000
    ph = 3.8
    defaultBombCount = 5
    def __init__(self):
        SpazBot.__init__(self)
        self.hitPoints = self.hitPointsMax = self.hp
        self._punchPowerScale = self.ph
    def __superHandleMessage(self, msg):
        super(SpazBot, self).handleMessage(msg)
    def dropBomb(self):
        if self.frozen or self.bombCount < 1: return
        p = self.node.positionForward
        v = self.node.velocity

        droppingBomb = True

        bomb = PoisonBomb(position=(p[0], p[1] - 0.0, p[2]),
                       velocity=(v[0], v[1], v[2]),
                       sourcePlayer=self.sourcePlayer,
                       owner=self.node).autoRetain()

        if droppingBomb:
            self.bombCount -= 1
            bomb.node.addDeathAction(bs.WeakCall(self.handleMessage, _BombDiedMessage()))
        self._pickUp(bomb.node)

        for c in self._droppedBombCallbacks: c(self, bomb)
        
        return bomb

    def handleMessage(self, msg):
        if isinstance(msg, PoisonBombHitMessage):
            PoisonEffect(owner = self.node)
            OtherEffect(text = "Poisoned", player = self.node, color = (0,2,0), opacity = 0.8, effectTime = 10000)
        elif isinstance(msg, bs.HitMessage):
            activity = self._activity()
            if (msg.hitSubType in ['bossBlast', 'impact', 'killLaKill', 'poisonEffect', 'poison', 'landMine']) or (msg.sourcePlayer is None): return True
            if msg.flatDamage:
                dmg = msg.flatDamage * 1.0
            else:
                dmg = 0.22 * self.node.damage
            if activity is not None:
                if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                    if dmg > 0.0:
                        activity.handleMessage(
                            ZeroBossHitMessage(msg.hitType, msg.hitSubType, msg.sourcePlayer, dmg * 1.0))
            if msg.sourcePlayer is not None and msg.sourcePlayer.exists():
                self.lastPlayerAttackedBy = msg.sourcePlayer
                self.lastAttackedTime = bs.getGameTime()
                self.lastAttackedType = (msg.hitType, msg.hitSubType)
            self.__superHandleMessage(msg)
        elif isinstance(msg, bs.DieMessage):
            # report normal deaths for scoring purposes
            if not self._dead and not msg.immediate:

                # if this guy was being held at the time of death, the
                # holder is the killer
                if (self.heldCount > 0 and self.lastPlayerHeldBy is not None
                        and self.lastPlayerHeldBy.exists()):
                    killerPlayer = self.lastPlayerHeldBy
                else:
                    # otherwise if they were attacked by someone in the
                    # last few seconds that person's the killer..
                    # otherwise it was a suicide
                    if (self.lastPlayerAttackedBy is not None
                           and self.lastPlayerAttackedBy.exists()
                           and bs.getGameTime() - self.lastAttackedTime < 4000):
                        killerPlayer = self.lastPlayerAttackedBy
                    else:
                        killerPlayer = None
                activity = self._activity()

                if killerPlayer is not None and not killerPlayer.exists():
                    killerPlayer = None
                if activity is not None: activity.handleMessage(ZeroBossDeathMessage(self, killerPlayer, msg.how))
            self.__superHandleMessage(msg) # augment standard behavior
        else:
            SpazBot.handleMessage(self, msg)

class ZeroBossBotSpecial(SpazBot):
    color=(0, 0, 0)
    highlight=(-0.5, -0.5, -2.5)
    character = 'Snake Shadow'
    defaultBombType = 'impact'
    punchiness = 0.4
    throwiness = 0.35
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 4
    throwDistMax = 9999
    pointsMult = 60
    hp = 3250
    ph = 1.2
    defaultBombCount = 1
    def __init__(self):
        SpazBot.__init__(self)
        self.hitPoints = self.hitPointsMax = self.hp
        self._punchPowerScale = self.ph
    def handleMessage(self, msg):
        if PoisonBombHitMessage is not None and isinstance(msg, PoisonBombHitMessage):
            PoisonEffect(owner = self.node), OtherEffect(text = "Poisoned", player = self.node, color = (0,2,0), opacity = 0.8, effectTime = 10000)
        elif isinstance(msg, bs.HitMessage) and hasattr(msg, "hitSubType") and msg.hitSubType == "poisonEffect": 
            mag = msg.magnitude * 1.0
            damage = self.node.damage * 0.22
            self.node.handleMessage(
                "impulse", msg.pos[0], msg.pos[1], msg.pos[2],
                msg.velocity[0], msg.velocity[1], msg.velocity[2],
                mag, velocityMag, msg.radius, 0,
                msg.forceDirection[0], msg.forceDirection[1],
                msg.forceDirection[2])
            self.hitPoints -= damage
            self.node.hurt = 1.0 - float(self.hitPoints)/self.hitPointsMax
        else: SpazBot.handleMessage(self, msg)

class ZeroBossBot(SpazBot):
    color=(1,1,1)
    highlight=(3, 3, 3)
    character = 'Snake Shadow'
    defaultBombType = 'normal'
    punchiness = 2.2
    throwiness = 0
    run = True
    bouncy = True
    defaultShields = True
    chargeDistMin = 0
    chargeDistMax = 0.5
    chargeSpeedMin = 1
    chargeSpeedMax = 1
    throwDistMin = 9998
    throwDistMax = 9999
    pointsMult = 30
    hp = 920
    ph = 2.2
    defaultBombCount = 1
    def __init__(self):
        SpazBot.__init__(self)
        self.hitPoints = self.hitPointsMax = self.hp
        self._punchPowerScale = self.ph
    def handleMessage(self, msg):
        if PoisonBombHitMessage is not None and isinstance(msg, PoisonBombHitMessage):
            PoisonEffect(owner = self.node), OtherEffect(text = "Poisoned", player = self.node, color = (0,2,0), opacity = 0.8, effectTime = 10000)
        elif isinstance(msg, bs.HitMessage) and hasattr(msg, "hitSubType") and msg.hitSubType == "poisonEffect": 
            mag = msg.magnitude * 1.0
            damage = self.node.damage * 0.22
            velocityMag = msg.velocityMagnitude * 1.0
            self.node.handleMessage(
                "impulse", msg.pos[0], msg.pos[1], msg.pos[2],
                msg.velocity[0], msg.velocity[1], msg.velocity[2],
                mag, velocityMag, msg.radius, 0,
                msg.forceDirection[0], msg.forceDirection[1],
                msg.forceDirection[2])
            self.hitPoints -= damage
            self.node.hurt = 1.0 - float(self.hitPoints)/self.hitPointsMax
        else: SpazBot.handleMessage(self, msg)

def bsGetAPIVersion():
    return 4

def bsGetGames():
    return [ZeroGameUpdated]

def bsGetLevels():
    return [bs.Level('Zero Chance', displayName='${GAME}', gameType=ZeroGameUpdated, settings={'HardCore?':False}, previewTexName='black')]

class ZeroGameUpdated(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'Zero Chance\'s'

    @classmethod
    def getScoreInfo(cls):
        return {'scoreName': 'Score', 'scoreType': 'points'}

    @classmethod
    def getDescription(cls, sessionType):
        return 'Stay alive.'

    @classmethod
    def getSupportedMaps(cls, sessionType):
        return ['Football Stadium']

    @classmethod
    def supportsSessionType(cls, sessionType):
        return True if issubclass(sessionType, bs.FreeForAllSession) or issubclass(sessionType, bs.CoopSession) else False

    @classmethod
    def getSettings(cls, sessionType):
        return []

    def __init__(self, settings):
        bs.TeamGameActivity.__init__(self, settings)        
        self._scoreBoard = bs.ScoreBoard()
        self._bots = bs.BotSet()

    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='Scary')

    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)
        self.damage = {'boss': 0, 'bots': 0, 'now': 0, 'next': 9000}
        self.respawn = 0
        self.boss = None
        self.st = 1
        self._bots.spawnBot(ZeroBoss, pos=(0, 0.5, 0), spawnTime=5000, onSpawnCall=self.set_boss_node)
        self._updateTimer = bs.Timer(1000, bs.Call(self._update), repeat = True)
        self._attackTimer = {bs.getRealTime()+19000: bs.Timer(19000, bs.Call(self._rnd_attack, "19000_0"))}
        self._update()
        self.tpSound = bs.getSound('block')
        self.result = {}
        self._all = ['light_attack', 'spawnBots', 'circles_on_floor', 'bomb_worker', \
            'teleport', 'impact_bombs_attack']

    def set_boss_node(self, spaz=None):
        self.boss = spaz

    def _update_timer(self, force=False):
        time = 20000
        if self.st == 2: time=16000
        if self.st == 3: time=12000
        if self.st == 4: time=9000
        if self.st > 4: time=6000
        key = bs.getRealTime()+time
        if self._attackTimer is not None:
            if len(self._attackTimer) > 1:
                try:
                    for i in self._attackTimer:
                        if i < bs.getRealTime(): self._attackTimer.pop(i)
                except RuntimeError: pass # kak naxer
            if force: self._attackTimer[key] = bs.Timer(time, bs.Call(self._rnd_attack, key))

    def _rnd_attack(self, key=27654):
        if self.st > 0:
            stinfo = {1: (0, 3), 2: (4, 6), 3: (7, 10), 4: (11, 16)}
            if key in self._attackTimer: self._attackTimer.pop(key)
            while True:
                rnd = random.randint(stinfo.get(self.st, (11, 16))[0], stinfo.get(self.st, (11, 16))[1])
                if getattr(self, 'last_attack', 0) != rnd:
                    self.last_attack = rnd
                    break
            def attack():
                self.attack_number = getattr(self, 'attack_number', 0)+1
                self._update_timer(force=True)
                if self.st == 1:
                    if rnd == 0: self.light_attack(type='multi')
                    elif rnd == 1: self.light_attack(type='vertical')
                    elif rnd == 2: self.light_attack(type='horizontal')
                    elif rnd == 3: self.circles_on_floor()
                elif self.st == 2:
                    if rnd == 4: self.bomb_worker()
                    elif rnd == 5: self.light_attack(type='multi')
                    elif rnd == 6: self.spawnBots()
                elif self.st == 3:
                    if rnd == 7: self.circles_on_floor()
                    elif rnd == 8: self.impact_bombs_attack()
                    elif rnd == 9: self.spawnBots()
                    elif rnd == 10: self.light_attack(type='multi')
                elif self.st > 3:
                    if rnd == 11: self.circles_on_floor()
                    elif rnd == 12: self.bomb_worker(count=random.randint(2,4))
                    elif rnd == 13: self.teleport(alert=True, count=(random.randint(1,3)*7))
                    elif rnd == 14: self.light_attack(type='horizontal')
                    elif rnd == 15: self.impact_bombs_attack(count=random.randint(1,2), interval=(random.randint(1,6)*1000))
                    elif rnd == 16: self.spawnBots()
            self.heal()
            bs.gameTimer(1000, bs.Call(attack))
        else: self._attackTimer = None

    def _update(self):
        self.maxRespawn = len(self.players) * 5
        self.damage.update({'now': self.damage.get('boss', 0)+self.damage.get('bots', 0)})
        self._update_timer(force=False)
        if self.damage['now'] > self.damage.get('next', 10000):
            if self.st > 0:
                damage = self.damage.get('now', 0)
                self.st = 1
                if damage > 10000: 
                    self.st = 2
                    self.damage.update({'next': 16050})
                if damage > 16050: 
                    self.st = 3
                    self.damage.update({'next': 22500})
                if damage > 22500:
                    self.st = 4
                    self.damage.update({'next': 304500})
                if damage > 304500:
                    self.st = 5
                    self.damage.update({'next': 99999999999999999})

    def spawnPlayerSpaz(self, player, position=None, angle=None):
        """
        Method override; spawns and wires up a standard bs.PlayerSpaz for
        a bs.Player.

        If position or angle is not supplied, a default will be chosen based
        on the bs.Player and their bs.Team.
        """
        if position is None:
            # in teams-mode get our team-start-location
            if isinstance(self.getSession(), bs.TeamsSession):
                position = \
                    self.getMap().getStartPosition(player.getTeam().getID())
            else:
                # otherwise do free-for-all spawn locations
                position = self.getMap().getFFAStartPosition(self.players)

        return self.spawnPlayerSpaz0(player, position, angle)

    def spawnPlayerSpaz0(self, player, position=(0, 0, 0), angle=None):
        name = player.getName()
        color = player.color
        highlight = player.highlight

        lightColor = bsUtils.getNormalizedColor(color)
        
        displayColor = bs.getSafeColor(color, targetIntensity=0.75)
        spaz = InGamePlayerSpaz(color=color,
                             highlight=highlight,
                             character=player.character,
                             player=player)
        player.setActor(spaz)

        # if this is co-op and we're on Courtyard or Runaround, add the
        # material that allows us to collide with the player-walls
        # FIXME; need to generalize this
        if isinstance(
                self.getSession(),
                bs.CoopSession) and self.getMap().getName() in[
                'Courtyard', 'Tower D']:
            mat = self.getMap().preloadData['collideWithWallMaterial']
            spaz.node.materials += (mat,)
            spaz.node.rollerMaterials += (mat,)

        spaz.node.name = name
        spaz.node.nameColor = displayColor
        spaz.connectControlsToPlayer()
        self.scoreSet.playerGotNewSpaz(player, spaz)

        # move to the stand position and add a flash of light
        spaz.handleMessage(
            bs.StandMessage(
                position, angle
                if angle is not None else random.uniform(0, 360)))
        t = bs.getGameTime()
        bs.playSound(self._spawnSound, 1, position=spaz.node.position)
        light = bs.newNode('light', attrs={'color': lightColor})
        spaz.node.connectAttr('position', light, 'position')
        bsUtils.animate(light, 'intensity', {0: 0, 250: 1, 500: 0})
        bs.gameTimer(500, light.delete)
        return spaz

    def spawnPlayer(self, player):
        spaz = self.spawnPlayerSpaz(player)
        spaz.connectControlsToPlayer()

    def celebratePlayers(self):
        for i in self.players:
            if i.exists() and i.isAlive(): i.actor.node.handleMessage("celebrate", 10000.0)

    def heal(self):
        def spawn():
            spawnCounts = 0
            players = [i for i in self.players if i.exists() and i.isAlive() and i.actor.hitPoints < 500]
            if self.st > 2: spawnCounts = min(2, len(players))
            if spawnCounts > 0:
                if len(players) > 0:
                    if self.getMap().defs is not None: 
                        positions = [self.getMap().defs.points.get('powerupSpawn'+str(i), (0, 5, 0)) for i in range(4)]
                        for i in range(spawnCounts): bs.Powerup(powerupType='health', position = random.choice(positions)).autoRetain()
        spawn()
        

    def checkInAlertPlayers(self, type='custom'):
        def check_position(bounds = ((-15, 15), (-2, 2)), position=None):
            if position is not None:
                if int(position[0]) in range(bounds[0][0], bounds[0][1]) and int(position[2]) in range(bounds[1][0], bounds[1][1]): return True
            return False
        for i in self.players:
            if i.exists() and i.isAlive():
                pos = i.actor.node.position
                boss_pos = self.boss.node.position if self.boss is not None and self.boss.exists() and self.boss.isAlive() else None
                if type == 'all': TextOnScreen(owner = i.actor.node)
                else:
                    if (type == 'horizontal' and check_position(bounds=((-15,15), (-2,2)), position=pos)) or (type == 'vertical' and 
                        check_position(bounds=((-2,2), (-15,15)), position=pos)) or (type == 'center' and 
                        check_position(bounds=((-3,3), (-2,2)), position=pos)) or (type == 'custom' and boss_pos is not None and 
                        check_position(bounds=((-3,3), (-3,3)), position=boss_pos)): TextOnScreen(owner = i.actor.node)

    def spawnBots(self):
        if len(self._bots.getLivingBots()) < 2:
            if self.st > 1:
                for i in range(2): self._bots.spawnBot(ZeroBossBot, pos=(random.randint(-1,1),1,random.randint(-1,1)), spawnTime=1000)
            if self.st > 2:
                for i in range(2): self._bots.spawnBot(ZeroBossBotSpecial, pos=(random.randint(-1,1),1,random.randint(-1,1)), spawnTime=1)
        else: self.light_attack('multi')

    def light_attack(self, type='vertical'):
        type = [type] if type != 'multi' else ['horizontal','vertical']
        def start():
            for i in type: ZeroBossBlast(type=i).autoRetain()
        for i in type: self.checkInAlertPlayers(type=i)
        bs.gameTimer(2000+(random.randint(0, 4)*100), bs.Call(start))

    def circles_on_floor(self):
        self.checkInAlertPlayers(type='all')
        def start():
            ZeroBossBlast(type='sphere').autoRetain()
        for i in range(30+random.randint(0,10)): bs.gameTimer(300 + (i*50), bs.Call(start))

    def bomb_worker(self, count=1):
        def start():
            ZeroBossCircle(time=5000, position=random.choice([(-8, 1.5, 0), (8, 1.5, 0), (0, 1.5, 0)]), times=1, radius=0.5)
        self.checkInAlertPlayers(type='center')
        for i in range(count): 
            bs.gameTimer(1000+(4000*i)+(random.randint(0,10)*100), bs.Call(start))

    def teleport(self, count=1, interval=100, alert=False, sound=True):
        if self.boss is not None and self.boss.exists() and self.boss.isAlive():
            if alert: self.checkInAlertPlayers(type='custom')
            if sound and count < 2: 
                try: bs.playSound(self.tpSound, 0.5, position=self.boss.node.position)
                except: pass
            mapBounds = self.getMap().spawnPoints
            def start():
                pos = (random.uniform(mapBounds[0][0], mapBounds[1][0]), random.uniform(mapBounds[0][1], mapBounds[1][1]), random.uniform(mapBounds[0][2], mapBounds[1][2]))
                bs.emitBGDynamics(position=pos, velocity=(0.1,-1,0.1),
                    count=random.randint(30, 50), scale=0.35,
                    spread=0.2, chunkType='spark')
                self.boss.node.handleMessage("stand", pos[0], pos[1], pos[2], random.randrange(0,360))
            for i in range(count): bs.gameTimer(100+(i*interval), bs.Call(start))
        else: return 

    def impact_bombs_attack(self, count=1, interval=1000):
        self.checkInAlertPlayers(type='center')
        def start():
            for i in range(8):
                for c in [(i, i), (-i, -i), (-i, i), (i, -i)]: bs.Bomb(position=(c[0],7,c[1]), velocity=(0,0,0), bombType='impact', blastRadius=1, sourcePlayer=None).autoRetain()
        for i in range(count): bs.gameTimer(2000+(i*interval), bs.Call(start))

    def handleMessage(self, m):
        if isinstance(m, bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self, m)
            self.respawn += 1
            if self.respawn > self.maxRespawn: 
                self.endGame()
            else: 
                self._aPlayerHasBeenKilled = True
                player = m.spaz.getPlayer()
                if not player.exists(): return
                self.scoreSet.playerLostSpaz(player)
                respawnTime = 1000+len(self.initialPlayerInfo)*2500
                player.gameData['respawnTimer'] = bs.Timer(respawnTime, bs.Call(self.spawnPlayerIfExists, player))
                player.gameData['respawnIcon'] = bs.RespawnIcon(player, respawnTime)
        elif isinstance(m, ZeroBossDeathMessage):
            self.celebratePlayers()
            self.damage['bots'] += 16000
            bs.gameTimer(5000, bs.Call(self.endGame))
        elif isinstance(m, bs.SpazBotDeathMessage):
            self.damage['bots'] += 1000
        elif isinstance(m, ZeroBossHitMessage):
            self.damage['boss'] += m.damage*1.0
            if m.player is not None and m.player.exists(): 
                if hasattr(m.player, 'getTeam'): team=m.player.getTeam()
                else: team = None
                if team is not None: team.gameData.update({'score': team.gameData.get('score', 0)+m.damage})
            if self.boss is not None and self.boss.exists() and self.boss.isAlive():
                if self.st > 3 and m.type == 'punch': 
                    self.boss.hitPoints = min(self.boss.hitPoints+(m.damage*0.3), self.boss.hitPointsMax)
                if self.boss.hitPoints < 3000: 
                    if self.st > 3: 
                        self.teleport(count=28, interval=50)
                        self.boss.hitPoints = min(self.boss.hitPoints+(m.damage*0.75), self.boss.hitPointsMax)
                    else: 
                        if m.type == 'punch' or m.type == 'explosion': 
                            self.boss.node.handleMessage('knockout', int(m.damage))
                            self.boss.hitPoints = min(self.boss.hitPoints+(m.damage*0.4), self.boss.hitPointsMax)
                        self.teleport()
                else:
                    if m.type == 'punch' and m.damage > 400 and self.st > 1: self.teleport()
                    if m.type == 'explosion' and m.damage > 1000 and self.st > 2: self.teleport()
        else:
            bs.TeamGameActivity.handleMessage(self, m)

    def endGame(self):
        self.st = 0
        results = bs.TeamGameResults()
        for team in self.teams:
            results.setTeamScore(team, int(max(0, team.gameData.get('score', 0)+self.damage['bots']*0.72+self.damage['boss']-(self.respawn*1000))))
        self._attackTimer = None
        self._updateTimer = None
        self.end(results)

class ZeroBossCircle(object):
    def __init__(self, time=10000, position=(0,1.5,0), times = 2, radius=1):
        self.endCircleTime = time
        self.circlePos = position
        self.times = times
        self.radius = radius
        if self.endCircleTime < 3000: self.endCircleTime = 3000
        def start():
            self.spawn()
        for i in range(self.times):
            bs.gameTimer((self.endCircleTime/2)*(i), bs.Call(start))
        self.light = bs.newNode('light', attrs={'position':self.circlePos,'color':(1,0.35,0),'radius':self.radius})
        bsUtils.animate(self.light, 'intensity', {0:0, 1000:1.5, self.endCircleTime-1000:1.5, self.endCircleTime:0})
        bsUtils.animate(self.light, 'radius', {0:self.radius/1.2, 700:self.radius/1.2, 1000:self.radius, 2000:self.radius/1.2}, loop=True)
        bs.gameTimer(int(self.endCircleTime*1.0), self.light.delete)
    def spawn(self):
        speed = 6
        def bomb0():
            bs.Bomb(position=self.circlePos, velocity=(0,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(0,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb1():
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(speed,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb2():
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,0), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(speed,0,0), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        def bomb3():
            bs.Bomb(position=self.circlePos, velocity=(speed,0,speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
            bs.Bomb(position=self.circlePos, velocity=(-speed,0,-speed), bombType='normal', blastRadius=2.0, sourcePlayer=None).autoRetain()
        mult = self.endCircleTime/10
        bs.gameTimer(mult*1, bs.Call(bomb0))
        bs.gameTimer(mult*2, bs.Call(bomb1))
        bs.gameTimer(mult*3, bs.Call(bomb2))
        bs.gameTimer(mult*4, bs.Call(bomb3))

class ZeroBossBlastExample(object):
    def __init__(self, position=(0,0,0), color=(1,0.75,0), radius=0.3, mult=1.05, startTime=1, endTime=2001):
        self.death = endTime
        self.start = startTime
        self.position = position
        self.color = color
        self.radius = radius
        self.mult = mult
        bs.gameTimer(int(self.start*1.0), self.spawn)
    def spawn(self):
        self.light = bs.newNode('light', attrs={'position':self.position,'color':self.color,'radius':self.radius})
        bsUtils.animate(self.light, 'intensity', {0:0, 1000:1.75, int(self.death*1.0):1.75, int(self.death*1.0)+1000:0})
        bsUtils.animate(self.light, 'radius', {0:self.radius, 3000:self.radius*self.mult, 4500:self.radius}, True)
        bs.gameTimer(int(self.death*1.0)+1000, self.light.delete)

class ZeroBossBlast(bs.Actor):
    def __init__(self,position=(0,1,0),time=5000,type = 'horizontal'):
        bs.Actor.__init__(self)
        factory = self.getFactory()
        self.pos = position
        self.scale = (1,1,1)
        self.time = time
        self.m = type
        if (self.m in ['horizontal','vertical']):
            if self.m == 'horizontal': 
                for i in range(30):
                    ZeroBossBlastExample(position=(-15+i,0,0), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1+(i*30), endTime=(1+int(self.time*1.0)))
                self.scale = (20,10,0.1)
            elif self.m == 'vertical':
                for i in range(20):
                    ZeroBossBlastExample(position=(0,0,-10+i), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1+(i*30), endTime=(1+int(self.time*1.0)))
                self.scale = (0.1,10,20)
            def spawn():
                self.node = bs.newNode('region', delegate=self, attrs={'position':(self.pos[0],self.pos[1]-0.1,self.pos[2]),'scale':self.scale,'type':'box','materials':(factory.newBlastMaterial, bs.getSharedObject('attackMaterial'))})
                bs.gameTimer(int(self.time*1.0), self.node.delete)
            bs.gameTimer(500, bs.Call(spawn))
        elif (self.m in ['sphere']):
            self.scale = (0.6,10,0.6)
            randPos = (random.randrange(-12,12),1,random.randrange(-5,5))
            def spawn():
                self.node = bs.newNode('region', delegate=self, attrs={'position':(randPos[0],randPos[1]-0.1,randPos[2]),'scale':self.scale,'type':'sphere','materials':(factory.newBlastMaterial, bs.getSharedObject('attackMaterial'))})
                bs.gameTimer(int(self.time*1.0), self.node.delete)
            bs.gameTimer(500, bs.Call(spawn))
            ZeroBossBlastExample(position=(randPos[0],randPos[1]-0.1,randPos[2]), color=(1,0.5,0), radius=0.1, mult=1.05, startTime=1, endTime=(1+int(self.time*1.0)))

    def getFactory(cls):
        activity = bs.getActivity()
        try: return activity._sharedZeroBossBlastFact
        except Exception:
            f = activity._sharedZeroBossBlastFact = ZeroBossBlastFactory()
            return f

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if isinstance(msg, bs.DieMessage): 
            self.node.delete()
        elif isinstance(msg, NewExplodeHitMessage):
            node = bs.getCollisionInfo("opposingNode")
            if node is not None and node.exists():
                t = self.node.position
                tr = node.position
                if (node.getNodeType() == 'spaz'):
                    node.handleMessage(bs.HitMessage(
                        pos=tr,
                        velocity=(0,0,0),
                        magnitude=550.0,
                        hitType='explosion',
                        hitSubType='bossBlast',
                        radius=100.0,
                        sourcePlayer=bs.Player(None), 
                        kickBack=0))
                    node.handleMessage('impulse',tr[0],tr[1]-2,tr[2],0,0,0,2000,0,200.0,1,0,100,0)
        else:
            bs.Actor.handleMessage(self, msg)

class ZeroBossBlastFactory(object):
    def __init__(self):
        self.blastSound = bs.getSound('activateBeep')
        self.newBlastMaterial = bs.Material()
        self.newBlastMaterial.addActions(
            conditions=(('theyHaveMaterial',
                         bs.getSharedObject('objectMaterial'))),
            actions=(('modifyPartCollision','collide',True),
                     ('modifyPartCollision','physical',False),
                     ('message','ourNode','atConnect',NewExplodeHitMessage())))

class NewExplodeHitMessage(object):
    def __init__(self):
        pass

class TextOnScreen(object):
    def __init__(self, color=(3,0,0), scale=0.0095, time=2000, position='player', opacity=1, text='Alert!', owner=None):
        self.color = color
        self.scale = scale
        self.end = time
        self.owner = owner
        self.pos = position if position != 'player' else (0,0,0)
        self.flatness = opacity
        self.text = text
        if self.owner is not None:
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 2.325, 0), 'operation': 'add'})
            self.owner.connectAttr('position', m, 'input2')                        
            self._text = bs.newNode('text', owner=self.owner, attrs={'text':self.text, 'inWorld':True, 'position':self.pos, 'flatness':0, 'color':self.color, 'scale':0, 'hAlign':'center'})
            m.connectAttr('output', self._text, 'position')
        else: self._text = bs.newNode('text', attrs={'text':self.text, 'inWorld':True, 'position':self.pos, 'flatness':0, 'color':self.color, 'scale':0, 'hAlign':'center'})
        bsUtils.animate(self._text, 'scale', {0:0, 250:self.scale, int(self.end*1.0):self.scale, int(self.end*1.0)+500:0.0})
        bsUtils.animate(self._text, 'opacity', {0:self.flatness/1.5, 250:self.flatness, 500:self.flatness/1.5}, loop = True)
        bs.gameTimer(int(self.end*1.0)+500, self._text.delete)
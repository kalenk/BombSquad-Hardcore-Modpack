import bs
import bsInternal
import bsUtils

class ChangeTime(object):
    def __init__(self):
        self.data={"tint":None, "motion":False}
        self.animate = None
        self.animateMotion = None

    def get(self):
        a = bsInternal._getForegroundHostActivity()
        if a is not None:
            with bs.Context(a):
                import chatCmd
                self.tint = chatCmd.get()
                self.motion = chatCmd.get(type='motion')
        else: 
            self.tint = None
            self.motion = None

    def stop(self):
        self.animate = None
        self.animateMotion = None

    def start(self, type, tint=None):
        type=type if type in ['cycle','usual'] else 'cycle'
        if tint is None:
            import chatCmd
            tint=chatCmd.get()
        if tint is not None:
            if type == 'cycle':
                anim={0:tint, 7500:(1.25, 1.21, 1.075), 30000:(1.25, 1.21, 1.075), \
                    57500:(1.1, 0.86, 0.74), 67500:(1.1, 0.86, 0.74), \
                    90000:(0, 0.27, 0.51), 120000:(0, 0.27, 0.51), 142500:(1.3, 1.06, 1.02), \
                    157500:(1.3, 1.06, 1.02), 180000:(1.3, 1.25, 1.2), 195500:(1.3, 1.25, 1.2), \
                    220000:tint}
                self.animate = bsUtils.animateArray(bs.getSharedObject('globals'), 'tint', 3, anim, True)
                self.animateMotion = None
            else:
                self.tint=chatCmd.get_normal_tint()
                self.get()
                self.animate = bsUtils.animateArray(bs.getSharedObject('globals'), 'tint',3, {0:tint, 31:(0,0,0.2), 461:self.tint}, False)
                self.animateMotion = bsUtils.animate(bs.getSharedObject('globals'), 'slowMotion', {0:self.motion, 31:not self.motion, 461:self.motion})
                bs.gameTimer(500, self.end)

    def end(self):
        bsUtils.animateArray(bs.getSharedObject('globals'), 'tint',3, {0:bs.getSharedObject('globals').tint, 461:self.tint}, False)
        bs.gameTimer(461, bs.Call(self.stop))

    def give(self, tint=None, motion=None):
        if tint is not None: self.tint = tint
        if motion is not None: self.motion = motion

    def getGlobal(self, arg=None):
        if arg == 'tint': return self.tint
        elif arg == 'motion': return self.motion
    

c = ChangeTime()
def animate(type='usual', tint=None):
    c.start(type=type, tint=tint)

def animatestop():
    c.stop()

def getInfo(type='tint'):
    if type == 'tint': return c.getGlobal(arg='tint')
    elif type == 'motion': return c.getGlobal(arg='motion')

def giveInfo(tint=None, motion=None):
    c.give(tint,motion)
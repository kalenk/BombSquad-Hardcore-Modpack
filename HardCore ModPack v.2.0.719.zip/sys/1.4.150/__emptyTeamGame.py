import bs
import random

def bsGetAPIVersion():
    return 4

def bsGetGames():
    return [EmptyGameSecond]

def bsGetLevels():
    return [bs.Level('Empty Game', displayName='${GAME}', gameType=EmptyGameSecond, settings={}, previewTexName='black')]

class EmptyGameSecond(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return "Testing"

    @classmethod
    def getScoreInfo(cls):
        return {'scoreName': 'Score',
                'scoreType': 'points'}

    @classmethod
    def getDescription(cls, sessionType):
        return "Just for fun"

    @classmethod
    def getSupportedMaps(cls, sessionType):
        return ["Doom Shroom","Hockey Stadium","Football Stadium","Big G", \
                        "Roundabout","Monkey Face","Bridgit","Zigzag","The Pad","Lake Frigid",\
                        "Tip Top","Crag Castle","Tower D","Happy Thoughts","Step Right Up",\
                        "Courtyard","Rampage"]

    @classmethod
    def supportsSessionType(cls, sessionType):
        return True

    @classmethod
    def getSettings(cls, sessionType):
        return []

    def __init__(self, settings):
        bs.TeamGameActivity.__init__(self, settings)

    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='ForwardMarch')

    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)
        bs.getSound("spawn")
        
    def handleMessage(self, m):
        if isinstance(m, bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self, m) 
            self._aPlayerHasBeenKilled = True
            player = m.spaz.getPlayer()
            if not player.exists(): return
            respawnTime = 100+len(self.initialPlayerInfo)*100
            player.gameData['respawnTimer'] = bs.Timer(respawnTime, bs.Call(self.spawnPlayerIfExists, player))
            player.gameData['respawnIcon'] = bs.RespawnIcon(player, respawnTime)
        else:
            bs.TeamGameActivity.handleMessage(self, m)
    
    def spawnPlayer(self, player):
        spaz = self.spawnPlayerSpaz(player)
        spaz.connectControlsToPlayer()

    def endGame(self):
        results = bs.TeamGameResults()
        for team in self.teams:
            results.setTeamScore(team, 0)
        self.end(results)

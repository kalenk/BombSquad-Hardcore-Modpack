from .text import *
from .__init__ import get_setting
import bsUI
import bsInternal
import bs

def _filterChatMessage(msg, clientID):
    if bsInternal._getForegroundHostActivity() is not None:
        with bs.Context(bsInternal._getForegroundHostActivity()):
            if get_setting(name="chat_commands_enabled"):
                import chatCmd
                if format_spaces(msg=msg.lower()).split(" ")[0] in chatCmd.commands:
                    temp=""
                    if len(bsInternal._getGameRoster()) > 0:
                        for i in bsInternal._getGameRoster():
                            if i["clientID"] == clientID:
                                if len(i["players"]) > 0:
                                    for n in range(len(i["players"])): temp+=(i["players"][n]["name"] if i["players"][n]["name"] == i["players"][0]["name"] else ("/"+i["players"][n]["name"]))
                                else: temp=i["displayString"]
                    else:
                        if len(bsInternal._getForegroundHostActivity().players) > 0:
                            for i in bsInternal._getForegroundHostActivity().players: temp+=i.getName()
                        else: temp = bsInternal._getAccountName(False)
                        if len(temp) > 10: temp = temp[:10] + "..."
                    temp=bs.utf8(temp)+": "+format_spaces(msg=msg).lower()
                    bsInternal._log(temp)
                    chatCmd.cmd(temp)
    return msg
bsUI._filterChatMessage = _filterChatMessage
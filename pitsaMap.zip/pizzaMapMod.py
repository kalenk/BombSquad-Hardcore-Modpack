# -*- coding: utf-8 -*-
import bs
import shutil, os
import bsInternal

version = 11

#writed by drov.drov

class MapDefs:
    def __init__(self):
        self.points, self.boxes = {}, {}
        self.points['ffaSpawn1'] = (-5.63146, 0.86888, -5.49035) + (0.80872, 0.05, 0.80669)
        self.points['ffaSpawn2'] = (5.62503, 0.88152, 5.77077) + (0.80637, 0.05, 0.81611)
        self.points['ffaSpawn3'] = (5.74158, 0.29753, -5.56487) + (0.80027, 0.05, 0.82515)
        self.points['ffaSpawn4'] = (-5.58582, 0.86787, 5.78048) + (0.76742, 0.05, 0.79699)
        self.points['flag2'] = (5.01741, 0.75494, -0.01127)
        self.points['flag1'] = (-4.98648, 0.8644, 0.009)
        self.points['flagDefault'] = (0.01799, 1.07604, -0.00189)
        self.points['powerupSpawn1'] = (-4.46708, 0.86892, 4.50733)
        self.points['powerupSpawn2'] = (4.47144, 0.85466, -4.48573)
        self.points['powerupSpawn3'] = (4.45078, 0.86645, 4.56213)
        self.points['powerupSpawn4'] = (-4.46708, 0.87874, -4.5154)
        self.points['shadowLowerBottom'] = (-8.58973, -2.52382, 11.44724)
        self.points['shadowLowerTop'] = (-8.63258, -0.09581, 11.44724)
        self.points['shadowUpperBottom'] = (10.71258, 9.98874, -6.53996)
        self.points['shadowUpperTop'] = (10.71258, 10.70252, -6.53996)
        self.points['spawn1'] = (-6.21933, 0.86559, 0.19553) + (0.18289, 0.05, 2.19598)
        self.points['spawn2'] = (6.28882, 0.88058, 0.19359) + (0.1954, 0.05, 2.22167)
        self.boxes['areaOfInterestBounds'] = (0.43967, -1.44778, 1.57821) + (0, 0, 0) + (69.69495, 42.61848, 34.81906)
        self.boxes['levelBounds'] = (0.0344, 17.80806, -0.14702) + (0, 0, 0) + (51.3223, 52.40075, 57.54623)
        self.points['floor'] = (0, 0, 0)

env = bs.getEnvironment()
gAndroid = env['platform'] == 'android'
gPath = 'data' if not gAndroid else '/data/data/net.froemling.bombsquad/files/bombsquad_files/data'

map_name = 'Pitsa'
working_path = os.path.join(env['userScriptsDirectory'], 'PitsaBox')
data_path = os.path.join(gPath, 'pitsaMapMod.data')
file_types = {'.ktx' if gAndroid else '.dds': 'textures', '.bob': 'models', '.ogg': 'audio', '.cob': 'models'}

translates = {
    "Russian": {
        "installStartedText": "Установка карты \"{}\"",
        "copyingText": "Копирование файла {}",
        "installCompleteText": "Установка завершена!"},
    "English": {
        "installStartedText": "Installing map \"{}\"",
        "copyingText": "Copying file {}",
        "installCompleteText": "Install complete!"}
    }

time_skip = 200 # time rate while copying 
translates = translates.get(bs.getLanguage(), translates.get("English", {}))

def run(call=None):
    a = bsInternal._getForegroundHostActivity()
    if call is None: call = lambda x : True
    if a is not None: bs.realTimer(time_skip, bs.Call(call))
    else: bs.realTimer(time_skip, bs.Call(run, call))

def install():
    v = 0
    if os.path.exists(data_path): 
        with open(data_path, 'r') as f:
            v = f.read()
            f.close()
        try: v = int(v.replace('.', ''))
        except ValueError: v = 0
    if v < version: copyfiles()
    else: add_map()

def copyfiles():
    bs.screenMessage(translates.get("installStartedText", "installing map \"{}\"").format(map_name), color=(1,0.85,0))
    def copy(dst, src):
        filename = dst.split(os.path.sep)[-1]
        filepath = os.path.join(src, filename)
        if os.path.exists(filepath): os.remove(filepath)
        bs.screenMessage(translates.get("copyingText", "copying... {}").format(filename), color=(1, 1, 0))
        try: shutil.copy(dst, src)
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
    if os.path.exists(working_path) and os.path.isdir(working_path):
        try:
            files = os.listdir(working_path)
            for i in range(len(files)):
                file = os.path.join(working_path, files[i])
                type = None
                for c in file_types: 
                    if file.endswith(c): 
                        type = file_types[c]
                        break
                if type is not None and os.path.isfile(file): bs.realTimer(time_skip * i + time_skip, bs.Call(copy, file, os.path.join(gPath, type)))
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
        else:
            with open(data_path, 'w+') as f:
                f.write(str(version))
                f.close()
            def end():
                add_map()
                bs.screenMessage(translates.get("installCompleteText", "install complete!").format(map_name), color=(1,0.85,0))
            bs.realTimer(time_skip * len(files) + time_skip * 2, bs.Call(end))
    else: bs.screenMessage("Can not find path: "+str(working_path), color=(1,0,0))

def add_map():
    from bsMap import Map, registerMap
    from bsBomb import ExplodeMessage

    def on_bomb_collide():
        node = bs.getCollisionInfo('opposingNode')
        if node is not None and node.exists():
            node.handleMessage(ExplodeMessage)

    class PizzaMap(Map):
        defs = MapDefs()
        name = 'Pizza'
        playTypes = ['melee', 'keepAway', 'teamFlag','kingOfTheHill']

        @classmethod
        def getPreviewTextureName(cls):
            return 'IconPitsaBox'
    
        @classmethod
        def onPreload(cls):
            data = {}
            data['modelTop'] = bs.getModel('PitsaBoxMap')
            data['collideModel'] = bs.getCollideModel('PitsaBoxMapCollide')
            data['tex'] = bs.getTexture('PitsaBoxMapColor')

            data['modelBG'] = bs.getModel('alwaysLandBG')
            data['modelBGTex'] = bs.getTexture('PitsaBoxMapBG') #bs.getTexture('alwaysLandBGColor') #bs.getTexture('natureBackgroundColor')
  
            data['bgMaterial'] = bs.Material()
            data['bgMaterial'].addActions(actions=('modifyPartCollision', 'friction', 10.0))
            data['floorMaterial'] = bs.Material()
            data['floorMaterial'].addActions(
                actions=(('modifyPartCollision','collide',True)))
            
            data['bombBlastMaterial'] = bs.Material()
            data['bombBlastMaterial'].addActions(
                conditions=(('theyHaveMaterial', bs.Bomb.getFactory().bombMaterial)),
                actions=(
                    ('call', 'atConnect', bs.Call(on_bomb_collide)),
                    ('modifyPartCollision','collide',False)
                    ))
            return data
    
        def __init__(self):
            Map.__init__(self)
            floorMaterials = [bs.getSharedObject('footingMaterial'),
                self.preloadData['floorMaterial']]
            self.node = bs.newNode('terrain', delegate=self, attrs={
                'collideModel': self.preloadData['collideModel'],
                'color': (0.7,0.7,0.7),
                'model': self.preloadData['modelTop'],
                'colorTexture': self.preloadData['tex'],
                'materials': [bs.getSharedObject('footingMaterial')]})
            self.foo = bs.newNode('terrain', attrs={
                'model':self.preloadData['modelBG'],
                'lighting':False,
                'background':True,
                'colorTexture':self.preloadData['modelBGTex']})
            if 1:
                posY = -15.4
                height, width, mt = 10, 1, 26
                data = {0: {'scale': (width, height, mt*1.6), 'position': (-9.4, posY, 0)}, 
                    1: {'scale': (width, height, mt*1.6), 'position': (9.4, posY, 0)},
                    2: {'scale': (mt*1.6, height, width), 'position': (0, posY, 10)},
                    3: {'scale': (mt*1.6, height, width), 'position': (0, posY, -8.4)},
                    4: {'scale': (mt*2, width, mt*2), 'position': (0, posY, -7)},
                    5: {'scale': (width*1.8, height, width*1.7), 'position': (-6, posY, 7)},
                    6: {'scale': (width*1.8, height, width*1.7), 'position': (6, posY, 7)}
                    }
                for i in data:
                    if i < 4: continue
                    dt = data[i]
                    bs.newNode('region', attrs={
                        'position': dt['position'],
                        'scale': dt['scale'],
                        'type': 'box',
                        'materials': floorMaterials+[self.preloadData['bombBlastMaterial']] if i not in [4, 5, 6] else floorMaterials})
            bsGlobals = bs.getSharedObject('globals')
            bsGlobals.tint = (1.1, 1.2, 1.3)
            bsGlobals.ambientColor = (1.1, 1.2, 1.3)
            bsGlobals.vignetteOuter = (0.65, 0.6, 0.55)
            bsGlobals.vignetteInner = (0.9, 0.9, 0.93)
    registerMap(PizzaMap)

run(install)
    
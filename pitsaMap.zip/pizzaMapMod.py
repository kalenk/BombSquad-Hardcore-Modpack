# -*- coding: utf-8 -*-
import bs
import shutil, os
import bsInternal

version = 6

#writed by drov.drov

class MapDefs:
    def __init__(self):
        self.points, self.boxes = {}, {}
        self.points['ffaSpawn1'] = (-5.71412, 0.86888, -5.15969) + (0.80872, 0.05, 0.80669)
        self.points['ffaSpawn2'] = (5.72836, 0.88152, 5.77077) + (0.80637, 0.05, 0.81611)
        self.points['ffaSpawn3'] = (5.74158, 0.29753, -5.17222) + (0.80027, 0.05, 0.82515)
        self.points['ffaSpawn4'] = (-5.75115, 0.86787, 5.78048) + (0.76742, 0.05, 0.79699)
        self.points['flag2'] = (5.59606, 0.75494, 0.36072)
        self.points['flag1'] = (-4.70288, 0.8644, 0.32235)
        self.points['flagDefault'] = (-0.00268, 1.07604, 0.32877)
        self.points['powerupSpawn1'] = (-3.9711, 0.86892, 4.01135)
        self.points['powerupSpawn2'] = (4.01679, 0.85466, -3.43176)
        self.points['powerupSpawn3'] = (4.01679, 0.86645, 3.98348)
        self.points['powerupSpawn4'] = (-3.9711, 0.87874, -3.6061)
        self.points['shadowLowerBottom'] = (-8.03264, -1.28108, 11.44724)
        self.points['shadowLowerTop'] = (-8.03264, -0.09581, 11.44724)
        self.points['shadowUpperBottom'] = (11.94675, 6.81379, -6.53996)
        self.points['shadowUpperTop'] = (11.94675, 10.70252, -6.53996)
        self.points['spawn1'] = (-6.21933, 0.86559, 0.19553) + (0.18289, 0.05, 2.19598)
        self.points['spawn2'] = (6.28882, 0.88058, 0.19359) + (0.1954, 0.05, 2.22167)
        self.points['floor'] = (0, -0.151, 0)
        self.boxes['areaOfInterestBounds'] = (0.43967, -1.44778, 1.57821) + (0, 0, 0) + (69.69495, 42.61848, 34.81906)
        self.boxes['levelBounds'] = (-0.09184, 2.65289, 13.36995) + (0, 0, 0) + (59.47348, 60.32737, 57.54623)

env = bs.getEnvironment()
gAndroid = env['platform'] == 'android'
gPath = 'data' if not gAndroid else '/data/data/net.froemling.bombsquad/files/bombsquad_files/data'

map_name = 'Pitsa'
working_path = os.path.join(env['userScriptsDirectory'], 'PitsaBox')
data_path = os.path.join(gPath, 'pitsaMapMod.data')
file_types = {'.ktx' if gAndroid else '.dds': 'textures', '.bob': 'models', '.ogg': 'audio', '.cob': 'models'}

translates = {
    "Russian": {
        "installStartedText": "Установка карты \"{}\"",
        "copyingText": "Копирование файла {}",
        "installCompleteText": "Установка завершена!"},
    "English": {
        "installStartedText": "Installing map \"{}\"",
        "copyingText": "Copying file {}",
        "installCompleteText": "Install complete!"}
    }

time_skip = 200 # time rate while copying 
translates = translates.get(bs.getLanguage(), translates.get("English", {}))

def run(call=None):
    a = bsInternal._getForegroundHostActivity()
    if call is None: call = lambda x : True
    if a is not None: bs.realTimer(time_skip, bs.Call(call))
    else: bs.realTimer(time_skip, bs.Call(run, call))

def install():
    v = 0
    if os.path.exists(data_path): 
        with open(data_path, 'r') as f:
            v = f.read()
            f.close()
        try: v = int(v.replace('.', ''))
        except ValueError: v = 0
    if v < version: copyfiles()
    else: add_map()

def copyfiles():
    bs.screenMessage(translates.get("installStartedText", "installing map \"{}\"").format(map_name), color=(1,0.85,0))
    def copy(dst, src):
        filename = dst.split(os.path.sep)[-1]
        filepath = os.path.join(src, filename)
        if os.path.exists(filepath): os.remove(filepath)
        bs.screenMessage(translates.get("copyingText", "copying... {}").format(filename), color=(1, 1, 0))
        try: shutil.copy(dst, src)
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
    if os.path.exists(working_path) and os.path.isdir(working_path):
        try:
            files = os.listdir(working_path)
            for i in range(len(files)):
                file = os.path.join(working_path, files[i])
                type = None
                for c in file_types: 
                    if file.endswith(c): 
                        type = file_types[c]
                        break
                if type is not None and os.path.isfile(file): bs.realTimer(time_skip * i + time_skip, bs.Call(copy, file, os.path.join(gPath, type)))
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
        else:
            with open(data_path, 'w+') as f:
                f.write(str(version))
                f.close()
            def end():
                add_map()
                bs.screenMessage(translates.get("installCompleteText", "install complete!").format(map_name), color=(1,0.85,0))
            bs.realTimer(time_skip * len(files) + time_skip * 2, bs.Call(end))
    else: bs.screenMessage("Can not find path: "+str(working_path), color=(1,0,0))

def add_map():
    from bsMap import Map, registerMap
    class FloorTouchedMessage(object):
        def __init__(self):
            pass
    class PizzaMap(Map):
        defs = MapDefs()
        name = 'Pizza'
        playTypes = ['melee', 'keepAway', 'teamFlag','kingOfTheHill']
    
        @classmethod
        def getPreviewTextureName(cls):
            return 'IconPitsaBox'
    
        @classmethod
        def onPreload(cls):
            data = {}
            data['modelTop'] = bs.getModel('PitsaBoxMap')
            data['modelBottom'] = bs.getModel('PitsaBoxMapBottom')
            data['collideModel'] = bs.getCollideModel('PitsaBoxMapCollide')
            data['tex'] = bs.getTexture('PitsaBoxMapColor')

            data['modelBG'] = bs.getModel('natureBackground')
            data['bgVRFillModel'] = bs.getModel('natureBackgroundVRFill')
            data['modelBGTex'] = bs.getTexture('natureBackgroundColor')
            data['collideBG'] = bs.getCollideModel('natureBackgroundCollide')
            data['bgMaterial'] = bs.Material()
            data['bgMaterial'].addActions(actions=('modifyPartCollision', 'friction', 10.0))
            data['floorMaterial'] = bs.Material()
            data['floorMaterial'].addActions(
                actions=(
                    ('modifyPartCollision','collide',True), 
                    ('modifyPartCollision','friction', 0.3)))
                   # ('message','ourNode','atConnect',FloorTouchedMessage())))
            return data
    
        def __init__(self):
            Map.__init__(self)
            self.node = bs.newNode('terrain', delegate=self, attrs={
                'collideModel':self.preloadData['collideModel'],
                'color':(0.7,0.7,0.7),
                'model':self.preloadData['modelTop'],
                'colorTexture':self.preloadData['tex'],
                'materials':[bs.getSharedObject('footingMaterial')]})
            self.bottom = bs.newNode('terrain', attrs={
                'model':self.preloadData['modelBottom'],
                'color':(0.7,0.7,0.7),
                'lighting':False,
                'colorTexture':self.preloadData['tex']})
            self.foo = bs.newNode('terrain', attrs={
                'model':self.preloadData['modelBG'],
                'lighting':False,
                'background':True,
                'colorTexture':self.preloadData['modelBGTex']})
            bs.newNode('terrain', attrs={
                'model':self.preloadData['bgVRFillModel'],
                'lighting':False,
                'vrOnly':True,
                'background':True,
                'colorTexture':self.preloadData['modelBGTex']})
            floorMaterials = [bs.getSharedObject('footingMaterial'),
                self.preloadData['floorMaterial'],
                bs.getSharedObject('objectMaterial')]
            self.floor = bs.newNode('region', delegate=self, attrs={
                'position': self.getDefPoint('floor'),
                'scale':(100, 0.5, 100),
                'type':'box',
                'materials': floorMaterials})
            bs.newNode('region', attrs={
                'position': (-9.2, 0, 0),
                'scale':(1, 10, 30),
                'type':'box',
                'materials': floorMaterials})
            bs.newNode('region', attrs={
                'position': (9.2, 0, 0),
                'scale':(1, 10, 30),
                'type':'box',
                'materials': floorMaterials})
            bs.newNode('region', attrs={
                'position': (0, 0, 10),
                'scale':(18, 10, 1),
                'type':'box',
                'materials': floorMaterials})
            bs.newNode('region', attrs={
                'position': (0, 0, -10),
                'scale':(18, 10, 1),
                'type':'box',
                'materials': floorMaterials})
            self.bgCollide = bs.newNode('terrain', attrs={
                'collideModel':self.preloadData['collideBG'],
                'materials':[bs.getSharedObject('footingMaterial'),
                             self.preloadData['bgMaterial'],
                             bs.getSharedObject('deathMaterial')]})
            bsGlobals = bs.getSharedObject('globals')
            bsGlobals.tint = (1.1, 1.2, 1.3)
            bsGlobals.ambientColor = (1.1, 1.2, 1.3)
            bsGlobals.vignetteOuter = (0.65, 0.6, 0.55)
            bsGlobals.vignetteInner = (0.9, 0.9, 0.93)
        def handleMessage(self, msg):
            if isinstance(msg, FloorTouchedMessage): 
                bs.screenMessage("tch")
                node = bs.getCollisionInfo('opposingNode')
                if node is not None and node.exists():
                    t = node.position
                    #if node.getNodeType() == 'spaz':
                    node.handleMessage('impulse', t[0], t[1]-3.0, t[2], 0, 0, 0, 3000, 0, 200.0, 1, 0, 100, 0)
    registerMap(PizzaMap)

run(install)
    
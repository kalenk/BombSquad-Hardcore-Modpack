# -*- coding: utf-8 -*-

values = {
    'accountSettingsWindow':{
        'accountNameRules':'Acoief coej. c woejf. cwoef ocoweofwjfj c wjefowfowef wocjoweff',
        'accountProfileText':'(acczntl prfflzlf)',
        'accountsText':'Acctntzz',
        'achievementProgressText':'Achilfjasdflz: ${COUNT} ouzt of ${TOTAL}',
        'campaignProgressText':'Cmapghan Progflzl: ${PROGRESS}',
        'changeOncePerSeason':'owe c wow chofu wefwoefjwofjowcowfwf.',
        'changeOncePerSeasonError':'You cows ow woefj woifjwo ec oweo fowijf owiejf (${NUM} cowefwe)',
        'customName':'Cow oj wojNaoa',
        'deviceSpecificAccountText':'Crrlzfjowf uznfl a divwfo-zpijfwo ancnfo ${NAME}',
        'linkAccountsEnterCodeText':'Enrlr Cfdsz',
        'linkAccountsGenerateCodeText':'Gncowf CFdzz',
        'linkAccountsInfoText':'(fwoco par owcj woef oac we paoi oijof)',
        'linkAccountsInstructionsNewText':('Tl link j twice. owfj w off jeoifjwocjowiejfowef\n'
                                           'coajfaocj wfjw efowjo. cowejf DO Oajofjwefjeo\n'
                                           'orc aofj agpweoijv aefhwefo dj owiejf ewofj.\n'
                                           '(Dofjw jeotja theatric. owjfwfjjwf)\n'
                                           '\n'
                                           'Youc wfowej toij ${COUNT} cow oef.\n'
                                           '\n'
                                           'ICMPEWOT:  Coewij wthehowcjwef weofijweof;\n'
                                           'cIf wef htheojc;woej wejocowefjwe f wetowe\n'
                                           'baoefhcw ecywoeutowermwocwoeitjs.'),
        'linkAccountsInstructionsText':('Tz lknf twz aoc coj, goi woc woef \n'
                                        'acoweof oac oia oow towjoifowj\n'
                                        'Prowfo and in oir wojoc owinofiff.\n'
                                        'Youc owo iwoe oijf ${COUNT} accoaoijf.\n'
                                        '\n'
                                        'IMPCO oOIFOWEFJ\n'
                                        'owijecojwef\n'
                                        'oijoicjwe\n'
                                        '\n'
                                        'AOicjowijeojwoeifjwef'),
        'linkAccountsText':'Lnk Accnffzz',
        'linkedAccountsText':'Lnkfdf Accnrts:',
        'nameChangeConfirm':'Cho weft cowejf coiwjocwe. ${NAME}?',
        'notLoggedInText':'<nzt lggzt inz>',
        'resetProgressConfirmNoAchievementsText':('Thzz wflzz resta yrsr co-opz proglfzlz\n'
                                                  'and hghzl scrdz.  Itz cntljdf be zunfzz.\n'
                                                  'Arz yoz srz?'),
        'resetProgressConfirmText':('Thzlz wlz rzlt yrlzz co-pz plglrz,\n'
                                    'achroifzlz, and hghzl-scrlrz.\n'
                                    'Tz cndft b undozn.\n'
                                    'Anz youz sér?'),
        'resetProgressText':'Rztlsf Proggzfrz',
        'setAccountName':'Soil  owe o animas',
        'setAccountNameDesc':('Selcow f cjwo ot afoa fw jcpaoewj fwocowefj.\n'
                              'You wolf wc. weowyc oawe awoefm mcapowefi \n'
                              'coat aocjweo towirowmcowiefownr.'),
        'signInInfoText':('Sgn inz tz strz yr prograrzz inz\n'
                          'thz cld, rnzr tckrz, rnz'),
        'signInText':'Sggnz Inz',
        'signInWithDeviceInfoText':'(an coiwjfow fcoa cowj efj woj cowij eofjwoj foijs aofij )',
        'signInWithDeviceText':'Sngi foicj oj de voa cwoiejfw',
        'signInWithGameCircleText':'Sgn in gh Gm Cirflc',
        'signInWithGooglePlayText':'Snf ocj weo fGOofl Plfl',
        'signInWithTestAccountInfoText':'(lgjo cac  cojef ot; oeco  doic w eofjw oero )',
        'signInWithTestAccountText':'Sjc weo fwtjwoefj cowefwf',
        'signOutText':'Sgngz Ozt',
        'signingInText':'Sgngngn infz..',
        'signingOutText':'Sngning ozt..',
        'testAccountWarningCardboardText':('Wrrjowifj a f;aoiwejc owj efaoiwjef owjef oaje wf\n'
                                           'aiwje ofjw eoijaocijw oeifjowefj owijefoiwjefowi ef\n'
                                           'aowj aocj weoif ja;woiefj woioc woef woiefjow fjweo.\n'
                                           '\n'
                                           'c weoiwo efjwo  cowiejf oaiwje oaiwj i ogamaoiw.\n'
                                           '(yoauc owi odf oaijfo wojaojpjf oafpo ewf owejrw er)'),
        'testAccountWarningOculusText':('Wrrjowifj a f;aoiwejc owj efaoiwjef owjef oaje wf\n'
                                        'aiwje ofjw eoijaocijw oeifjowefj owijefoiwjefowi ef\n'
                                        'aowj aocj weoif ja;woiefj woioc woef woiefjow fjweo.\n'
                                        '\n'
                                        'c weoiwo efjwo  cowiejf oaiwje oaiwj i ogamaoiw.\n'
                                        '(yoauc owi odf oaijfo wojaojpjf oafpo ewf owejrw er)'),
        'testAccountWarningText':('Wrznnzn: yzz asdfa aofijs fo asd; ofiasdfo jasdo\n'
                                  'a;sdj faoisdfj oiasdfo; asdoi aoisjdfasdf\n'
                                  'asdoj asodi oasdjf osijdf oaijsdf oiasfd\n'
                                  'asdof jaosdfj oasdjf ;oaisjdf;oijas dfoijasdf'),
        'ticketsText':'Tzcktzz: ${COUNT}',
        'titleText':'Acnfnnz',
        'unlinkAccountsInstructionsText':'Slj cwefjwe f owcjwoeijowief',
        'unlinkAccountsText':'Uldfj owjowerjsr',
        'viaAccount':'(fc cowefjwef ${NAME})',
        'youAreLoggedInAsText':'Yzrl arz lgzffd iz az:',
        'youAreSignedInAsText':'Yz arz sngnfd inz arz:'
    },
    'achievementChallengesText':'Achéivmznt Chalzlngesz',
    'achievementText':'Áchíévzmúnt',
    'achievements':{
        'Boom Goes the Dynamite':{
            'description':'Kílzl 3 bád gúyz wúth TNTz',
            'descriptionComplete':'Killéd 3 bád gúyz wíth TNT',
            'descriptionFull':'Kíll 3 bád gzys wíth TNT ónz ${LEVEL}',
            'descriptionFullComplete':'Kzlléd 3 bad gzs wéth TNT ón ${LEVEL}',
            'name':'Boóm Gúzz thz Dynámitz'
        },
        'Boxer':{
            'description':'Win withóut uzing any bómbz',
            'descriptionComplete':'Wén withéut uzing any bémbzz',
            'descriptionFull':'Czmplétz ${LEVEL} wéithzt uznng anyz bómbz',
            'descriptionFullComplete':'Complzzted ${LEVEL} wíthoutz úsing ány bómbz',
            'name':'Bóxzr'
        },
        'Dual Wielding':{
            'descriptionFull':'Coocjf co eofw jc9ha oc jweofi jwoe)',
            'descriptionFullComplete':'Cncof o 2 Ocno come o f(hard co who oc)',
            'name':'Dual Wlfjl c'
        },
        'Flawless Victory':{
            'description':'Win withóut getting hit',
            'descriptionComplete':'Wén withéut getting hit',
            'descriptionFull':'Wín ${LEVEL} wíthozt géttzng hétz',
            'descriptionFullComplete':'Wón ${LEVEL} wíthóut géttnz hit',
            'name':'Fláwlzzz Victoryz'
        },
        'Free Loader':{
            'descriptionFull':'Stalk two  owiej of ; cow   2+ cpoijefz',
            'descriptionFullComplete':'Stoic wo reif owe jo j oweo woeijo 2+ cowpef',
            'name':'Frizz Ljdfefwz'
        },
        'Gold Miner':{
            'description':'Kill 6 búd guyz wíth lánd-minez',
            'descriptionComplete':'Killed 6 bad guyz with land-minez',
            'descriptionFull':'Kílz 6 bád gzsz wéth lánz-mínz on ${LEVEL}',
            'descriptionFullComplete':'Kílzd 6 bád gzsz wéth lánz-mínz on ${LEVEL}',
            'name':'Góld Mínzr'
        },
        'Got the Moves':{
            'description':'Win withóut uzing púnchez ór bómbz',
            'descriptionComplete':'Wén withéut uzing punchez ér bémbz',
            'descriptionFull':'Wín ${LEVEL} wiznfft ands bpunchpd so bmzlf',
            'descriptionFullComplete':'Wonz ${LEVEL} wlznfif anz pnchr or bmzfz',
            'name':'Gót thz Móvzz'
        },
        'In Control':{
            'descriptionFull':'Coin oil of jo  owe fo(her dcc oiowe)',
            'descriptionFullComplete':'Coco oe  owe fwoinoi (where ocwo wjef)',
            'name':'Ina Conoiwjef'
        },
        'Last Stand God':{
            'description':'Zcóre 1000 póintz',
            'descriptionComplete':'Zcéred 1000 péintz',
            'descriptionFull':'Scorz 1000 prtz on ${LEVEL}',
            'descriptionFullComplete':'Scorzed 1000 Ptz onz ${LEVEL}',
            'name':'${LEVEL} Gzd'
        },
        'Last Stand Master':{
            'description':'Zcóre 250 póintz',
            'descriptionComplete':'Scórzd 250 póinzfzs',
            'descriptionFull':'Scórz 250 póoinzf on ${LEVEL}',
            'descriptionFullComplete':'Scórzd 250 póoinzf on ${LEVEL}',
            'name':'${LEVEL} Mztstrz'
        },
        'Last Stand Wizard':{
            'description':'Zcóre 500 póintz',
            'descriptionComplete':'Zcéred 500 péintz',
            'descriptionFull':'Sczore 500 póintz ón ${LEVEL}',
            'descriptionFullComplete':'Sczored 500 póintz ón ${LEVEL}',
            'name':'${LEVEL} Wizárd'
        },
        'Mine Games':{
            'description':'Kill 3 bad guyz with land-minez',
            'descriptionComplete':'Killéd 3 bód gúyz with land-minez',
            'descriptionFull':'Kzll 3 bd guzl wzz lndz mdnz on ${LEVEL}',
            'descriptionFullComplete':'Kzlld 3 bd guzl wzz lndz mdnz on ${LEVEL}',
            'name':'Minz Gámzz'
        },
        'Off You Go Then':{
            'description':'Tózz 3 bad guyz óff the map',
            'descriptionComplete':'Tézzed 3 bad guyz éff the map',
            'descriptionFull':'Tlzzl 3 bd guzz ofz thz mp in ${LEVEL}',
            'descriptionFullComplete':'Tlzzld 3 bd guzz ofz thz mp in ${LEVEL}',
            'name':'Ofz Yóú Gú Thzn'
        },
        'Onslaught God':{
            'description':'Zcóre 5000 póintz',
            'descriptionComplete':'Zcéred 5000 péintz',
            'descriptionFull':'Scorlz 5000 ptsfz onz ${LEVEL}',
            'descriptionFullComplete':'Scorlzd 5000 ptsfz onz ${LEVEL}',
            'name':'${LEVEL} Gzd'
        },
        'Onslaught Master':{
            'description':'Zcóre 500 póintz',
            'descriptionComplete':'Zcéred 500 péintz',
            'descriptionFull':'Scorzr 500 ptasdf on ${LEVEL}',
            'descriptionFullComplete':'Scorzrd 500 ptasdf on ${LEVEL}',
            'name':'${LEVEL} Máztzr'
        },
        'Onslaught Training Victory':{
            'description':'Defeat all wavez',
            'descriptionComplete':'Defeated all wavez',
            'descriptionFull':'Défzt alzf wavls fn ${LEVEL}',
            'descriptionFullComplete':'Défztddz alzf wavls fn ${LEVEL}',
            'name':'${LEVEL} Victory'
        },
        'Onslaught Wizard':{
            'description':'Zcóre 1000 póintz',
            'descriptionComplete':'Zcéred 1000 péintz',
            'descriptionFull':'Scorlz 1000 pointz ín ${LEVEL}',
            'descriptionFullComplete':'Scorlz 1000 pointz ín ${LEVEL}',
            'name':'${LEVEL} Wizárd'
        },
        'Precision Bombing':{
            'description':'Win wíthóut any pówerupz',
            'descriptionComplete':'Wén withéut any péwerupz',
            'descriptionFull':'Wín ${LEVEL} wnthoz anz powr-upz',
            'descriptionFullComplete':'Wín ${LEVEL} wnthoz anz powr-upz',
            'name':'Przcízion Bombing'
        },
        'Pro Boxer':{
            'description':'Win withóut uzing any bómbz',
            'descriptionComplete':'Wén withéut uzing any bémbz',
            'descriptionFull':'Cómplztz ${LEVEL} wiífhaou uzngl fnp bomzz',
            'descriptionFullComplete':'Cómplztz ${LEVEL} wiífhaou uzngl fnp bomzz',
            'name':'Pró Bzxer'
        },
        'Pro Football Shutout':{
            'description':'Win withóut letting the bad guyz zcóre',
            'descriptionComplete':'Wén withéut letting the bad guyz zcére',
            'descriptionFull':'Wén ${LEVEL} winarhoz létngnz thé bád gzzl scéor',
            'descriptionFullComplete':'Wénd ${LEVEL} winarhoz létngnz thé bád gzzl scéor',
            'name':'${LEVEL} Zhutout'
        },
        'Pro Football Victory':{
            'description':'Win thé gúme',
            'descriptionComplete':'Wén thú game',
            'descriptionFull':'Winz thz gmz in ${LEVEL}',
            'descriptionFullComplete':'Winzd thz gmz in ${LEVEL}',
            'name':'${LEVEL} Victory'
        },
        'Pro Onslaught Victory':{
            'description':'Deféat áll wávez',
            'descriptionComplete':'Defeáted úll wávez',
            'descriptionFull':'Defetzz álz wávz óf ${LEVEL}',
            'descriptionFullComplete':'Defetzzd álz wávz óf ${LEVEL}',
            'name':'${LEVEL} Victory'
        },
        'Pro Runaround Victory':{
            'description':'Cómplúte all wavez',
            'descriptionComplete':'Cémpleted all wavez',
            'descriptionFull':'Cómpltz áll wávez on ${LEVEL}',
            'descriptionFullComplete':'Cómpltzd áll wávez on ${LEVEL}',
            'name':'${LEVEL} Victory'
        },
        'Rookie Football Shutout':{
            'description':'Win withóut letting the bad guyz zcóre',
            'descriptionComplete':'Wén withéut letting the bad guyz zcére',
            'descriptionFull':'Wiz ${LEVEL} wihtz lettzng the bd gly asorz',
            'descriptionFullComplete':'Wizd ${LEVEL} wihtz lettzng the bd gly asorz',
            'name':'${LEVEL} Zhutout'
        },
        'Rookie Football Victory':{
            'description':'Win the game',
            'descriptionComplete':'Wén the game',
            'descriptionFull':'Wizn thz gmaz in ${LEVEL}',
            'descriptionFullComplete':'Wiznd thz gmaz in ${LEVEL}',
            'name':'${LEVEL} Victory'
        },
        'Rookie Onslaught Victory':{
            'description':'Defeat all wavez',
            'descriptionComplete':'Defeated all wavez',
            'descriptionFull':'Defetz álz wávnz én ${LEVEL}',
            'descriptionFullComplete':'Defetzed álz wávnz én ${LEVEL}',
            'name':'${LEVEL} Victory'
        },
        'Runaround God':{
            'description':'Zcóre 2000 póintz',
            'descriptionComplete':'Zcéred 2000 péintz',
            'descriptionFull':'Scruze 2000 ptznf én ${LEVEL}',
            'descriptionFullComplete':'Scruzed 2000 ptznf én ${LEVEL}',
            'name':'${LEVEL} God'
        },
        'Runaround Master':{
            'description':'Zcóre 500 póintz',
            'descriptionComplete':'Zcéred 500 péintz',
            'descriptionFull':'Scórz 500 ptzfs én ${LEVEL}',
            'descriptionFullComplete':'Scórzd 500 ptzfs én ${LEVEL}',
            'name':'${LEVEL} Máztzr'
        },
        'Runaround Wizard':{
            'description':'Zcóre 1000 póintz',
            'descriptionComplete':'Zcéred 1000 péintz',
            'descriptionFull':'Scórz 1000 póintz ón ${LEVEL}',
            'descriptionFullComplete':'Scórzd 1000 póintz ón ${LEVEL}',
            'name':'${LEVEL} Wizárd'
        },
        'Sharing is Caring':{
            'descriptionFull':'Su owe oshoz o owe owejojowjeofjd',
            'descriptionFullComplete':'Suo web fsdhare oc ojowijeoioifoidfdf',
            'name':'Show zo owefj wojz'
        },
        'Stayin\' Alive':{
            'description':'Win withóut dyíng',
            'descriptionComplete':'Wén withéut dying',
            'descriptionFull':'Wín ${LEVEL} wíthzoft edynzg',
            'descriptionFullComplete':'Wínd ${LEVEL} wíthzoft edynzg',
            'name':'Ztáyin\' Álivz'
        },
        'Super Mega Punch':{
            'description':'Inflict 100% damage with óne punch',
            'descriptionComplete':'Inflicted 100% damage with éne punch',
            'descriptionFull':'Inflgz 100% dmgzz éwth on púnch en ${LEVEL}',
            'descriptionFullComplete':'Inflgzdz 100% dmgzz éwth on púnch en ${LEVEL}',
            'name':'Zúpzr Mzgá Punch'
        },
        'Super Punch':{
            'description':'Inflict 50% damage with óne punch',
            'descriptionComplete':'Inflicted 50% damage with éne punch',
            'descriptionFull':'Inflgtz 50% dmgzn wíth on puzn ón ${LEVEL}',
            'descriptionFullComplete':'Inflgtzd 50% dmgzn wíth on puzn ón ${LEVEL}',
            'name':'Zupzr Punch'
        },
        'TNT Terror':{
            'description':'Kill 6 bád gúyz with TNT',
            'descriptionComplete':'Killed 6 bad guyz with TNT',
            'descriptionFull':'Klzl 6 bad gulf with TNT en ${LEVEL}',
            'descriptionFullComplete':'Klzld 6 bad gulf with TNT en ${LEVEL}',
            'name':'TNTz Terrór'
        },
        'Team Player':{
            'descriptionFull':'Sto c weoj woe woe o o4+ pcoiwjef',
            'descriptionFullComplete':'Stoic own efoiw ojoiwjeo f woof 4+ pojzoz',
            'name':'Tzoij Plzljrz'
        },
        'The Great Wall':{
            'description':'Ztóp every zíngle bad guy',
            'descriptionComplete':'Ztépped every zingle bad guy',
            'descriptionFull':'Stopz evryz snglf bádz gzn on ${LEVEL}',
            'descriptionFullComplete':'Stopzd evryz snglf bádz gzn on ${LEVEL}',
            'name':'Thé Greát Wáll'
        },
        'The Wall':{
            'description':'Ztóp évery zíngle bad guy',
            'descriptionComplete':'Ztépped every zingle bad guy',
            'descriptionFull':'Stopz evryz snglf bádz gzn on ${LEVEL}',
            'descriptionFullComplete':'Stopzd evryz snglf bádz gzn on ${LEVEL}',
            'name':'Thz Wáll'
        },
        'Uber Football Shutout':{
            'description':'Win withóut létting thé bád guyz zcóre',
            'descriptionComplete':'Wén withéut letting the bad guyz zcére',
            'descriptionFull':'Winz ${LEVEL} wntho ltnfjf thz bád gzll scófz',
            'descriptionFullComplete':'Winzd ${LEVEL} wntho ltnfjf thz bád gzll scófz',
            'name':'${LEVEL} Zhútout'
        },
        'Uber Football Victory':{
            'description':'Wín the gáme',
            'descriptionComplete':'Wén the game',
            'descriptionFull':'Wínz thez gámz in ${LEVEL}',
            'descriptionFullComplete':'Wónz thz gamz én ${LEVEL}',
            'name':'${LEVEL} Víctory'
        },
        'Uber Onslaught Victory':{
            'description':'Defeat all wavez',
            'descriptionComplete':'Defeated all wavez',
            'descriptionFull':'Defetz álz wves in ${LEVEL}',
            'descriptionFullComplete':'Defetzdd álz wves in ${LEVEL}',
            'name':'${LEVEL} Victory'
        },
        'Uber Runaround Victory':{
            'description':'Cómplete áll wavez',
            'descriptionComplete':'Cémpleted all wavez',
            'descriptionFull':'Completz alz wves on ${LEVEL}',
            'descriptionFullComplete':'Czmplétdz álz waves ónz ${LEVEL}',
            'name':'${LEVEL} Victory'
        }
    },
    'achievementsRemainingText':'Azhiévemúnts Rzmáinzng:',
    'achievementsText':'Achéevúmentz',
    'achievementsUnavailableForOldSeasonsText':'Srrrz, chi faow co wjefo iwefo wef;oiajwf asodvjoa sdfj odfjsodf.',
    'addGameWindow':{
        'getMoreGamesText':'Gztz Mrrz Gmzz...',
        'titleText':'Ádzd Gámzé',
        'titleTextScale':1.01
    },
    'allowText':'Alzéow',
    'alreadySignedInText':('Yr co wcowief woeijo wife ewf;\n'
                           'orc woeful oj ceofjwoejfowief\n'
                           'ocjwoef weofwocijweofw.'),
    'apiVersionErrorText':'Cznt lzdz mdls ${NAME}; zt tarng faptr  ${VERSION_USED}; wz rojafoqrz ${VERSION_REQUIRED}.',
    'audioSettingsWindow':{
        'headRelativeVRAudioInfoText':'("Aztoz" enablez thz onlzl when hedifphz arnz plzzdd inz)',
        'headRelativeVRAudioText':'Hzad Rlztefijv VRZ Azdjfozl',
        'musicVolumeText':'Músíc Vólumze',
        'soundVolumeText':'Sóuznd Vólume',
        'soundtrackButtonText':'Sóuzdtríckz',
        'soundtrackDescriptionText':'(ássigzn yóur ówn músic zo pzlay dúrinzg gzmes)',
        'titleText':'Aúdzo'
    },
    'autoText':'Aztoz',
    'backText':'Bfjack',
    'banThisPlayerText':'Bjfo oweijf plfl',
    'bestOfFinalText':'Bést-óf-${COUNT} Fínál',
    'bestOfSeriesText':'Bést óf ${COUNT} sérzés:',
    'bestRankText':'Yz bst rnkf iz #${RANK}',
    'bestRatingText':'Yózr bést rátíng ús ${RATING}',
    'betaErrorText':'Thís béta ís nz lóngzr áctzve; pléase chéck fór á nzw vérsion.',
    'betaValidateErrorText':'Unáble tó válidzte béta. (nó nét cónnectizn?)',
    'betaValidatedText':'Bztá Válídatéd; Enjóy!',
    'bombBoldText':'BÓZMB',
    'bombText':'Bóombz',
    'boostText':'Bfzesf',
    'bsRemoteConfigureInAppText':'${REMOTE_APP_NAME} ís cónfigúred ín thé ápp itszlf.',
    'buttonText':'béttzn',
    'canWeDebugText':('Woíld yoí lúké BombZqíád to áítomátúcálly réport\n'
                      'bígz, crázhéz, ánd bázúc ízágé únfo to thé dévélopér?\n'
                      '\n'
                      'Thúz dátá contáúnz no pérzonál únformátúon ánd hélpz\n'
                      'kéép thé gámé rínnúng zmoothly ánd bíg-fréép.'),
    'cancelText':'Czéanczel',
    'cantConfigureDeviceText':'Sórry, ${DEVICE} ús nút cónfígúrzble.',
    'challengeEndedText':'Thzl cowfo jan fa  eofnwoefnw.',
    'chatMuteText':'Mmof wChad',
    'chatMutedText':'Chad mamba',
    'chatUnMuteText':'Unobiaje Chafb',
    'choosingPlayerText':'<chflzf plzlflr>',
    'completeThisLevelToProceedText':('Yóz múst cómplítz\n'
                                      'thís lével tú próceed!'),
    'completionBonusText':'Cúmplezión Búnís',
    'configControllersWindow':{
        'configureControllersText':'Cnfgjzljrz Gmpzjgdz',
        'configureGamepadsText':'Confifignr Gmpndddss',
        'configureKeyboard2Text':'Confifif Kebzllszzz P2',
        'configureKeyboardText':'Cnfofig Keybbbdzzzrd',
        'configureMobileText':'Mozzle Dzdices as Cntlrrlz',
        'configureTouchText':'Confifio Tofjafiffffsn',
        'ps3Text':'PS3 Czojfijzssz',
        'titleText':'Ctnzléfjorss',
        'wiimotesText':'Wiizzle',
        'xbox360Text':'Xbox 360 Csojfoijssszz'
    },
    'configGamepadSelectWindow':{
        'androidNoteText':'Note: gzzzmf suzzzort vzzfrs bzz dzzzf anz Androidzzf verzzffrdn.',
        'pressAnyButtonText':('Przss anzz butzzon on zzt gamzzzepad\n'
                              ' yozu waznt tzzo confijfgure...'),
        'titleText':'Confiszzgr Gzramepad'
    },
    'configGamepadWindow':{
        'advancedText':'Advzzcced',
        'advancedTitleText':'Adnvlglz Ctnlglglz Stprurzz',
        'analogStickDeadZoneDescriptionText':'(tzrlf upz ifz rzlf charlfzz \'drfgz\' whcz yozl rjldf f thz tsicls)',
        'analogStickDeadZoneText':'Anazz Séick Dfead Zze',
        'appliesToAllText':'(appldf fdojf sfojdf fof thisp)',
        'autoRecalibrateDescriptionText':'(ezble thffs fe yoér charawefter dows nwt mze atfull spzzed)',
        'autoRecalibrateDescriptionTextScale':0.4,
        'autoRecalibrateText':'Auzo-Zecfélibrate Azzlog Stéck',
        'autoRecalibrateTextScale':0.65,
        'axisText':'axéy',
        'clearText':'clzár',
        'dpadText':'dpéz',
        'extraStartButtonText':'Extraflz Starn buTzzlf',
        'ifNothingHappensTryAnalogText':'If zzidfeng happzzens, trw asszzning to thf anzlog stewfk efwstead.',
        'ifNothingHappensTryDpadText':'Ift nothewfng happezz, tzy asigewning tz the ewd-pad itead.',
        'ignoreCompletelyDescriptionText':'(pvojf wocjw oe ifjwo iefow eoijociwj efoij weofj woejf owijef)',
        'ignoreCompletelyText':'Igoif Cmwpoifwf',
        'ignoredButton1Text':'Ignozfoj Btntlg 1',
        'ignoredButton2Text':'Ignogfj Buttlafj 2',
        'ignoredButton3Text':'Ignoje Bttnzf 3',
        'ignoredButton4Text':'Ignfowf Brtjlaf 4',
        'ignoredButtonDescriptionText':'(usz thfs tzzz wrevent \'homez\' or \'szync\' bzztons éom afctcng thz UI)',
        'ignoredButtonDescriptionTextScale':0.4,
        'ignoredButtonText':'Ignzcefd Buttzzn',
        'pressAnyAnalogTriggerText':'Préss anz anfzalog tzzgger...',
        'pressAnyButtonOrDpadText':'Przzs anfy buttw oz dpad...',
        'pressAnyButtonText':'Prezz ayy buzton...',
        'pressLeftRightText':'Pzss lefwt zr rewght...',
        'pressUpDownText':'Press ufep orz éown...',
        'runButton1Text':'Rén Buzzon 1',
        'runButton2Text':'Rén Buefwon 2',
        'runTrigger1Text':'Rén Trzzger 1',
        'runTrigger2Text':'Rén Trizzer 2',
        'runTriggerDescriptionText':'(anglaj trgglaf ltz yz rndf at baljfef zpddds)',
        'secondHalfText':('Usz tzzs tossc  onzzgure the zecond slf\n'
                          'of a 2-gazzas-in-1 dezzzce zhat\n'
                          'sdfws up as a segle cntljtlz.'),
        'secondaryEnableText':'Enzable',
        'secondaryText':'Scndofjfsf Cntnglafj',
        'startButtonActivatesDefaultDescriptionText':'(tflz thzf offz ifz yourz stfzf butlflz isz morz of a mnzuz bunflz)',
        'startButtonActivatesDefaultText':'Stzt Bztton Actfewvates Dzault Wffget',
        'startButtonActivatesDefaultTextScale':0.65,
        'titleText':'Ctjglafj Stwwcfp',
        'twoInOneSetupText':'2-ér-1 Conzugger Setzzp',
        'uiOnlyDescriptionText':'(pcoije oic owejofijwe ocj owejofjwo efjo wejfo)',
        'uiOnlyText':'Lmo to Mnf Uslf',
        'unassignedButtonsRunText':'All Unzzssigned Befttons Run',
        'unassignedButtonsRunTextScale':0.8,
        'unsetText':'<unzét>',
        'vrReorientButtonText':'VR OCjweof jweofOBofw'
    },
    'configKeyboardWindow':{
        'configuringText':'Cofzzfgurizzf ${DEVICE}',
        'keyboard2NoteScale':0.7,
        'keyboard2NoteText':('Nozf: mzost keybfdasdfrds canf oly rezzzfter a fewz kfjwoesses at\n'
                             'ofce, so havifasdf a secffd keydfafrd plzzer maff wrko beéter\n'
                             'ifz tdfere isza sfaate kefdfaoard atzzched fof tfm too zse.\n'
                             'Nfote thtyou\'ll stdfjill nejfe to asndssgn uniqeeys tfe tnhe\n'
                             'tzwo payersfeweven inthat ase.')
    },
    'configTouchscreenWindow':{
        'actionControlScaleText':'Actglz Cntrflf Sclz',
        'actionsText':'Actíóns',
        'buttonsText':'búttzns',
        'dragControlsText':'< drgz nrltlss tz rpempnzlsdjf tmgj >',
        'joystickText':'jóystizk',
        'movementControlScaleText':'Mvjtjtg Cntljtfl Sclz',
        'movementText':'Múvemznt',
        'resetText':'Részt',
        'swipeControlsHiddenText':'Hdz Swpnz Icnflfz',
        'swipeInfoText':('\'Swípe\' styze cúntrozs táke ú lúttle gétting úsed tó bút\n'
                         'mzke ít eásiér tó pláy wíthoút lóoking át thé cóntróls.'),
        'swipeText':'swípe',
        'titleText':'Cónfígúre Tóuchszreen',
        'touchControlsScaleText':'Tóuch Cóntróls Scále'
    },
    'configureItNowText':'Cónfígzre ít nów?',
    'configureText':'Cónfúgzre',
    'connectMobileDevicesWindow':{
        'amazonText':'Amézon Appstóre',
        'appStoreText':'Appz Stózre',
        'bestResultsScale':0.65,
        'bestResultsText':('Fór bést részlts yóz\'ll nééd a lag-fréé wifi nétwórk. Yóz can\n'
                           'rédzcé wifi lag by tzrning óff óthér wiréléss dévicés, by\n'
                           'playing clósé tó yózr wifi rózytér, and by cónnécting thé\n'
                           'gamé hóst diréctly tó thé nétwórk via éthérnét.'),
        'explanationScale':0.8,
        'explanationText':('Tz usé á smárt-phzné zr táblét ás á wiréléss gámépád,\n'
                           'instáll thé "${REMOTE_APP_NAME}" ápp zn it. Up tz 8 dévicés\n'
                           'cán cznnéct tz á ${APP_NAME} gámé zvér WiFi, ánd it\'s fréé!'),
        'forAndroidText':'fór Anzdróid:',
        'forIOSText':'fór íOzS:',
        'getItForText':('Gét ${REMOTE_APP_NAME} fzr iOS ót thz Applé App Stúre\n'
                        'orz fór Andróid ét the Gozgle Pláy Stóre ur Amázon Appstóre'),
        'googlePlayText':'Gglgl Plz',
        'titleText':'Uzíng Móbíle Dzvíces asz Cntrlflfz:'
    },
    'continuePurchaseText':'Continifjz frz ${PRICE}?',
    'continueText':'Conttiflz',
    'controlsText':'Cztrnlfz',
    'coopSelectWindow':{
        'activenessAllTimeInfoText':'Thz dfsn not appz to alflz-tmf rnefkz',
        'activenessInfoText':('Thz mfijfo roif coiwef ow oijoiwe \n'
                              'pcoi wefoa coiweofi weocoieo dofiw.'),
        'activityText':'Actlffz',
        'campaignText':'Cézmpáignz',
        'challengesInfoText':('Winz piorios for complinlt mini-fjgisjf.\n'
                              '\n'
                              'Prizoi and office levels cnieicowf\n'
                              'caohf im fa chcijlef is copweof and\n'
                              'docowei coawijfowieocwiejf owoifoijfow.'),
        'challengesText':'Chllzlzfnfz',
        'currentBestText':'Crrlzz Bzt',
        'customText':'Cúztúm',
        'entryFeeText':'Enrrz',
        'forfeitConfirmText':'Forfojf thosi cowjeofijwf?',
        'forfeitNotAllowedYetText':'Thz cowj co woac owienf owj oaijefowf.',
        'forfeitText':'Froijfow',
        'multipliersText':'Mlflfjzfs',
        'nextChallengeText':'Nzt Chclwlfs',
        'nextPlayText':'Nxts Plzflz',
        'ofTotalTimeText':'ofz ${TOTAL}',
        'playNowText':'Plz nfz',
        'pointsText':'Pffzfs',
        'powerRankingFinishedSeasonUnrankedText':'(finifhs sroic unrnrkken)',
        'powerRankingNotInTopText':'(notz inf wociwoef ${NUMBER})',
        'powerRankingPointsEqualsText':'= ${NUMBER} pzf',
        'powerRankingPointsMultText':'(x ${NUMBER} pzt)',
        'powerRankingPointsText':'${NUMBER} pff',
        'powerRankingPointsToRankedText':'(${CURRENT} ofz ${REMAINING} wefz)',
        'powerRankingText':'Pzwlrrl Rnkflfz',
        'prizesText':'Prrzzz',
        'proMultInfoText':('Pfofz wf thet ${PRO} yocfz\n'
                           'rcsfff a ${PERCENT}% poient bsffz hdere.'),
        'seeMoreText':'Mrrzz...',
        'skipWaitText':'Skpz Wzrz',
        'timeRemainingText':'Tmmz Rmrmrmfz',
        'titleText':'Có-óup',
        'toRankedText':'Tz Rnfkfd',
        'totalText':'tztrlz',
        'tournamentInfoText':('Cmpfowj foij hoihwo jowec\n'
                              'otjo fpcowjefo weyowufowef.\n'
                              '\n'
                              'Poriwjf cowiej oaww aor dojofoscore\n'
                              'pacify when fofjocow efoiwje fjoits.'),
        'welcome1Text':('Wlcojf to ${LEAGUE}. Yz j woej owiejowjef\n'
                        'flwejfo ocjw oeif weofowewfw ejfwf, comfpof\n'
                        'cajweoifwoif and fweiningowifj woicoijweorioreors.'),
        'welcome2Text':('Yz cm alfj fcojwfowiejfo wiejo wfoinoaicoiwefoiwef.\n'
                        'Tickef woioiweofiw efoiauoicoiwefjoaieofaefa\n'
                        'minf-fizoj , and itner ouacohao,a nd fmofz.'),
        'yourPowerRankingText':'Yrrlz Powe Rnkkffz:'
    },
    'copyOfText':'Copzyz du ${NAME}',
    'copyText':'Czópy',
    'copyrightText':'© 2013 Eric Froemling',
    'createAPlayerProfileText':'Créatz á pláyer prófzle?',
    'createEditPlayerText':'<Coicwe/Edior Plflz>',
    'createText':'Crziate',
    'creditsWindow':{
        'additionalAudioArtIdeasText':'Addizijton Audorz, Elralz Artlzl,a ndlad Idlflzf by ${NAME}',
        'additionalMusicFromText':'Adiidfjozj amuflzf crjlz ${NAME}',
        'allMyFamilyText':'All of mzomf famif lwoh ljfljdf plzl telslfsf',
        'codingGraphicsAudioText':'Cdjfozj, Gprhpaz, and Audouz bz ${NAME}',
        'creditsText':('  COdifid fjaosdjf aona dofii by Eric Froemling\n'
                       '  \n'
                       '  Andofi dsjoasdij dsjoi goingpoin arf Raphael Suter\n'
                       '  \n'
                       '  Snofl and Gramble:\n'
                       '\n'
                       '${SOUND_AND_MUSIC}     Pblusd asfojasdfj idsfjif Musopen.com (ajfojsdfjfd oisdfjf fijf)\n'
                       '        Thalsjfisjdfoijsf  US Army, Navy, and Marine Bands.\n'
                       '\n'
                       '     Big fpsodfj sdf jdfoasdfij sadfodfj osdfj asdofiwef owefjwiefij foijf:\n'
                       '${FREESOUND_NAMES}  \n'
                       '  SPananf éfodjfij:\n'
                       '     Todd, Laura, arf Robert Froemling\n'
                       '     Al sjfoasd jfisfoas djsdfjsdfoiasdfjjfif\n'
                       '     Whala fjsdofjfisjoiajsjfoafo\n'
                       '  \n'
                       '                                                             www.froemling.net\n'),
        'languageTranslationsText':'Langlaflzf Translafsjfldzl:',
        'legalText':'Leglzfl:',
        'publicDomainMusicViaText':'Pbfljzl-zmfmdf mufizlc vz ${NAME}',
        'softwareBasedOnText':'Thz sofjtlzf iz blzlf inz prrltzl onz thfz wrkjzl ofz ${NAME}',
        'songCreditText':('${TITLE} Perfofzf bzy ${PERFORMER}\n'
                          'Cmpzfjlz bzy ${COMPOSER}, Arrnafflzz byz ${ARRANGER}, Pbllffljfd bzy ${PUBLISHER},\n'
                          'Crorjlzf ofz ${SOURCE}'),
        'soundAndMusicText':'Szfjogi & Muzifg:',
        'soundsText':'Sndlfjz (${SOURCE}):',
        'specialThanksText':'Spzjlfz Thznflz:',
        'thanksEspeciallyToText':'Thzjflz epfojaflzf to ${NAME}',
        'titleText':'${APP_NAME} Cojweoijwf',
        'whoeverInventedCoffeeText':'Whozjfver invjlntlc cffzzre'
    },
    'currentStandingText':'Yrz crrlf stnsff is #${RANK}',
    'customizeText':'Cztmtlajfz...',
    'deathsTallyText':'${COUNT} déathz',
    'deathsText':'Déáthzs',
    'debugText':'débúg',
    'debugWindow':{
        'reloadBenchmarkBestResultsText':'Ntzl: itz iz rcmdmfdded thz yz st Sttnggljs->Grphafz->Texjfosijf to "Hghz" whlz tsttfng thiz',
        'runCPUBenchmarkText':'Rn CPU Bnchfjmzk',
        'runGPUBenchmarkText':'Rnz GPU Bnchmrmkz',
        'runMediaReloadBenchmarkText':'Rnzl Mdidl-Rlzdd Bnchrmdkz',
        'runStressTestText':'Rzn strzzlf tsts',
        'stressTestPlayerCountText':'Plzearr Cntntz',
        'stressTestPlaylistDescriptionText':'Strezz Tzets Plzltlsz',
        'stressTestPlaylistNameText':'Plzlrjtls Nmlgz',
        'stressTestPlaylistTypeText':'Plrntllst Tpzfm',
        'stressTestRoundDurationText':'Rngjfzfl Drurnastnfn',
        'stressTestTitleText':'Strnflz Tstz',
        'titleText':'Bnchrmfsjf & Stffz Tsgsz',
        'totalReloadTimeText':'Totalf rlslze tmz: ${TIME} (see log for details)',
        'unlockCoopText':'Unzllfsf co-op lvlflsz'
    },
    'defaultFreeForAllGameListNameText':'Dzfáult Féee-fzr-Azl Gámés',
    'defaultGameListNameText':'Defaultz ${PLAYMODE} Plflzjlz',
    'defaultNewFreeForAllGameListNameText':'Méz Fée-fzr-Azl Gázmes',
    'defaultNewGameListNameText':'Mz ${PLAYMODE} Plzllst',
    'defaultNewTeamGameListNameText':'Méz Táam Gézmes',
    'defaultTeamGameListNameText':'Dzéaulzt Tzam Gámzz',
    'deleteText':'Deferf',
    'demoText':'Dmfwef',
    'denyText':'Dénziy',
    'desktopResText':'Dzlflfjz Rzflz',
    'difficultyEasyText':'Ezrz',
    'difficultyHardOnlyText':'Hrdf Mdd Onflz',
    'difficultyHardText':'Hrefz',
    'difficultyHardUnlockOnlyText':('Th cowej fwojco wefj aweoiejroa doif aoef.\n'
                                    'Dof coiejwo iefjowei ojcowijeofijeofjwef?'),
    'directBrowserToURLText':'Plzlsl dirzlt a wblf browlfer tz thz flzllng URL:',
    'disableRemoteAppConnectionsText':'Disojf c woij ewof-app cowjf woejwe',
    'disableXInputDescriptionText':'Allow mor wow ejo4 cow oeicjwo cobu oaf woejfowie jowrj',
    'disableXInputText':'Dio cow eofwije',
    'doneText':'Dónz',
    'drawText':'Drawz',
    'duplicateText':'DSFcoiwjef',
    'editGameListWindow':{
        'addGameText':('Aédd\n'
                       'Gzéme'),
        'cantOverwriteDefaultText':'Cznt oéerzwrzite thez dúfauzlt plzlltlz!',
        'cantSaveAlreadyExistsText':'A pzlslfz wizh thz nmzl alrzdy exisrarz!',
        'cantSaveEmptyListText':'Czn\'t sévze anz eptóy gze lúst!',
        'editGameText':('Edzét\n'
                        'Gzme'),
        'gameListText':'Gámé Lzúst',
        'listNameText':'Plzljlfz Nmflf',
        'nameText':'Néáme',
        'removeGameText':('Rzmóve\n'
                          'Gzmze'),
        'saveText':'Sézve Lzést',
        'titleText':'Plzltls Edirtzlr'
    },
    'editProfileWindow':{
        'accountProfileInfoText':('Thi foic oiwe ofijaoijc oppoyw ofiuwo\n'
                                  'ico coajob aon fcouaoir coa fosof\n'
                                  '\n'
                                  '${ICONS}\n'
                                  '\n'
                                  'Cfocjo cuoso cporijfo oi you anav to sue\n'
                                  'dif o cjoiwnoam ooifon onrs.'),
        'accountProfileText':'(accfnsf profiofs)',
        'availableText':'Thz nmff "${NAME}" if oviajvoi fof.',
        'changesNotAffectText':'Nótez: chuznges wzll nót azfeét chzráctezrs zlready itze gúme',
        'characterText':'chljraflzr',
        'checkingAvailabilityText':'Chkfjofwi agavaifj for "${NAME}"...',
        'colorText':'cólzr',
        'getMoreCharactersText':'Gzl Mzrz Chrjafewerz..',
        'getMoreIconsText':'Gzzt Mrrz Icnffz...',
        'globalProfileInfoText':('Gllfoij coijw pefj acpoiwj poijf oienaowieoia oifof\n'
                                 'naoim owfoijweof i. THofo oaicjoieoij ocnoso.'),
        'globalProfileText':'(glfjlic procjof)',
        'highlightText':'híghlzght',
        'iconText':'icfnfz',
        'localProfileInfoText':('Lfjoci fplkw oijcwofj woeif owci owiej foiwjeofi wjeff\n'
                                'not oafij aoicjwoeiw ocjoaiw fow. Upfgra foicj oijofaf\n'
                                'to ojovia cooijf wo oacj oiwejfo wfeoococ cjiocs.'),
        'localProfileText':'(lcllf proriocf)',
        'nameDescriptionText':'Pléyzr Náme',
        'nameText':'Núme',
        'randomText':'rándzm',
        'titleEditText':'Edít Prófílze',
        'titleNewText':'Néw Prófílze',
        'unavailableText':'"${NAME}" i coif owcij owejf; tra coain fname.',
        'upgradeProfileInfoText':('Thofi cowie jfojroie osejo voeja;ofowfe\n'
                                  'and foajoai weft oayoucoait onto points.'),
        'upgradeToGlobalProfileText':'Upoifjo toi Glcojw efProicjoifjz'
    },
    'editProfilesAnyTimeText':'(yoú cén údzt prófilzs át úny tíme úndzr \'séttinzs\')',
    'editSoundtrackWindow':{
        'cantDeleteDefaultText':'Czé\'t délzte défaúlz sóunztráck.',
        'cantEditDefaultText':'Czn\'t ézit dzfáult sondtrack.  Dzplícaze ít ór crezte á nów zne.',
        'cantEditWhileConnectedOrInReplayText':'Cfn ef we souf oj woeh oconnnect ot jpa pray or oacnoefof wrpal.',
        'cantOverwriteDefaultText':'Cún\'t ovarwréte dzfaxlt sóunztrack',
        'cantSaveAlreadyExistsText':'A snfjdfzzf wzth thz nmxl alreeyx exisarsz!',
        'copyText':'Cópy',
        'defaultGameMusicText':'<défazlt gáme múzsic>',
        'defaultSoundtrackNameText':'Dúfazlt Seóndtrúck',
        'deleteConfirmText':('Dzléte Sóuzdtráck:\n'
                             '\n'
                             '\'${NAME}\'?'),
        'deleteText':('Dúléte\n'
                      'Sndfjflr'),
        'duplicateText':('Dúplízate\n'
                         'Sndfjrtrzkz'),
        'editSoundtrackText':('Dúléte\n'
                              'Sndjfrazk'),
        'editText':('Edjf\n'
                    'Sndfjarljrz'),
        'fetchingITunesText':'fétczing iTúnes plzylísts...',
        'musicVolumeZeroWarning':'Wzrnízg: mísuc vólzme ús sét tó 0',
        'nameText':'Nzmé',
        'newSoundtrackNameText':'Mz Soundtrckz ${COUNT}',
        'newSoundtrackText':'Néw Sóundztráck:',
        'newText':('Neflw\n'
                   'Snsdjralrz'),
        'selectAPlaylistText':'Sélézt A Pláylzst',
        'selectASourceText':'Mzicf Srlfflz',
        'soundtrackText':'SóuzdTráck',
        'testText':'túst',
        'titleText':'Sndflarrz',
        'useDefaultGameMusicText':'Dfzlfl Gmzl Mzlgl',
        'useITunesPlaylistText':'iTznfl Plzllzst',
        'useMusicFileText':'Mzlgl Flzl (mp3, tzz)',
        'useMusicFolderText':'Fldlzr ofz Mzlfic Flzlz'
    },
    'editText':'Edf',
    'endText':'Enzf',
    'enjoyText':'Enfjofjw!',
    'epicDescriptionFilterText':'${DESCRIPTION} Ín ípic slúw mztíon.',
    'epicNameFilterText':'${NAME} Epícz',
    'errorAccessDeniedText':'acczlr dnfflz',
    'errorOutOfDiskSpaceText':'orz of dkzk spzlfz',
    'errorText':'Errórz',
    'errorUnknownText':'unknznlz errzzz',
    'exitGameText':'$Excej ${APP_NAME}',
    'exportSuccessText':'\'${NAME}\' woejpcj',
    'externalStorageText':'Extzljrzl Stjrfjzfgz',
    'failText':'Fáilz',
    'fatalErrorText':('Uz Hofwco wije fowiejf weoifw oef.\n'
                      'pc oef owjcoije ow f wco weofijweo\n'
                      'contcat ${EMAIL} fo cowijef.'),
    'fileSelectorWindow':{
        'titleFileFolderText':'Slct a Flzl orz Folzlfld',
        'titleFileText':'Slzlclt a Flzlf',
        'titleFolderText':'Slzlctz a Fldldfrz',
        'useThisFolderButtonText':'Uslz Thizl Fldlrz'
    },
    'finalScoreText':'Fínúl Scóze',
    'finalScoresText':'Fínúl Scórez',
    'finalTimeText':'Fínál Tímz',
    'finishingInstallText':'Fbfhaifweuhf Ubsfkasfhdzl onz mmfomasf...',
    'fireTVRemoteWarningText':('* Frz z brttlrz wpzjoirzrz, rrz\n'
                               'Gmfj Cnoroajflz rz inglnzf thz\n'
                               '\'${REMOTE_APP_NAME}\' app on yrz\n'
                               'phzjfz anz tbljrzz.'),
    'firstToFinalText':'Fírzt-tú-${COUNT} Fínzl',
    'firstToSeriesText':'First-to-${COUNT} Séréz',
    'fiveKillText':'FÍVÍ KZLL!!!',
    'flawlessWaveText':'Flúwlzés Wúví!',
    'fourKillText':'QÚZD KÍLL!!!',
    'freeForAllText':'Fzée-fúr-Azll',
    'friendScoresUnavailableText':'Fríénd scóres unávailáblz.',
    'gameCenterText':'Gzmz Centerlz',
    'gameCircleText':'GamzCírclz',
    'gameLeadersText':'Gámé ${COUNT} Léádérs',
    'gameListWindow':{
        'cantDeleteDefaultText':'Cán\'t délzte thú défazlt gáme lést!',
        'cantEditDefaultText':'Cázn\'t édit tze défazlt gázme líst!  Dúpléczte ít ór créute á néw óne.',
        'cantShareDefaultText':'You w wolf wi eofw ec woef ef.',
        'deleteConfirmText':'Dzléte Gázme Lísz: ${LIST}?',
        'deleteText':('Deletaz\n'
                      'Pltjalsfz'),
        'duplicateText':('Dupclilar\n'
                         'Plsfjalfiz'),
        'editText':('Ezltjf\n'
                    'Plaflfzlz'),
        'gameListText':'Gzéme Lízt',
        'newText':('Núw\n'
                   'Plzlrlrzl'),
        'showTutorialText':'Shzwlf Trltlrjlzjf',
        'shuffleGameOrderText':'Shúfflze Gáme Oéder',
        'titleText':'Cmtlajrz ${TYPE} Plzlsfwz'
    },
    'gameSettingsWindow':{
        'addGameText':'Adf Gámé'
    },
    'gamepadDetectedText':'1 glmpgpoz detcalfjfz',
    'gamepadsDetectedText':'${COUNT} gmdpfzj dtecjterd.',
    'gamesToText':'${WINCOUNT} gámzs tú ${LOSECOUNT}',
    'gatherWindow':{
        'aboutDescriptionLocalMultiplayerExtraText':('Rmgrar z: anzl flje oa aosdfj oaisjdf oaif jewf\n'
                                                     'ocn cncontjalf iznf foyocu ltafh aconcotrlz.'),
        'aboutDescriptionText':('Uzl thafl tbs tz assmdlb a pratlzf\n'
                                '\n'
                                'Prlajtla lz yzz plz zglmfl and rarntalnflf\n'
                                'pw hfo o fjalr anafdlcl aro doijffljz\n'
                                '\n'
                                'Usz thz ${PARTY} bttnz antz tha fpz arnafl tz\n'
                                'chrhz antz ntinaf c inwhat ptohr\n'
                                '(ons a cntafljar, przlz ${BUTTON} whz inz a mnf)'),
        'aboutText':'Abffnlz',
        'addressFetchErrorText':'<rjwef ftafhew adfawwer>',
        'appInviteInfoText':('Ivnir afoc weoif acj w;oejf ;owej owef\n'
                             'gzt ${COUNT} frr ztoijco . Youcl rlrlrjz\n'
                             '${YOU_COUNT} frz coe cow eofjwoefs.'),
        'appInviteMessageText':'${NAME} fwoj fojwc ${COUNT} tijowfi iz ${APP_NAME}',
        'appInviteSendACodeText':'Sndf Thm a Cdofoz',
        'appInviteTitleText':'${APP_NAME} App Invoff',
        'bluetoothAndroidSupportText':'(wrks thz andf Andrjef dvcewf supportsf Blzltahofs)',
        'bluetoothDescriptionText':'Hzt/jnz a prrty overer Blzthffz:',
        'bluetoothHostText':'Hzts overz Blztnfhfz',
        'bluetoothJoinText':'Jnzlz voer Blthfhogz',
        'bluetoothText':'Blztthzz',
        'checkingText':'chzckinggz..',
        'dedicatedServerInfoText':'For code wocj woiejfowiejf, loci joweijf owiejfw. Se eocwj efowiejo wcoweijf woeifowoco er.',
        'disconnectClientsText':('Thz wlzl dicntjf thz ${COUNT} pljflaf (s)\n'
                                 'inc yrrz prthra.  Arz yrz fsrru?'),
        'earnTicketsForRecommendingAmountText':('Fofofj oicow  ${COUNT} ocwjoe f cow ef woefje\n'
                                                '(aocweo fwjoefi jo${YOU_COUNT} cowiejfowi oie)'),
        'earnTicketsForRecommendingText':('Shz thz gom \n'
                                          'fo cowiej coiwoij...'),
        'emailItText':'Emcofj It',
        'friendHasSentPromoCodeText':'${COUNT} ${APP_NAME} toijcoif cowf ${NAME}',
        'friendPromoCodeAwardText':'Yz rceive ${COUNT} tofjow cowe cowejfow jefowei.',
        'friendPromoCodeExpireText':'Thz cof wolfl wcpof jin ${EXPIRE_HOURS} hcouwf aono wijfo wjeoiwjfjpo pfsfs.',
        'friendPromoCodeInfoText':('It ooijc wolf woiwjeoef ${COUNT} ocjowef.\n'
                                   '\n'
                                   'Tz fowl "Settings->Advanced->Enter Promo Code" ice wefowcj weofjweoif \n'
                                   'Zzz bombsquadgame.com cow efoiwcej woejf woeifjowef.\n'
                                   '  awe oiwjefowej owejf ${EXPIRE_HOURS} ;ofj ;woiefj ;oweijf ;woiej'),
        'friendPromoCodeInstructionsText':('To Us ocj , ofijwe ${APP_NAME} oafn aco"segoingaf- aocij weoifjwoe fowiejoijcowijcoiwjef.\n'
                                           'See ofjc oiwejfowje foajfo weofjodijf oiasjgo isjdfo ijaweoijfowije oiwjoifjw.'),
        'friendPromoCodeRedeemLongText':'It cnf vow weofjwoefi joef ${COUNT} ffoij cowijetoi cwoiej fo ${MAX_USES} pcojfofz.',
        'friendPromoCodeRedeemShortText':'It cnf br coefwf fwfof ${COUNT} toico foin ciwfj gmes.',
        'friendPromoCodeWhereToEnterText':'(inz "Settdfings->Adwefwced->Eftcer Codze")',
        'getFriendInviteCodeText':'Gz Frjor Infivo Cdz',
        'googlePlayDescriptionText':'Invlt Gglglz Plzlz plzlfer tz yzr prtaryz:',
        'googlePlayInviteText':'Invtlzz',
        'googlePlayReInviteText':('Tnz arzs ${COUNT} Gflf Plzz Plalfjdsf oin weojf wfeoyowiufe\n'
                                  'whiz ewofij woijdoisoic o asodf wfiawje;aoew aoiwfj.\n'
                                  'TIncowjf oweofjao wotonwei oiacoiw eotijweto tat.'),
        'googlePlaySeeInvitesText':'Szz Invtlfz',
        'googlePlayText':'Gzzlg Plz',
        'googlePlayVersionOnlyText':'(Glfl plz versofj coniclfn)',
        'hostPublicPartyDescriptionText':'Hewn oje cowiefwdf',
        'inDevelopmentWarningText':('WRNRLJFF\n'
                                    'Nt-f psfdo asdj PREPP OE vojoi oweifj owjj.dsas\n'
                                    'FRofj woviow ejpfoiwejf paoij oiwjecojwofj\n'
                                    'aojfo aijwco wijeowjf oaijfo jwoefijwoeifj'),
        'internetText':'Off',
        'inviteAFriendText':('FO jwfo wcej owiejf woijf;aowei jf;aowiej;w\n'
                             'towyfaoijcowe foaiwj oweijf ${COUNT} fowifj icirks.'),
        'inviteFriendsText':'Invofj Frirnzz',
        'joinPublicPartyDescriptionText':'Jc owe  oefPuwer',
        'localNetworkDescriptionText':'Mnnrl',
        'localNetworkText':'Lczflz Nworkrz',
        'makePartyPrivateText':'Mk Mow ojpowefjpowjeof',
        'makePartyPublicText':'Mk PmY pcowej oacjo wei',
        'manualAddressText':'Addrraz',
        'manualConnectText':'Cnnzgmc',
        'manualDescriptionText':'Jnzlz a prrt brz adrarfs:',
        'manualJoinableFromInternetText':'Arz zy joing  frmz the winterrws?',
        'manualJoinableNoWithAsteriskText':'NZ*',
        'manualJoinableYesText':'YZF',
        'manualRouterForwardingText':'*tz fgj thzf, tafh confiefjao ayoru routheoafe jfor dsf UDP prt ${PORT} tz yoru local addrrz',
        'manualText':'Mnfrulz',
        'manualYourAddressFromInternetText':'Yrrz adrar frmz thz internefat:',
        'manualYourLocalAddressText':'Yrrz lcl addratrz:',
        'noConnectionText':'<nz cnnectars>',
        'otherVersionsText':'(otco verosfjso)',
        'partyInviteAcceptText':'Acczlfp',
        'partyInviteDeclineText':'Dclflz',
        'partyInviteGooglePlayExtraText':'(szz thz \'Gllglz Plz\' tab in the \'Gthfz\' wndfj)',
        'partyInviteIgnoreText':'Ignfjz',
        'partyInviteText':('${NAME} hz invite yz\n'
                           'to fjoia f fatpartyz.'),
        'partyNameText':'Poijf OFwoe j',
        'partySizeText':'pwtoifj cowief',
        'partyStatusCheckingText':'cjoefij cowijefo weft...',
        'partyStatusJoinableText':'your cp woefj cow efoajpocjwoe rowijcowijer',
        'partyStatusNoConnectionText':'oefj wow jeojrowiejr',
        'partyStatusNotJoinableText':'yrowu coe apweo c ojoicowiejoriwodnfdf',
        'partyStatusNotPublicText':'your two cow eijowenotcb',
        'pingText':'pow',
        'portText':'weft',
        'requestingAPromoCodeText':'Roifjo jc a promco fojror...',
        'sendDirectInvitesText':'Snd Direoc Invirrzz',
        'sendThisToAFriendText':'Snd roij coij to fowo owijr:',
        'shareThisCodeWithFriendsText':'Shzrr tiz crrd thtf fforjrz.',
        'showMyAddressText':'Show oe cow eijfwef',
        'startAdvertisingText':'Stasi Advoierowijrz',
        'stopAdvertisingText':'Stop Aodvoierz',
        'titleText':'Gthzrz',
        'wifiDirectDescriptionBottomText':('Ifz allz dvicoew hfz a \'WOFJFJ JDf pnc, thoo asdhousdfl lboeij woife oiuzeufnd\n'
                                           'and conecwn to fhaoeiof Onc alz eodoeiv ad caoocnornct, yz can bpzl afprt\n'
                                           'aowihe and comlcoa lntoweij ftab, jowf asdms reag awe fiw fnweorwerwekr\n'
                                           '\n'
                                           'Fzr befj weojwea, wowf oaf dsfoac aosidjf oasdjf oajsdf ${APP_NAME} party fhofz.'),
        'wifiDirectDescriptionTopText':('Wjf a can def ajsfd lajsd flakjsdflsdljoiwjef oiwjef oaje ofijwe foijwfe\n'
                                        'nednf and andfoidjf wane two thou foiwa eoiANdo irjo 4.1 or manor.\n'
                                        '\n'
                                        'Th ojfwo uousdf, Opn Witi foiwefoij oiad asd;o awofjweoijfo iwjmne..'),
        'wifiDirectOpenWiFiSettingsText':'Opnz WifZ Snnfaz',
        'wifiDirectText':'Wz-Fz Dract',
        'worksBetweenAllPlatformsText':'(wrorkz btwflf alz pltafmmrs)',
        'worksWithGooglePlayDevicesText':'(wlokrlz thf divcie srnngaf thz Gllglz Plz (android) gvjerajf ofz thez gmz)',
        'youHaveBeenSentAPromoCodeText':'Yo hv ofj wcasn a ${APP_NAME} pwofj wcode:'
    },
    'getCoinsWindow':{
        'coinDoublerText':'Cznn Dnblzrz',
        'coinsText':'${COUNT} Cnfjflz',
        'freeCoinsText':'Frzz Cntnz',
        'restorePurchasesText':'Rzatlsf Pncharlrzz',
        'titleText':'Gzt Cnflzz'
    },
    'getTicketsWindow':{
        'freeText':'FRZZ!!',
        'freeTicketsText':'Frzz Tkkckztz',
        'inProgressText':'A tnfajocj in nfo cpoaro fl p lejfaowf oit agiosd fomoemnt.',
        'purchasesRestoredText':'Pfojfofjf resotores.',
        'receivedTicketsText':'Recvnrrd ${COUNT} rclfjsf!',
        'restorePurchasesText':'Rzsgrrz Prchfrrtz',
        'ticketDoublerText':'Tckfkrz Dblrrerz',
        'ticketPack1Text':'Smllz Tckrt Pck',
        'ticketPack2Text':'Mdmfm Tkfkf Pck',
        'ticketPack3Text':'Lrggl Tkcct Pck',
        'ticketPack4Text':'Jmfpmf Tkckf CPkf',
        'ticketPack5Text':'Mmthf Tckff Pckc',
        'ticketPack6Text':'Ulzjtla Tkckdf Pck',
        'ticketsFromASponsorText':('Gzt ${COUNT} tkckjtz\n'
                                   'fzn a sobfhrkz'),
        'ticketsText':'${COUNT} Tckrtzz',
        'titleText':'Gtz Tckrtz',
        'unavailableLinkAccountText':('Srryrc, cpofj caodn oiwrj coi weo joweijwoief.\n'
                                      'If wc woiejf w, cocwi eoiaoth aciw jeojfow iejoijwef\n'
                                      'pcoj weo faona omowio wejfowijerwe.'),
        'unavailableTemporarilyText':'Thz iz cjrntelr unvalijrlwif; plz tarz agagnzl pttzzrz.',
        'unavailableText':'Srrz, thz is nz avoarjowwz.',
        'versionTooOldText':'Srrr.z haf voij eowij fowj aoig;o wido; ojep aowefj owepaidsof oefwoef.',
        'youHaveShortText':'you hv f ${COUNT}',
        'youHaveText':'yz hv ${COUNT} tickrrz'
    },
    'googlePlayText':'Gzzggl Plzz',
    'graphicsSettingsWindow':{
        'alwaysText':'Azlwáys',
        'autoText':'Aúto',
        'fullScreenCmdText':'Fúllézreen (Cmd-F)',
        'fullScreenCtrlText':'Fúlzcréen (Ctrl-F)',
        'gammaText':'Gámza',
        'highText':'Hígh',
        'higherText':'Híghrz',
        'lowText':'Lózw',
        'mediumText':'Mzdíum',
        'neverText':'Névzer',
        'resolutionText':'Résólution',
        'showFPSText':'Shów FPS',
        'texturesText':'Téxzures',
        'titleText':'Gézphícs',
        'tvBorderText':'TV Bórdzr',
        'verticalSyncText':'Vértícal Sync',
        'visualsText':'Vísuzls'
    },
    'helpWindow':{
        'bombInfoText':('- Bmmbb -\n'
                        'Stzzzfgr thff pzzfjnch, bfft\n'
                        'cfn rssltf inf grazzf sfff-injjoiury.\n'
                        'Fr bfzst refuzzts, thzz tzzzff\n'
                        'enfffmy bezzfere fuése rzs outffz.'),
        'bombInfoTextScale':0.6,
        'canHelpText':'${APP_NAME} cjo cweoff',
        'controllersInfoText':('Yz can fj plsjdf ${APP_NAME} osfasfoiajwefoa soadfove rhte nwgo\n'
                               'can fpdalsdf asoifn aodifoeub weofa faodo aoocnaotorlers.\n'
                               '${APP_NAME} ucouspod ra voarar elfoaf othw. yo aoidf ands ven ae\n'
                               'a sd controajjsdefowfj boijg ${REMOTE_APP_NAME} app\n'
                               'se t adsoenga;odva;ocntrononrod fomr orminfo.'),
        'controllersInfoTextFantasia':('Onfe ojfr twjo ploayers cjan usje tjhe keyoiboard, bjut BombjjSquad ifs bfest width gamjepads.\n'
                                       'Wiimotejs, adnd iOS/Android devfdsfs to condsdfrol chasdfcters. Hopezzfully you havesf\n'
                                       'somef of thesfe handffy.  See \'Controllefdrs\' undzer \'Settinfewgs\' fofr moree inefo.'),
        'controllersInfoTextMac':('Onfe ojfr twjo ploayers cjan usje tjhe keyoiboard, bjut BombjjSquad ifs bfest width gamjepads.\n'
                                  'BombSqufad cajn ufe USB gamepd, PS3 codzntrollers, XBsox 360 codsfnolers,\n'
                                  'Wiimotejs, adnd iOS/Android devfdsfs to condsdfrol chasdfcters. Hopezzfully you havesf\n'
                                  'somef of thesfe handffy.  See \'Controllefdrs\' undzer \'Settinfewgs\' fofr moree inefo.'),
        'controllersInfoTextOuya':('Yzz czf usfd OUYA contdsfasdf, PS3 conconafdsf, XBox 360 coancofffnf,\n'
                                   'afg ladsf of ofafsdf USB and Bluetooth gamepdfhfj with BombSquadz.\n'
                                   'Youf canzz alssf use ijOS aknd Androioid dejoivices as cojjntrollers vjia thej fjree\n'
                                   '\'BombSquadj Remoftef\' appf. Seef \'Controllerss\' underz \'Settinfgsf\' fozr mosre inffo.'),
        'controllersInfoTextScaleFantasia':0.56,
        'controllersInfoTextScaleMac':0.58,
        'controllersInfoTextScaleOuya':0.63,
        'controllersText':'Czontrollzerssz',
        'controllersTextScale':0.63,
        'controlsSubtitleText':'Yzjfo frrizjfly ${APP_NAME} czlfharcter hasf af fzew bzsic acsszzzcténs:',
        'controlsSubtitleTextScale':0.7,
        'controlsText':'Czfontrollzz',
        'controlsTextScale':1.4,
        'devicesInfoText':('Thz VR vojeora fo ${APP_NAME} afsdcn ab asdfpladf oasdjfaoveornt\n'
                           'thwa oefia oerj avoae a;oi joaje fo wfja wfj asodf ;aosj ;af\n'
                           'and acoapute randf amge aw asm con aofdi jas; oa;oinc;oianr\n'
                           'oncoain;d a; f;a owerj;aogiu;goau;o a;odi a;osidf oto joust\n'
                           'conasdf as dnl ob pwero pacoi joaijtoiajt.'),
        'devicesText':'Dvnlfz',
        'friendsGoodText':('Frizjdzofs gozn gnno godr poof.  ${APP_NAME} za funzzgoo da sevvrzsll playerszgo\n'
                           'anff supportgo up to 8 at argo time, which leadszfoo usz tof:'),
        'friendsGoodTextScale':0.6,
        'friendsText':'Friendificzs',
        'friendsTextScale':0.6,
        'jumpInfoText':('- Jzzum -\n'
                        'Jumjfp t crodfssfsmall gzps,\n'
                        'tothroéw thzfjgs farthff, ando\n'
                        'tof eresffés feezzclings ofjoy.'),
        'jumpInfoTextScale':0.6,
        'orPunchingSomethingText':'Or punching something, throwing it off a cliff, and blowing it up on the way down with a sticky bomb.',
        'orPunchingSomethingTextScale':0.5,
        'pickUpInfoText':('- PizzckUp -\n'
                          'Grazb flffgs, znemies, or anffhing\n'
                          'ezse notolted toz fji groffnd.\n'
                          'Presz againf tofféthrow.'),
        'pickUpInfoTextScale':0.6,
        'powerupBombDescriptionText':('Thf sdf asodjafds sdfosj fosfj\n'
                                      'jfoiadf oiisfj owefj aweofj owfj.'),
        'powerupBombNameText':'Tr asdf Bzzfzz',
        'powerupCurseDescriptionText':('Yousd ofjafj osjfj jsis fjiji\n'
                                       ' ...orz dfo yodsffu?'),
        'powerupCurseNameText':'Czzrse',
        'powerupHealthDescriptionText':('Rah dsflaj fdhfoifi.\n'
                                        'R dsfojasdofijdsf jfffjf.'),
        'powerupHealthNameText':'Mzfsdf fff',
        'powerupIceBombsDescriptionText':('Walfkjaf dsojsdfj\n'
                                          'bjaosdf jfoasdfj sfdj sdfij\n'
                                          'land foif goaoif.'),
        'powerupIceBombsNameText':'Icz Fjfiwf',
        'powerupImpactBombsDescriptionText':('Osjdf asdofjsdfjifjoasdfj\n'
                                             'objsd, poig fjidfso fimpac ff.'),
        'powerupImpactBombsNameText':'Trasdf-Bozmbs',
        'powerupLandMinesDescriptionText':('Thsojfi fojsofj of threosfj\n'
                                           'Usefjfojs ofo bjbos\n'
                                           'stoiz fo bosoijji.'),
        'powerupLandMinesNameText':'Lzjfo-Minfof',
        'powerupPunchDescriptionText':('Mzaz yffr pzzches zfffr,\n'
                                       'fzzzrsr, ssbsr, stééger.'),
        'powerupPunchNameText':'Bzzxing-Gzzoves',
        'powerupShieldDescriptionText':'Abslablh sdlfjaisfd fjfo fo sadoijad sf sdfjosaidjf.',
        'powerupShieldNameText':'Ezzgy-Szfield',
        'powerupStickyBombsDescriptionText':('Sticjf asdofjidf jfjj\n'
                                             'Hoidfjfjhll'),
        'powerupStickyBombsNameText':'Stifiziz-Bzbs',
        'powerupsSubtitleText':'Ozf courffse, nof gzme izs cozzlete wizzzut possfaups:',
        'powerupsSubtitleTextScale':0.8,
        'powerupsText':'Pzioowers',
        'powerupsTextScale':1.4,
        'punchInfoText':('- Pzznch -\n'
                         'Puzfjoi dof mosefre damafsdfe thfe\n'
                         'fasdfer yzr fsdfts af mfffng, so\n'
                         'rzn and szzin lizz a mffffs.'),
        'punchInfoTextScale':0.6,
        'runInfoText':('- Runf -\n'
                       'Holf ANZY buttonfo tof runz.  Shoullzder buoions workzwell eeifu havfe thez.\n'
                       'Rfzunning getssyou plaffz fastfro butk makezos thaozrd to turnzo, sofjwatch out for cljoiwiffs.'),
        'runInfoTextScale':0.6,
        'someDaysText':'Sasdfasdf days ydfadf just feelz ldfasdf pujnlching something.  Or bzjlowing ztosmethign upz.',
        'someDaysTextScale':0.55,
        'titleText':'${APP_NAME} Hfzlf',
        'toGetTheMostText':'Tzo grtt thrr mosta oufo zeez gammezsnort, youzl\'ll needzgo:',
        'toGetTheMostTextScale':0.8,
        'welcomeText':'Wwocjowe to ${APP_NAME}!'
    },
    'holdAnyButtonText':'<hozld ány búttón>',
    'holdAnyKeyText':'<hzóld azy kéy>',
    'hostIsNavigatingMenusText':'- ${HOST} isa nfojfo efj emnz klk fj voij -',
    'importPlaylistCodeInstructionsText':'Ou o who far cj owejow o woefj aoc oapo paoel cwewer.',
    'importPlaylistSuccessText':'Imps wef  ${TYPE} cow e ${NAME}',
    'importText':'Icwefwe',
    'importingText':'Imcowiew..',
    'inGameClippedNameText':('ic weof owef\n'
                             '"${NAME}"'),
    'installDiskSpaceErrorText':('ERROR: Unzlbj ao ppc pwef oj oinosjs.\n'
                                 'Yos  may aoefo wocw oeitjoidosdfdve.\n'
                                 'Cjfewf wocjdo spac ando ro gaing.'),
    'internal':{
        'arrowsToExitListText':'préss ${LEFT} ór ${RIGHT} tó exút lzst',
        'buttonText':'béttzn',
        'cantKickHostError':'You loci woof woeijcoonh.',
        'chatBlockedText':'${NAME} is fwocj woefj woeifj ${TIME} cowejof.',
        'connectedToGameText':'Jowiejwf \'${NAME}\'',
        'connectedToPartyText':'Joined ${NAME}\'s parthrlz',
        'connectingToPartyText':'Cnncttaignz...',
        'connectionFailedHostAlreadyInPartyText':'Cnfnecn fjlzlkefe; hzfj iz fjn fnoanowpar ry.',
        'connectionFailedPartyFullText':'Coiwje woie fow. oijwfo woecowefu.',
        'connectionFailedText':'Cnnflg fnldkfd.',
        'connectionFailedVersionMismatchText':('Cnndcat flld; hfdfj orurn sd adoifdoifj oawe ve;woirodfj osdf the gaz.\n'
                                               'Mk fowie cowie fowi coc woef woiejfoiafosid oaisdf.'),
        'connectionRejectedText':'Cnndmcat rnecjected.',
        'controllerConnectedText':'${CONTROLLER} czfznnected.',
        'controllerDetectedText':'1 cnototlrlfz dtecttzff.',
        'controllerDisconnectedText':'${CONTROLLER} dizcénnectud.',
        'controllerDisconnectedTryAgainText':'${CONTROLLER} diszcénezctz. Pléaze tréy coznéctíng agáín.',
        'controllerForMenusOnlyText':'Thoc weo woef woecowje ofj; cow eocijwoejowiejofj.',
        'controllerReconnectedText':'${CONTROLLER} récónnzécted.',
        'controllersConnectedText':'${COUNT} czntlafjorrz cntjafoctd.',
        'controllersDetectedText':'${COUNT} czntafjlrifl dtctatcz.',
        'controllersDisconnectedText':'${COUNT} cntjofaifz dscrontctdz.',
        'corruptFileText':'Cppro ff jfosjf dtecoewf w Plz wtoy finwocei wo iefj ro emaf ${EMAIL}',
        'errorPlayingMusicText':'Error plzling muicf: ${MUSIC}',
        'errorResettingAchievementsText':'Unzlbl tz rezerlz onzlflz achivirmvnrz; plz trz agnz ltrz.',
        'hasMenuControlText':'${NAME} owjie. woejf owc.',
        'incompatibleNewerVersionHostText':('Howe c ow ego inc wejoijwe ofijweof.\n'
                                            'Ups who who ineoifjwoc  woejoiw ejorwer.'),
        'incompatibleVersionHostText':('Hstn iz rningf a difefer ver ejoaf of thz gmz; vn\'t cndnocet.\n'
                                       'Mkf woeic woefj owe cwefowfo woeowei oijtwf.'),
        'incompatibleVersionPlayerText':('${NAME} iz nfowij f and ifid fioew af versino af oidf c acnat aonncect.\n'
                                         'Mk weocijw efow oc awejfowj eojcoiwjeojroewjf.'),
        'invalidAddressErrorText':'Errrlr; Invalidjf arrddrrs.',
        'invalidNameErrorText':'Errr: coijwef noamwef',
        'invalidPortErrorText':'Ero cowej woepor.',
        'invitationSentText':'Invitiadf sendt.',
        'invitationsSentText':'${COUNT} invitaosfod sdnt.',
        'joinedPartyInstructionsText':('A frnsd azh joinfiwef yr prtr.\n'
                                       'Gz tz \'Plaz\' tz start a gmfz.'),
        'keyboardText':'Kéybzard',
        'kickIdlePlayersKickedText':'Kkgjgf ${NAME} frz bnglfz idlzf.',
        'kickIdlePlayersWarning1Text':'${NAME} wllz bz kfkzfl in ${COUNT} scirzlr if stfzl idlfz.',
        'kickIdlePlayersWarning2Text':'(yz cnz trzn offz inz Sttnglgz -> Advnffzd)',
        'leftGameText':'Lefzf \'${NAME}\'',
        'leftPartyText':'Left ${NAME}\'s prtatz.',
        'noMusicFilesInFolderText':'Fldrz contlfzl nz mzlfig fizlflz.',
        'playerJoinedPartyText':'${NAME} jfnd th z parrty!',
        'playerLeftPartyText':'${NAME} lft thz party.',
        'rejectingInviteAlreadyInPartyText':'Rjcjofe invljf (lweljf cojwe aoaf)',
        'serverRestartingText':'ROIJOIOC. Pl coiwje oifjwoewerw ...',
        'signInErrorText':'Errlr zinging inf.',
        'signInNoConnectionText':'Unzlbl tz fsing fina f(no intnerlafj conencetion?)',
        'teamNameText':'Tzlljm ${NAME}',
        'telnetAccessDeniedText':'ERZOR: uzér hzs nát grúntzd télnzt accéss.',
        'timeOutText':'(tímes óut zn ${TIME} seconds)',
        'touchScreenJoinWarningText':('Yz hv jofndsf woijt iafh doctoucohdsf.\n'
                                      'If oth dfawas do oasdf osdft mwne owijf oadsjf.'),
        'touchScreenText':'TóuchScrzén',
        'trialText':'tríál',
        'unableToResolveHostText':'Error: cow e fwjeociwjeorir.',
        'unavailableNoConnectionText':'Tho fiw ficj woiejf paowejf (no itnwotower connecotjs?)',
        'vrOrientationResetCardboardText':('Us this to weoojeif co VR owfjow ego\n'
                                           'Tz pc we fwotj oa ocw eoowf eo awoifoacoincwr.'),
        'vrOrientationResetText':'VR ooiwjfowif rnefz.',
        'willTimeOutText':'(wzlf tmz oat if idle)'
    },
    'jumpBoldText':'JZMP',
    'jumpText':'Júmp',
    'keepText':'Kéepz',
    'keepTheseSettingsText':'Kéép thúse síttzngs?',
    'kickOccurredText':'${NAME} weir eowifjwoe.',
    'kickQuestionText':'Kfoicj ${NAME}?',
    'kickText':'Kcwef',
    'kickVoteFailedNotEnoughVotersText':'No wc weo ra;so asdpaj cowier.',
    'kickVoteFailedText':'Kfeoiw-vofj flwjef',
    'kickVoteStartedText':'A cjf co cow ef woa c ocwjeo jwof ${NAME}.',
    'kickVoteText':'Voice woes ocowieki',
    'kickWithChatText':'Typ  ${YES} oef cwoiejf owe ${NO} fojw c.',
    'killsTallyText':'${COUNT} kíllz',
    'killsText':'Kíllz',
    'kioskWindow':{
        'easyText':'Ezrz',
        'epicModeText':'Epcz Md',
        'fullMenuText':'Fllz Menuz',
        'hardText':'Hrzzd',
        'mediumText':'Mddnfmz',
        'singlePlayerExamplesText':'Snflgj Plzlrz / Co-opz Exmapflz',
        'versusExamplesText':'Versuz Exmapez'
    },
    'languageSetText':'Lngofijf isa tnsfl ${LANGUAGE}',
    'lapNumberText':'Lzp ${CURRENT} ofz ${TOTAL}',
    'lastGamesText':'(lász ${COUNT} gámúz)',
    'launchingItunesText':'Lznching iTnzlflz...',
    'leaderboardsText':'Lezérbórdz',
    'league':{
        'allTimeText':'Allz Tmz',
        'currentSeasonText':'Currngjg ZSfowife (${NUMBER})',
        'leagueFullText':'${NAME} Lfjofz',
        'leagueRankText':'Lglfl Rnrka',
        'leagueText':'Lggfzf',
        'rankInLeagueText':'#${RANK}, ${NAME} Lzlglf${SUFFIX}',
        'seasonEndedDaysAgoText':'Sfsf endf f ${NUMBER} fjosf afoc.',
        'seasonEndsDaysText':'Sfowefj wfn dofi ${NUMBER} dfjowf.',
        'seasonEndsHoursText':'Swso fo jiwf woie${NUMBER} fowhfz.',
        'seasonEndsMinutesText':'Seaonf woeo cowi fj${NUMBER} mcoinwefoij.',
        'seasonText':'Seocwofj ${NUMBER}',
        'tournamentLeagueText':'Yzz mff erwr ${NAME} leg foic woefin woef oeijfwfew.',
        'trophyCountsResetText':'Trphy cofo wuecw owef owioiafowf.'
    },
    'levelBestScoresText':'Bsfwo cowiejo ef${LEVEL}',
    'levelBestTimesText':'Best wfm coi ${LEVEL}',
    'levelFastestTimesText':'Fztjst tmzf on ${LEVEL}',
    'levelHighestScoresText':'Hghglz scorlz on ${LEVEL}',
    'levelIsLockedText':'${LEVEL} ís lúckzd.',
    'levelMustBeCompletedFirstText':'${LEVEL} múst bz cómplztíd fúrst.',
    'levelText':'Lvfjosfi ${NUMBER}',
    'levelUnlockedText':'Lévzl Unlóckzd!',
    'livesBonusText':'Lívzs Bónús',
    'loadingText':'lztijding',
    'loadingTryAgainText':'Lcowejf c weoifj wecoi woeijo...',
    'macControllerSubsystemBothText':'Both (eco woicowijef)',
    'macControllerSubsystemClassicText':'Cladsfsf',
    'macControllerSubsystemDescriptionText':'(tic oc woef. coli hoi ogief eer woeofowiejfoj)',
    'macControllerSubsystemMFiNoteText':('Mwoe cw obj c woe kiwi eoijwe;\n'
                                         'You wo. och weil foeiwjf oiwjc owije - > COijowiejfs.'),
    'macControllerSubsystemMFiText':'Mcojwe-coj-cwoejowif',
    'macControllerSubsystemTitleText':'Coijcw oijSuporer',
    'mainMenu':{
        'creditsText':'Crizetzzts',
        'demoMenuText':'Dmzm Mnzz',
        'endGameText':'Enzs Gzmé´fez',
        'exitGameText':'Excczzt Gamzzéé',
        'exitToMenuText':'Exít tzú ménu?',
        'howToPlayText':'Hwopm T´wPlayynf',
        'justPlayerText':'(Jzft ${NAME})',
        'leaveGameText':'Lvffz Gmmz',
        'leavePartyConfirmText':'Rellr lvvz thz parrttyz?',
        'leavePartyText':'Lvvz Prttzz',
        'leaveText':'Lvveeaavv',
        'quitText':'Qztiiizt',
        'resumeText':'Rssmzmmee',
        'settingsText':'Staettengis'
    },
    'makeItSoText':'Mrazzk itzz Séooee',
    'mapSelectGetMoreMapsText':'Gzzt Mrrz Mppz...',
    'mapSelectText':'Sélézt...',
    'mapSelectTitleText':'Mápz dú ${GAME}',
    'mapText':'Mázp',
    'maxConnectionsText':'Mc COnoweijwer',
    'maxPartySizeText':'McCoy cpweo fwocwoef',
    'maxPlayersText':'Mx Plweffz',
    'mostValuablePlayerText':'Móst Válúablz Pláyér',
    'mostViolatedPlayerText':'Móst Víoláted Pláyer',
    'mostViolentPlayerText':'Móst Víolznt Pláyér',
    'moveText':'Móvév',
    'multiKillText':'${COUNT}-KÍZL!!!',
    'multiPlayerCountText':'${COUNT} pláyzrs',
    'mustInviteFriendsText':('Ntz: yz mlfj coi jowe oif\n'
                             'oj "${GATHER}" cows coe ojwoef\n'
                             'ocnotjoi to pla coimcourlr.'),
    'nameBetrayedText':'${NAME} bétráyzd ${VICTIM}.',
    'nameDiedText':'${NAME} díed.',
    'nameKilledText':'${NAME} killzéd ${VICTIM}.',
    'nameNotEmptyText':'Náme cúnnzt bé émptz!',
    'nameScoresText':'${NAME} Scórzsz!',
    'nameSuicideKidFriendlyText':'${NAME} accfijflzfj dzrz.',
    'nameSuicideText':'${NAME} cómmittéd súizide.',
    'nameText':'Noiwjfe',
    'nativeText':'Nztvvz',
    'newPersonalBestText':'Néw pérsónzl bést!',
    'newTestBuildAvailableText':('A nwlf tat blfjl is aviflflzblz! (${VERSION} blzd ${BUILD}).\n'
                                 'Gzt iz tat ${ADDRESS}'),
    'newText':'Ncw',
    'newVersionAvailableText':'A newo coi efo ${APP_NAME} i c ifoi wf ${VERSION}',
    'nextAchievementsText':'Nx aoio ijoijefez',
    'nextLevelText':'Néxt Lévzl',
    'noAchievementsRemainingText':'- nónz',
    'noContinuesText':'(nz contoijfows)',
    'noExternalStorageErrorText':'Nz xtenrlf stlfsdf fnff onf thz dfvfojfzz',
    'noGameCircleText':'Errór: nút lúggzd íntó Góme Cúrclz',
    'noJoinCoopMidwayText':'Có-óp gúmzs cán\'t bz jóinzd mídwáy.',
    'noProfilesErrorText':('Yoú hávz nó pláyerz prófilzs, só yóu\'re stzck wíth \'${NAME}\'.\n'
                           'Gó tz Sétzings->Pláyerz Prófiles tú mzke yóurszlf á prófile.'),
    'noScoresYetText':'Nz scrrlz ytz.',
    'noThanksText':'Nó Thánkz',
    'noValidMapsErrorText':'Nó válíd máps fóund fúr thzs gáme typz.',
    'notEnoughPlayersRemainingText':'Nt zefwnoef plrjr rmeinging; exit anfo iwfj owjf oj ga emga;',
    'notEnoughPlayersText':'Yf nfdf a taflew ${COUNT} pfo wotj wofijow afo game!',
    'notNowText':'Nót Núw',
    'notSignedInErrorText':'Yz mst bz snginf intof yrrz accnt tz dz thzz.',
    'notSignedInGooglePlayErrorText':'Ym fij cow fj wo cowe toiw jcoj ojwoefj owi.',
    'notSignedInText':'(nf cow eofw)',
    'nothingIsSelectedErrorText':'Nothflf iz seleftcetzd!',
    'numberText':'#${NUMBER}',
    'offText':'Ófz',
    'okText':'OzKy',
    'onText':'Ón',
    'onslaughtRespawnText':'${PLAYER} wúll réspawn das wávz ${WAVE}',
    'orText':'${A} orz ${B}',
    'otherText':'Ofowiejf....',
    'outOfText':'(#${RANK} oút ófz ${ALL})',
    'ownFlagAtYourBaseWarning':('Yoúr owzn flág múst bé\n'
                                'át yzúr báse tó scóre!'),
    'packageModsEnabledErrorText':'Ntwrkz-plz nzt allrzd whlz pcket zmof aosdf oidsfwoe wfe(szz wsetnoaf adsasdnvanoce)',
    'partyWindow':{
        'chatMessageText':'Chclz Mafnfz',
        'emptyText':'Yrrz partzy ist memptyz',
        'hostText':'(hzt)',
        'sendText':'Snene',
        'titleText':'Yrrz Partar'
    },
    'pausedByHostText':'(pzzde bz hzstt)',
    'perfectWaveText':'Púrfzct Wávz!',
    'pickUpBoldText':'PZCKÚP',
    'pickUpText':'Píczk Uúp',
    'playModes':{
        'coopText':'Cz-opz',
        'freeForAllText':'Frzz-frz-Alz',
        'multiTeamText':'Mzltiz-Tmzz',
        'singlePlayerCoopText':'Sion Player /Cpfpowfji',
        'teamsText':'Tmmz'
    },
    'playText':'Pfnplay',
    'playWindow':{
        'coopText':'Czoo-op',
        'freeForAllText':'Férree-for-Azzxll',
        'oneToFourPlayersText':'1-4 plzzrzzz',
        'teamsText':'Téééémés',
        'titleText':'Plzaayz',
        'twoToEightPlayersText':'2-8 zpllzrrz'
    },
    'playerCountAbbreviatedText':'${COUNT}pz',
    'playerDelayedJoinText':'${PLAYER} wlzl enters atz z stzf  nfae ggmmz.',
    'playerInfoText':'Plzer Infor',
    'playerLeftText':'${PLAYER} lzfjt zjh gzmls.',
    'playerLimitReachedText':'Plzer lmzt of ${COUNT} rzched; nz jofjinsdfn allrlwzdz.',
    'playerLimitReachedUnlockProText':'Upfjfwef tz "${PRO}" wofj coje fwoe cojwiej woe ${COUNT} pffjz.',
    'playerProfilesWindow':{
        'cantDeleteAccountProfileText':'Yz cntn delfaje coweir anccnoar proffz.',
        'deleteButtonText':('Delefa\n'
                            'Prproif'),
        'deleteConfirmText':'Delfgt \'${PROFILE}\'?',
        'editButtonText':('Edtz\n'
                          'Prifaflz'),
        'explanationText':'(crtz custmo nmcm and appaoarnz frz)',
        'newButtonText':('Nwwz\n'
                         'Poriflrz'),
        'titleText':'Plzzerr Prfillz'
    },
    'playerText':'Pláyér',
    'playlistNoValidGamesErrorText':'Thz fpoiwfj coweoo conw ovj aodsf owcoi wefgages.',
    'playlistNotFoundText':'plzlst not fozfnd',
    'playlistsText':'Plzlntsfs',
    'pleaseRateText':('If yóu\'re énjoyíng ${APP_NAME}, pléase cónsider táking z\n'
                      'múment ánd rúting zt ór wrúting í reváew.  Thzs próvidzs\n'
                      'íseful fzédbíck ánd hélps súpport fútúre dévelópmént.\n'
                      '\n'
                      'thénkz!\n'
                      '-eric'),
    'pleaseWaitText':'Poke focwoe fjowef.',
    'practiceText':'Pcoifjzzz',
    'pressAnyButtonPlayAgainText':'Prézs ánz búttún tóz pláy agánz...',
    'pressAnyButtonText':'Prézs ánz búttún tóz cúntinze...',
    'pressAnyButtonToJoinText':'przés azny búttoz tz jóin...',
    'pressAnyKeyButtonPlayAgainText':'Prézs ánz kéy/búttún tóz pláy agánz...',
    'pressAnyKeyButtonText':'Prézs ánz kéy/búttún tóz cúntinze...',
    'pressAnyKeyText':'Préss ány kézy...',
    'pressJumpToFlyText':'** Przss júmp repéatedly tó flyz **',
    'pressPunchToJoinText':'przss PEZCH té júin...',
    'pressToOverrideCharacterText':'przss ${BUTTONS} tó óvézríde yózr chárazfter',
    'pressToSelectProfileText':'préezs ${BUTTONS} té seézlect yúr prófíle',
    'pressToSelectTeamText':'przéss ${BUTTONS} tó sézlezt yoór túém',
    'profileInfoText':('Créate prófilzs fór yourself and your friends to assign\n'
                       'yóurszlf námzs ánz cháractzrs ínstzad óf géttíng rándzm ónzs.'),
    'promoCodeWindow':{
        'codeText':'Czdfé',
        'codeTextDescription':'Prémsz Crdde',
        'enterText':'Entzzr'
    },
    'promoSubmitErrorText':'Errór szbmítting códe; chéck yóur ínternét cznnéctión',
    'ps3ControllersWindow':{
        'macInstructionsText':('Swízch zff zhe pzwer zn zhe báck zf yzur PS3, máke sure\n'
                               'Bluezzzzh ís enábled zn yzur Mác, zhen cznnecz yzur cznzrzller\n'
                               'zz yzur Mác víá á USB cáble zz páír zhe zwz. Frzm zhen zn, yzu\n'
                               'cán use zhe cznzrzller\'s hzme buzzzn zz cznnecz íz zz yzur Mác\n'
                               'ín eízher wíred (USB) zr wíreless (Bluezzzzh) mzde.\n'
                               '\n'
                               'Zn szme Mács yzu máy be przmpzed fzr á pássczde when páíríng.\n'
                               'Íf zhís háppens, see zhe fzllzwíng zuzzríál zr gzzgle fzr help.\n'
                               '\n'
                               '\n'
                               '\n'
                               '\n'
                               'PS3 cznzrzllers cznneczed wírelessly shzuld shzw up ín zhe devíce\n'
                               'lísz ín Syszem Preferences->Bluezzzzh. Yzu máy need zz remzve zhem\n'
                               'frzm zház lísz when yzu wánz zz use zhem wízh yzur PS3 ágáín.\n'
                               '\n'
                               'Álsz máke sure zz díscznnecz zhem frzm Bluezzzzh when nzz ín\n'
                               'use zr zheír bázzeríes wíll cznzínue zz dráín.\n'
                               '\n'
                               'Bluezzzzh shzuld hándle up zz 7 cznneczed devíces,\n'
                               'zhzugh yzur míleáge máy váry.'),
        'macInstructionsTextScale':0.74,
        'ouyaInstructionsText':('Tó usz a PS3 cóntróllzr wsth yóur ÓUYA, ssmply cónnzct st wsth a USB cablz\n'
                                'óncz tó pasr st.  Dósng thss may dsscónnzct yóur óthzr cóntróllzrs, só\n'
                                'yóu shóuld thzn rzstart yóur ÓUYA and unplug thz USB cablz.\n'
                                '\n'
                                'Fróm thzn ón yóu shóuld bz ablz tó usz thz cóntróllzr\'s HÓMZ buttón tó\n'
                                'cónnzct st wsrzlzssly. Whzn yóu arz dónz playsng, hóld thz HÓMZ buttón\n'
                                'fór 10 szcónds tó turn thz cóntróllzr óff; óthzrwssz st may rzmasn ón\n'
                                'and wastz battzrszs.'),
        'ouyaInstructionsTextScale':0.74,
        'pairingTutorialText':'péiríng tútóríal veídeo',
        'titleText':'Uzséng PS3 Cónzrollérs wízh ${APP_NAME}:'
    },
    'publicBetaText':'PZÚBLIC BÉZTA',
    'punchBoldText':'PÚNZCH',
    'punchText':'Púzch',
    'purchaseForText':'Púrcháse fúrz ${PRICE}',
    'purchaseGameText':'Púrchúze Gáme',
    'purchasingText':'Prjrcjfz...',
    'quitGameText':'Qcoifj ${APP_NAME}',
    'quittingIn5SecondsText':'Quéttzng ín 5 sécznds...',
    'randomPlayerNamesText':'DEFAULT_NAMES',
    'randomText':'Rzandomz',
    'rankText':'Rnkfz',
    'ratingText':'Rátzng',
    'reachWave2Text':'Réách wávé 2 tó ránk.',
    'readyText':'réády',
    'recentText':'Rcfjfzz',
    'remainingInTrialText':'rémáfiníng ín tríál',
    'remoteAppInfoShortText':('${APP_NAME} iz cow eofi co wefjowiej fowiejfowef\n'
                              'Cow enow c oweifj owiej oc owei fowije fowj ;join thsefaf\n'
                              '${REMOTE_APP_NAME} api c woe fj owiejc owe coiwjeowef\n'
                              'asdf contorfwefwe.'),
    'remote_app':{
        'app_name':'Bomc Rcorjorj',
        'app_name_short':'BSFmowcwe',
        'button_position':'Brroz Posijfoiwjr',
        'button_size':'Brrltjt Szr',
        'cant_resolve_host':'Cntto Rrrlj hrorz.',
        'capturing':'Cporrjz...',
        'connected':'Ctnntoicc.',
        'description':('Usf coi cyao o acj wof joic oaijojef a;owi ocaobOBm.\n'
                       'Ups to co w of avow wf ocw oei iwfor acoa wf mult apc a wefjo cp sonota toav a fowieort.'),
        'disconnected':'Doc wolf by user vowe.',
        'dpad_fixed':'ffojoc',
        'dpad_floating':'fljtoffz',
        'dpad_position':'D-Pd Pofjoijor',
        'dpad_size':'D-Pf zrrz',
        'dpad_type':'D-pd Tprpz',
        'enter_an_address':'Entro an addrrs',
        'game_full':'Thz gmc wif coj f cow tnoac aoj fojwoefjwe.',
        'game_shut_down':'Thz gocm ah soc ow townw.',
        'hardware_buttons':'Horjr oBurrlzz.',
        'join_by_address':'Jrorij boj Addrrzz.',
        'lag':'Lggz ${SECONDS} scofjfz',
        'reset':'Rzwf tz deferz',
        'run1':'Rrrnz',
        'run2':'Rnr z2',
        'searching':'Serarojc ofwe BBomsojo ggzfz...',
        'searching_caption':('Tpa co w toia noa cowef owiejower.\n'
                             'Mkf wuseo youc aeno toi oaoew rowjtooaor.'),
        'start':'Strwfz',
        'start_button':'Stwow',
        'version_mismatch':('Veroi jmoiowoejf\n'
                            'Mkac aot co boaisoijero caoioisd fjaoer\n'
                            'adc ot oacouweotu vowe ron aga.')
    },
    'removeInGameAdsText':'Unlkjfj  "${PRO}" in cowj wje of wejfoiwfoo oifoiwjef.',
    'renameText':'Rzngmlz',
    'replayEndText':'Enz Rpllz',
    'replayNameDefaultText':'Lzts Gmzl Rplzlz',
    'replayReadErrorText':'Errzr rdnglgz rplzlz flz.',
    'replayRenameWarningText':'Renznf "${REPLAY}" aftnf gmz oidf aosf asdj aoij keep aoioheor wofijo aivjoe rowijefowif.',
    'replayVersionErrorText':('Srrz, tzh replalz wz mddd inzl ad fidfffr\n'
                              'vererjz o f at the agamemfzz and acjewo tjj zluszd.'),
    'replayWatchText':'Wzzlt Rlpllzl',
    'replayWriteErrorText':'Errzz wrtzzlg rplzl fizlz.',
    'replaysText':'Rpzlzz',
    'reportPlayerExplanationText':('Uf woc ow efow efiwjco owe,we woi woiej ofijwoe fowe,wd fowidj owejfowief.\n'
                                   'Pef woc woejfowifw:'),
    'reportThisPlayerCheatingText':'Chttocz',
    'reportThisPlayerLanguageText':'Inpcowej oij Lnagoijafoj',
    'reportThisPlayerReasonText':'Wh cco wefo co aogjwo fjowef?',
    'reportThisPlayerText':'Rporijf Thif Plzlirz',
    'requestingText':'Rcjowcijc...',
    'restartText':'Réstártz',
    'retryText':'Rtefnz',
    'revertText':'Révúrt',
    'runBoldText':'RUZLN',
    'runText':'Rúun',
    'saveText':'Sávez',
    'scoreChallengesText':'Scóre Chálléngúz',
    'scoreListUnavailableText':'Sczerl lzst unvnslfljblz.',
    'scoreText':'Szóre',
    'scoreUnits':{
        'millisecondsText':'Mzlifjltlfjndfz',
        'pointsText':'Pntnz',
        'secondsText':'Sclnldfjz'
    },
    'scoreWasText':'(wús ${COUNT})',
    'selectText':'Slézcz',
    'seriesWinLine1PlayerText':'WZNNPLL THZ',
    'seriesWinLine1Scale':0.65,
    'seriesWinLine1TeamText':'WNZTTTM THZ',
    'seriesWinLine1Text':'WÍNZ THZ',
    'seriesWinLine2Scale':1.0,
    'seriesWinLine2Text':'SÉRÍZS!',
    'settingsWindow':{
        'accountText':'Acncljtz',
        'advancedText':'Advnfsdfjzd',
        'audioText':'Aédudief',
        'controllersText':'Cosljfoiwefjf',
        'enterPromoCodeText':'Enlsfl Przmfm Codnfff',
        'graphicsText':'Graphzzzz',
        'kickIdlePlayersText':'Kzjfk Idlze Plzerrls',
        'playerProfilesMovedText':'Ntzz: Plwef Profjowc hsv mcfw tz the Accfoj wenof co omain mcur.',
        'playerProfilesText':'Plefzjf Profifjss',
        'showPlayerNamesText':'Sfoz Plzersd Nzjmm',
        'titleText':'Szeetzgsss'
    },
    'settingsWindowAdvanced':{
        'alwaysUseInternalKeyboardDescriptionText':'(a smpd a, condofia efjwefoajewofoiaj;s a sodifj a;osdfjoitest  f)',
        'alwaysUseInternalKeyboardText':'Alzlt usl Intenralf kyBerz',
        'benchmarksText':'Bnchmkwr & Staf-Tsfsfz',
        'disableThisNotice':'(you come for wolf jwfowejoijer cowed wfoiwej jay)',
        'enablePackageModsDescriptionText':'(enleaf exjpaf mdoodn gcpappwro buf dsilas new t plz)',
        'enablePackageModsText':'Ebnblaf Lcjof Pcfowf Mdsfsz',
        'enterPromoCodeText':'Eznter Cdzs',
        'forTestingText':'Ntz: thz vlarj farz olflf rzz tsffcn anz wllz bz llfsf whnzl thzz app exrtzz.',
        'helpTranslateText':('${APP_NAME} lngalsdf transaldflksdfj arz fjocdmaosdf\n'
                             'sprnarted effrztzs.  Ifsdf oud\'fu likzz to cmdfoasdf corectsf\n'
                             'a sd fjafdsoijdf, flfowefj thz fljlnkdd blzljf.  Thansdlfn in andncas!'),
        'kickIdlePlayersText':'Kzkck Idlzlf Plzjrs',
        'kidFriendlyModeText':'Krz-Frjijglfz-Mzdz (rdfjifz voioifjf, fz)',
        'languageText':'Lnglfjslfd',
        'moddingGuideText':'Mddzng Gdufnzsd',
        'mustRestartText':'Yz msg restar thz gmm fof this tk ttk effectsz.',
        'netTestingText':'Ntwkrz Tsstcg',
        'resetText':'Rsttz',
        'showBombTrajectoriesText':'Shzlz Bomf Tfwoejcwoefz',
        'showPlayerNamesText':'SHzlfjl Plzlrr Nmzlzlls',
        'showUserModsText':'Shzl Mdsz Fldlrz',
        'titleText':'Advnafjfljdz',
        'translationEditorButtonText':'${APP_NAME} Tjofwijf Eoidjor',
        'translationFetchErrorText':'trnzlfgweg stdlsf unvavalrz',
        'translationFetchingStatusText':'chcking tranfsldf sttuffsz...',
        'translationInformMe':'Ofiw co. eom wccowoijef weiofwe  owef wc owefwrs.',
        'translationNoUpdateNeededText':'the crjlfidsj lnglfjdz iz upzl tx dtzzfs; woojofjd!',
        'translationUpdateNeededText':'** thz furur languares nezdsjd updates!!!! **',
        'vrTestingText':'VR Tzntgng'
    },
    'shareText':'Shcwef',
    'sharingText':'Chwoefz..',
    'showText':'Shz',
    'signInForPromoCodeText':'Yz mst singo in o accnno for cods ot thk weffets.',
    'signInWithGameCenterText':('To loci wo gamg wofiw efoiwjef.\n'
                                'coaej goajb oaj Game foc etapp.'),
    'singleGamePlaylistNameText':'Jzff ${GAME}',
    'singlePlayerCountText':'1 pláyzr',
    'soloNameFilterText':'${NAME} Sólzo',
    'soundtrackTypeNames':{
        'CharSelect':'Czárazter Sélection',
        'Chosen One':'Chósén Onz',
        'Epic':'Epíc Móde Games',
        'Epic Race':'Epíc Ráze',
        'FlagCatcher':'Cáptúre thz Flág',
        'Flying':'Háppy Thózghts',
        'Football':'Foótbazll',
        'ForwardMarch':'Aszáult',
        'GrandRomp':'Cónqúest',
        'Hockey':'Hóckzy',
        'Keep Away':'Kézp Awáy',
        'Marching':'Rúnazróund',
        'Menu':'Mzín Ménú',
        'Onslaught':'Onéslaúght',
        'Race':'Race',
        'Scary':'Kíng óf thé Híll',
        'Scores':'Scóre Scréen',
        'Survival':'Ezíminátion',
        'ToTheDeath':'Dáath Mzétch',
        'Victory':'Fínal Scóre Scréen'
    },
    'spaceKeyText':'spzz',
    'statsText':'Sfawfwf',
    'storagePermissionAccessText':'Tho cowefj woiejowefw.',
    'store':{
        'alreadyOwnText':'Yorz alrlfzl wozl ${NAME}!',
        'bombSquadProDescriptionText':('• Rmoi come fai oifwjeojf\n'
                                       '• Ubckff ${COUNT} bifn ciuefuh\n'
                                       '• +${PERCENT}% power foiacoiwfl\n'
                                       '• Unlclf \'${INF_ONSLAUGHT}\' anz\n'
                                       '  \'${INF_RUNAROUND}\' co of jews'),
        'bombSquadProFeaturesText':'Fettnafars:',
        'bombSquadProNameText':'${APP_NAME} Prz',
        'bombSquadProNewDescriptionText':('• OWjoc owejfowef dfwefwefwef\n'
                                          '• Woijc wefjweocjjcw fjweofijwef\n'
                                          '• wocje fowiejf:'),
        'buyText':'Bzy',
        'charactersText':'Czharggczzls',
        'comingSoonText':'Cmzngl Snznlsz...',
        'extrasText':'Extrrfz',
        'freeBombSquadProText':('Bfjaoefj ij foawje foijcowje oifjwo jf woaifjo waf\n'
                                'aowf aosdjfoaijcow iejojefo wjfowiefjo ${COUNT} foco wofeij a;iofj woj.\n'
                                'ENojfowaif oithwoefij ac owejfwoef jaoijf owicjoijcowiefj!\n'
                                '-Erfc'),
        'gameUpgradesText':'Gzmm Unzprjfzz',
        'getCoinsText':'Gzt Cnfljfz',
        'holidaySpecialText':'Hzlolidz Spzlzlflz',
        'howToSwitchCharactersText':'(gz tz ${SETTINGS} -> ${PLAYER_PROFILES} tz wfoiejf coijwoicoijwf)',
        'howToUseIconsText':'(croijoj oaf japocj paowejf owef"(in thc accj f enfo)" otj acoiejf w)',
        'howToUseMapsText':'(usf thwemc woeifj aojco wefjo wjaocj paowfj woeifjos)',
        'iconsText':'Icnofjf',
        'loadErrorText':('Unzlblf to zlfl bpgong.\n'
                         'Chlzl yrlzn intnlzfnl cnnfncsz.'),
        'loadingText':'lzdng',
        'mapsText':'Mzpz',
        'miniGamesText':'MnflzGmz',
        'oneTimeOnlyText':'(onc jf onlyf)',
        'purchaseAlreadyInProgressText':'A prnoif of thwf if mwof wofi aoer wofoiefw.',
        'purchaseConfirmText':'Prucoief ${ITEM}?',
        'purchaseNotValidError':('Prwoj focj owejf\n'
                                 'Contoewf ${EMAIL} if fowl efjw oajof.'),
        'purchaseText':'Pfoijcrz',
        'saleBundleText':'Bzfjoc Salfz!',
        'saleExclaimText':'Slfo!',
        'salePercentText':'(${PERCENT}% fifz)',
        'saleText':'SLFL',
        'searchText':'Srnczl',
        'teamsFreeForAllGamesText':'Tmmg / Frrzz-rff/Allz Gmffz',
        'totalWorthText':'*** ${TOTAL_WORTH} vafwf! ***',
        'upgradeQuestionText':'Upwfwef?',
        'winterSpecialText':'Wznter Spzlflfz',
        'youOwnThisText':'- yz wnfz thz -'
    },
    'storeDescriptionText':('asdfj fwofjwe fwjfjwf asdlfjsdf fdjatoijw;ojfpwoef wefjwoefjwfe.\n'
                            '\n'
                            'Blojsd;flj asdfj asd;ofjasdfoi a;sdijfs;dfsd jfdasoidjf ;aidsjf ;adsf\n'
                            'asdofa sdfijs;odf ;aosidjf ;asdfj;asdof;ijasdf;\n'
                            'sdjfsjd fasdf asdfasdfasdf'),
    'storeDescriptions':{
        'blowUpYourFriendsText':'Blzw upz yrzeor frdnfnz',
        'competeInMiniGamesText':'Cmplzl in mdmfl gmzlz rnglng fmzz rcngng to flznfg',
        'customize2Text':'Cztmzls chrcctsrsl, mnnin-gmzz, and evnf zl snftrrkckz.',
        'customizeText':'Cstmzlze chrzclterz dand crzlsldf yrzw ownz emin-gmzm sndorglrks.',
        'sportsMoreFunText':'Sprtzs arz mrzr fnzrs wthzr explowoafsdfs.',
        'teamUpAgainstComputerText':'Tmzls upz agansft thz cmpturzs.'
    },
    'storeText':'Stzlrle',
    'submitText':'Scowiejfwef',
    'submittingPromoCodeText':'Subjfoif Cdssz...',
    'teamNamesColorText':'Tmcoj Conor/ Coarle...',
    'teamsText':'Tééáémés',
    'telnetAccessGrantedText':'Tzélnt acczzss énazledz.',
    'telnetAccessText':'Tzélnt azcezs détzfcted; aélow?',
    'testBuildErrorText':'Thz tst-bld iz nz lnglsf actv.fz.  plz hckc frz nv vnarerz.',
    'testBuildText':'Tstg Blldz',
    'testBuildValidateErrorText':'Unbblldf tz validfajr tstb blflz. (nz netf cdnfdljfec?)',
    'testBuildValidatedText':'Tst Bjldf Vlaldkfsf; Enjzjf!',
    'thankYouText':'Thánk yóu fór yóur súppórt! Enjóy thé gáme!!',
    'threeKillText':'TRÍPLZ KÚLL!!',
    'timeBonusText':'Tíme Bónús',
    'timeElapsedText':'Tíme Elápszd',
    'timeExpiredText':'Tzmz Exprireizdd',
    'timeSuffixDaysText':'${COUNT}d',
    'timeSuffixHoursText':'${COUNT}hz',
    'timeSuffixMinutesText':'${COUNT}mz',
    'timeSuffixSecondsText':'${COUNT}sz',
    'tipText':'Tízp',
    'titleText':'Bmbmsqdz',
    'titleVRText':'BomboFjof VR',
    'topFriendsText':'Tóp Fríendz',
    'tournamentCheckingStateText':'Chkfjfowef oitwof oweifja oef pawoej owef...',
    'tournamentEndedText':'This foil jefoi weoa echo sd. An ewoifj wo oowifjowe soon.',
    'tournamentEntryText':'Tnofjwfe oecowiejw',
    'tournamentResultsRecentText':'Rcnet Touaofius aRamalsdf.',
    'tournamentStandingsText':'Tzewfjwoij Stndfalfjz',
    'tournamentText':'Tanfowijfowef',
    'tournamentTimeExpiredText':'Tmcoef Tm Epzoiejfefz',
    'tournamentsText':'Trzzmfnmflfzzs',
    'translations':{
        'characterNames':{
            'Agent Johnson':'Agjofi Jocwef',
            'B-9000':'B-90000',
            'Bernard':'Brzlfjfoz',
            'Bones':'Bnzl',
            'Butch':'Brzffd',
            'Easter Bunny':'Eefowj Boifjwoef',
            'Flopsy':'Flzpzfz',
            'Frosty':'Frrozf',
            'Gretel':'Gflrlz',
            'Grumbledorf':'Goijcowiefdf',
            'Jack Morgan':'Jcjo Mrggz',
            'Kronk':'Krrorzz',
            'Lee':'Lcwef',
            'Lucky':'Loiwjef',
            'Mel':'Mzzl',
            'Middle-Man':'Gmdflj-cmdf',
            'Minimus':'Mijowcf',
            'Pascal':'Pasclfz',
            'Pixel':'Poxiejf',
            'Sammy Slam':'Sm df cwoSflm',
            'Santa Claus':'Santa Clzous',
            'Santa Clause':'Szntana Clzlrnas',
            'Snake Shadow':'Snlj Co woefj',
            'Spaz':'Spzz',
            'Taobao Mascot':'Taco Mcwojefo',
            'Todd':'Tweet',
            'Todd McBurton':'Taj O woejfd',
            'Xara':'Xfwef',
            'Zoe':'Zob',
            'Zola':'Zlefw'
        },
        'coopIconNames':{
            ('Infinite\n'
             'Onslaught'):('Infíníte\n'
                           'Ónsláught'),
            ('Infinite\n'
             'Runaround'):('Ínfíníte\n'
                           'Rúnaróúnd'),
            ('Onslaught\n'
             'Training'):('Onsláughtz\n'
                          'Tráiníng'),
            ('Pro\n'
             'Football'):('Pró\n'
                          'Fóotbáll'),
            ('Pro\n'
             'Onslaught'):('Pró\n'
                           'Onsláughtz'),
            ('Pro\n'
             'Runaround'):('Pró\n'
                           'Rúnaróund'),
            ('Rookie\n'
             'Football'):('Róokíe\n'
                          'Fóotbálz'),
            ('Rookie\n'
             'Onslaught'):('Róokze\n'
                           'Onsláughz'),
            ('The\n'
             'Last Stand'):('Thé\n'
                            'Lást Stánd'),
            ('Uber\n'
             'Football'):('Úbér\n'
                          'Fóotbáll'),
            ('Uber\n'
             'Onslaught'):('Ubér\n'
                           'Onsláúght'),
            ('Uber\n'
             'Runaround'):('Úbér\n'
                           'Rúnároúnd')
        },
        'coopLevelNames':{
            '${GAME} Training':'${GAME} Tfjozijzs',
            'Infinite ${GAME}':'Infifiew ${GAME}',
            'Infinite Onslaught':'Íznfíníte Onzláught',
            'Infinite Runaround':'Iznfinite Runaround',
            'Onslaught':'Íznfíníte Onzláught',
            'Onslaught Training':'Onzláughtz Trzáíníng',
            'Pro ${GAME}':'Prz ${GAME}',
            'Pro Football':'Pró Football',
            'Pro Onslaught':'Pró Onzláught',
            'Pro Runaround':'Pró Runáround',
            'Rookie ${GAME}':'Rzzlfjf ${GAME}',
            'Rookie Football':'Rzokie Fúotbáll',
            'Rookie Onslaught':'Rúokíe Onzláught',
            'Runaround':'Iznfinite Runaround',
            'The Last Stand':'Thú Lázt Ztánd',
            'Uber ${GAME}':'Ubezr ${GAME}',
            'Uber Football':'Ubúr Football',
            'Uber Onslaught':'Ubzr Onzláught',
            'Uber Runaround':'Ubúr Runáround'
        },
        'gameDescriptions':{
            ('Be the chosen one for a length of time to win.\n'
             'Kill the chosen one to become it.'):('Bé thé chósen ónz fór a léngth éf tíme tó wzn.\n'
                                                   'Kzll thé chósen óne tz bécome út.'),
            'Bomb as many targets as you can.':'Bmb ojwe fo cj woef weoijcoj ofz.',
            'Carry the flag for ${ARG1} seconds.':'Cárrz thé flág fór ${ARG1} sécóndz.',
            'Carry the flag for a set length of time.':'Cárry thé flág fór á sét léngth oz tíme.',
            'Crush ${ARG1} of your enemies.':'Crúsz ${ARG1} óf yóúr énemies',
            'Defeat all enemies.':'Défetz álz enemíz.',
            'Dodge the falling bombs.':'Ddfjgzl thz flzjflg bjbjlfz.',
            'Final glorious epic slow motion battle to the death.':'Fínzl glóriozs épzc slów mótizn báttlz tó thz déath.',
            'Gather eggs!':'Gjowicj ewfgw!',
            'Get the flag to the enemy end zone.':'Gét thé flág tó thz enémy énd zóne.',
            'How fast can you defeat the ninjas?':'Hz wfwe cowej oiwcowiefo idnininas?',
            'Kill a set number of enemies to win.':'Kílz á sét númbér óf énmiez tó wín',
            'Last one standing wins.':'Lást ónz stándíng wíns.',
            'Last remaining alive wins.':'Lást rzmáiníng álzve wíns.',
            'Last team standing wins.':'Lást tézm stándíng wíns.',
            'Prevent enemies from reaching the exit.':'Prévúnt énemizs fróm reáching thé exít.',
            'Reach the enemy flag to score.':'Réach thz enémy flág tó scórz.',
            'Return the enemy flag to score.':'Réturz thz énemy flág tó scórz.',
            'Run ${ARG1} laps.':'Rún ${ARG1} lápz.',
            'Run ${ARG1} laps. Your entire team has to finish.':'Rún ${ARG1} lápz. Yóur éntzre téam has tó fznish.',
            'Run 1 lap.':'Rún 1 láp.',
            'Run 1 lap. Your entire team has to finish.':'Rún 1 láp. Yóur éntire téam has tó fznish.',
            'Run real fast!':'Rún réaz fázt',
            'Score ${ARG1} goals.':'Scóré ${ARG1} góalz.',
            'Score ${ARG1} touchdowns.':'Scóré ${ARG1} tóuchdównz.',
            'Score a goal':'Scórz á góal',
            'Score a goal.':'Scórz á góal.',
            'Score a touchdown.':'Scórz á tóuchdówz.',
            'Score some goals.':'Scórz sómz góalz.',
            'Secure all ${ARG1} flags.':'Sécúrz álz ${ARG1} flágz.',
            'Secure all flags on the map to win.':'Sécurz álz flúgs ón zú máp té wín',
            'Secure the flag for ${ARG1} seconds.':'Séczre thé flág fúr ${ARG1} sécúnds.',
            'Secure the flag for a set length of time.':'Séczré thé flúg fzr á sét lzngth óf túme.',
            'Steal the enemy flag ${ARG1} times.':'Stéál thé enémy flág ${ARG1} tímés.',
            'Steal the enemy flag.':'Stéál thé ezémy flúg',
            'There can be only one.':'Théré cán bé ónlz óne.',
            'Touch the enemy flag ${ARG1} times.':'Toúch thé enémy flág ${ARG1} tímés.',
            'Touch the enemy flag.':'Tóúcz thé ezémy flúg',
            'carry the flag for ${ARG1} seconds':'cárrz thé flág fór ${ARG1} sécóndz',
            'kill ${ARG1} enemies':'kílz ${ARG1} énzmíez',
            'last one standing wins':'lást ónz stándíng wíns',
            'last team standing wins':'lást tézm stándíng wíns',
            'return ${ARG1} flags':'rétúrn ${ARG1} flágz',
            'return 1 flag':'rétúrn 1 flág',
            'run ${ARG1} laps':'rún ${ARG1} lápz',
            'run 1 lap':'rún 1 láp',
            'score ${ARG1} goals':'Scóré ${ARG1} góalz',
            'score ${ARG1} touchdowns':'scórz ${ARG1} tóuchdównz',
            'score a goal':'scórz á góal',
            'score a touchdown':'scóre á tóuchdówn',
            'secure all ${ARG1} flags':'sécúrz álz ${ARG1} flágz',
            'secure the flag for ${ARG1} seconds':'séczre thé flág fúr ${ARG1} sécúnds',
            'touch ${ARG1} flags':'tóúch ${ARG1} flúgz',
            'touch 1 flag':'tóúch 1 flúg'
        },
        'gameNames':{
            'Assault':'Azzáulz',
            'Capture the Flag':'Cápzuré thé Flágz',
            'Chosen One':'Chzénz Ónez',
            'Conquest':'Cónquzézt',
            'Death Match':'Déátzh Mátczh',
            'Easter Egg Hunt':'Eogwiej owije ghuf',
            'Elimination':'Élímznizaín',
            'Football':'Fútbolz',
            'Hockey':'Hóckzy',
            'Keep Away':'Kéép Awáz',
            'King of the Hill':'Kíng óf thz Hílz',
            'Meteor Shower':'Mtrlrlr Shghglzrz',
            'Ninja Fight':'Njnff Fiffz',
            'Onslaught':'Ónsláughtz',
            'Race':'Ráze',
            'Runaround':'Rúnároundz',
            'Target Practice':'Tafo Prajcfz',
            'The Last Stand':'Thú Lzst Stándz'
        },
        'inputDeviceNames':{
            'Keyboard':'Kblflzfz',
            'Keyboard P2':'Kzboardz P2z'
        },
        'languages':{
            'Arabic':'Aroijwe',
            'Belarussian':'Blfrurzfozz',
            'Chinese':'Chzljesze',
            'Croatian':'Crrlzlrrs',
            'Czech':'Czffef',
            'Danish':'Dnishsdl',
            'Dutch':'Dtchjdflz',
            'English':'Englfjlzjsh',
            'Esperanto':'Esprorjjzlz',
            'Finnish':'Fnnizhsh',
            'French':'Frnzhfhn',
            'German':'Grmmzndn',
            'Gibberish':'Gibberish',
            'Greek':'Gaofwef',
            'Hindi':'Hfjofz',
            'Hungarian':'Hngjgozf',
            'Indonesian':'Inofiqdson',
            'Italian':'Itzllfjssnn',
            'Japanese':'Jpndjsjzes',
            'Korean':'Kornesnzn',
            'Persian':'Psdfsdf',
            'Polish':'Pzlishz',
            'Portuguese':'Portuguenejs',
            'Romanian':'Rmrfoijfzf',
            'Russian':'Rzznrsn',
            'Serbian':'Socowiejf',
            'Spanish':'Snsdnsh',
            'Swedish':'Swdiiszh',
            'Turkish':'Twfoijwef',
            'Ukrainian':'Ukckwef'
        },
        'leagueNames':{
            'Bronze':'Blfoijzf',
            'Diamond':'Dfoifffz',
            'Gold':'Glfdf',
            'Silver':'Slfjfozz'
        },
        'mapsNames':{
            'Big G':'Bíg Gz',
            'Bridgit':'Brídzgzt',
            'Courtyard':'Coúrtyárd',
            'Crag Castle':'Crág Cástlé',
            'Doom Shroom':'Dóóm Shróóm',
            'Football Stadium':'Fóózball Stédzm',
            'Happy Thoughts':'Háppy Thóúghts',
            'Hockey Stadium':'Hóckzy Stzéimz',
            'Lake Frigid':'Lk Frojfz',
            'Monkey Face':'Mónkey Fáce',
            'Rampage':'Rampágé',
            'Roundabout':'Róúndzboót',
            'Step Right Up':'Stép Reíghz Úp',
            'The Pad':'Thz Péd',
            'Tip Top':'Típ Tzp',
            'Tower D':'Tówér D',
            'Zigzag':'Zigzúzg'
        },
        'playlistNames':{
            'Just Epic':'Jst Pcpc',
            'Just Sports':'Jspsf Zprttz'
        },
        'promoCodeResponses':{
            'invalid promo code':'invlidf promoz cdfd'
        },
        'scoreNames':{
            'Flags':'Flágz',
            'Goals':'Góálz',
            'Score':'Sczórz',
            'Survived':'Súrvizvéd',
            'Time':'Tímé',
            'Time Held':'Tímz Hélz'
        },
        'serverResponses':{
            'A code has already been used on this account.':'A cfodfj hd cowefj aweof cwjeo fjweo fijw eofjwocij.',
            'A reward has already been given for that address.':'Ac wolf wo Code coi weojoifow e ocjw oiejfwer.',
            'Account linking successful!':'Accjo link succeosf!',
            'Account unlinking successful!':'Accjow cowejowejr sucefwewr!',
            'Accounts are already linked.':'Accojif co woie owjilkn.',
            'An error has occurred; (${ERROR})':'An cow fc woof wcef; (${ERROR})',
            'An error has occurred; please contact support. (${ERROR})':'An cowed c woefj wcoi woof weiojrwe rj goije ${ERROR})',
            'An error has occurred; please contact support@froemling.net.':'An f oco ao ocio wj ; pocj oco woei fsuupo co co ifoiwnet',
            'An error has occurred; please try again later.':'An cowjef win woes owe p apowejrowjers.',
            ('Are you sure you want to link these accounts?\n'
             '\n'
             '${ACCOUNT1}\n'
             '${ACCOUNT2}\n'
             '\n'
             'This cannot be undone!'):('Ac woef oi eowic woiej fowije foijcwe?\n'
                                        '\n'
                                        '${ACCOUNT1}\n'
                                        '${ACCOUNT2}\n'
                                        '\n'
                                        'THci weo woi efoiw ojo ij!!'),
            'BombSquad Pro unlocked!':'Boijfdfsjef pon occoijfs!',
            'Can\'t link 2 accounts of this type.':'Cnoj\' oi n aoco i ot oaifftz.',
            'Can\'t link 2 diamond league accounts.':'Cnoi\' oin koci o2 doi co fla cairjrs.',
            'Can\'t link; would surpass maximum of ${COUNT} linked accounts.':'Cn\'t coi oi; could up vo  io  ${COUNT} oi c ioicoicuors.',
            'Cheating detected; scores and prizes suspended for ${COUNT} days.':'Chowcj eof weoc jco; oe jwoeijf wojcwjeowfj woejf o${COUNT} dzf.',
            'Could not establish a secure connection.':'Cjfoi cn ooi a tac c oweocoicoinr.',
            'Daily maximum reached.':'Dfilaf mciwfjiwf rechced.',
            'Entering tournament...':'Ernwoefijweo jfowjefw...',
            'Invalid code.':'Invflijf cddz.',
            'Invalid payment; purchase canceled.':'Info ejcwpeopwer; purwup cowefjwef.',
            'Invalid promo code.':'Ivnfjfo pmpwf cdffz.',
            'Invalid purchase.':'Ivnifjf cnwerojf.',
            'Invalid tournament entry; score will be ignored.':'Invoc oic owe fo; co ot coi aingoired.',
            'Item unlocked!':'Iwerw cowefjwoeijwer!',
            ('LINKING DENIED. ${ACCOUNT} contains\n'
             'significant data that would ALL BE LOST.\n'
             'You can link in the opposite order if you\'d like\n'
             '(and lose THIS account\'s data instead)'):('LINKING FOFJWEF.  ${ACCOUNT} o iwjof\n'
                                                         'owe oijwe c woeoijwf oAL FJOEJI OCJW.\n'
                                                         'You off leojwoer wcowe foiwjefojweoiwf\n'
                                                         '(a c owfw oefjTHIS c weoojw oesf)'),
            ('Link account ${ACCOUNT} to this account?\n'
             'All existing data on ${ACCOUNT} will be lost.\n'
             'This can not be undone.  Are you sure?'):('Lcjwe fwofj o ${ACCOUNT} to cowejfweof?\n'
                                                        'All wefoiwejtthosjic w ${ACCOUNT} cowiejf tjsl.\n'
                                                        'This wefowondot onsof.  Aojr tyocu wsure?'),
            'Max number of playlists reached.':'Mx nfmow oijeplyalfaf rcnoahfd.',
            'Max number of profiles reached.':'Mc fjpasdofj c owiejfowe oiwjefsd.',
            'Maximum friend code rewards reached.':'Cmwoe oc wo Ego wel jacoweij weer.',
            'Profile "${NAME}" upgraded successfully.':'Profjojf "${NAME}" oupfuap coj woijsfsf.',
            'Profile could not be upgraded.':'Profojfo coild onot foj bupfrade.',
            'Purchase successful!':'Pcjofj scwcserfflz!',
            ('Received ${COUNT} tickets for signing in.\n'
             'Come back tomorrow to receive ${TOMORROW_COUNT}.'):('Rclfjoc ${COUNT} otjoa ojofj oweijf.\n'
                                                                  'Comcowef ocw weofjwefjowef ${TOMORROW_COUNT}.'),
            ('Server functionality is no longer supported in this version of the game;\n'
             'Please update to a newer version.'):('Sowejr cowj fwoe co wefj owe f c woefijw ego wejfoiwjejwfjoweiwfe;\n'
                                                   'Powijfw c wejfwoij oiwje wr erowijrowe.'),
            'Sorry, there are no uses remaining on this code.':'Srrryr, the war no cufowief rime woijwof con etude.',
            'Sorry, this code has already been used.':'Srrc, thiz codds has aoiwjre bndd usdd.',
            'Sorry, this code has expired.':'Sorrro, thi cowf ahs arowjers.',
            'Sorry, this code only works for new accounts.':'Srror, this cod ojfowf work for know accarrn.',
            'Temporarily unavailable; please try again later.':'Tmwoef wf oucwof wf; cowejf awoj cwoijers.',
            'The tournament ended before you finished.':'Thf weoijw oeij aoejf aowejf owjeof aiwjeofjwef.',
            'This account cannot be unlinked for ${NUM} days.':'Th ow co ref w owjoso o ${NUM} dyafsoef.',
            'This code cannot be used on the account that created it.':'Thiz codf cow oicna weoiw oaijwoefoa sdoausd cjoeri wod.',
            'This requires version ${VERSION} or newer.':'Thif efowjefo f${VERSION} or wofjweor.',
            'Tournaments disabled due to rooted device.':'Toiwfj woicw few doff our r woiwjeowods.',
            'Tournaments require ${VERSION} or newer':'Toijfw qojwce ${VERSION} or wcoiwej',
            ('Unlink ${ACCOUNT} from this account?\n'
             'All data on ${ACCOUNT} will be reset.\n'
             '(except for achievements in some cases)'):('Uncljwf ${ACCOUNT} cowed wthosijf?\n'
                                                         'All cowejt ocjiwf ${ACCOUNT} cowiest dois.\n'
                                                         '(expo fowefj etwohoa tand Costers)'),
            ('WARNING: complaints of hacking have been issued against your account.\n'
             'Accounts found to be hacking will be banned.  Please play fair.'):('WARNOEF: com owe fw epfojwe. cj weo fjwefo wejfo wef jocij eowiefwef.\n'
                                                                                 'Coaj owe fwefjwoo oweoifwoe fj ewrj woc. Ppel fwo c worywwr.'),
            ('Would you like to link your device account to this one?\n'
             '\n'
             'Your device account is ${ACCOUNT1}\n'
             'This account is ${ACCOUNT2}\n'
             '\n'
             'This will allow you to keep your existing progress.\n'
             'Warning: this cannot be undone!\n'):('Wocj weo ocj woiej fowj ofj aioj ojt;oi df joijwotijs?\n'
                                                   '\n'
                                                   'Yoc uweof c owej owijf  ${ACCOUNT1}\n'
                                                   'Thoci wef coj woeijf ${ACCOUNT2}\n'
                                                   '\n'
                                                   'Thoc jweo owej fow cwi efod odo focwoe.\n'
                                                   'Wocj fo : cwo c weof odo fauoino!'),
            'You already own this!':'Yz fwowefoi coiweno fjoz!',
            'You can join in ${COUNT} seconds.':'You won cowier fwoef ${COUNT} coiwejf.',
            'You don\'t have enough tickets for this!':'Yz dfoiwf ahv weoj fwoitjoicker fz thzz!',
            'You don\'t own that.':'You loci jeff jwoefwe.',
            'You got ${COUNT} tickets!':'Y zfowej f${COUNT{ ticeofjwe!',
            'You got a ${ITEM}!':'Yzz gtzz z ${ITEM}!',
            'You have been promoted to a new league; congratulations!':'Yf co efoj woef woecj owejfoiwef lfj ; congaroiwjf woes!',
            'You must update to a newer version of the app to do this.':'Yz mocu upc oig owc owt oc o ca; ;apc oi oj ;oj.',
            'You must update to the newest version of the game to do this.':'Yocwe fweoowo weotjosij;ow. woeower weroso taotoautats.',
            'You must wait a few seconds before entering a new code.':'Yzz msfgt wt a fz cwcfwf bfrrzz entef wcnfz cdszz.',
            'You ranked #${RANK} in the last tournament. Thanks for playing!':'Yz wf ooiwef #${RANK} ofijwe oijw oijef . Thansf afpaflalay!',
            ('Your copy of the game has been modified.\n'
             'Please revert any changes and try again.'):('Yr coijw epowf oief oaefoiwfowjef\n'
                                                          'Plejasefoaw efojw oefjwoejo aciowejrow.'),
            'Your friend code was used by ${ACCOUNT}':'Yrrj cof owf owcjowj fwoafeof ${ACCOUNT}'
        },
        'settingNames':{
            '1 Minute':'1 Mínuzz',
            '1 Second':'1 Scfmfz',
            '10 Minutes':'10 Mínuzz',
            '2 Minutes':'2 Mínuzz',
            '2 Seconds':'2 Sfljcjfsz',
            '20 Minutes':'20 Mínuzz',
            '4 Seconds':'4 Sfcljfdz',
            '5 Minutes':'5 Mínuzz',
            '8 Seconds':'8 Sfcljrjdz',
            'Allow Negative Scores':'Alllzz Nglfljcw Scorrzz',
            'Balance Total Lives':'Bálncz Tótzl Líves',
            'Bomb Spawning':'SOCj efoijw come',
            'Chosen One Gets Gloves':'Chózn One Gétz Glóvz',
            'Chosen One Gets Shield':'Chózn One Gétz Shíéld',
            'Chosen One Time':'Chzénz Ónz Tímz',
            'Enable Impact Bombs':'Enfojf Impac BombS',
            'Enable Triple Bombs':'Enafojf Tapowef Bobms',
            'Entire Team Must Finish':'Enfowief Tem Musc Fiifsf',
            'Epic Mode':'Épizc Módz',
            'Flag Idle Return Time':'Flág Ídle Rétúrn Tímz',
            'Flag Touch Return Time':'Flág Tzch Rétúrn Tímz',
            'Hold Time':'Hólz Tímz',
            'Kills to Win Per Player':'Kílls tó Wín Pér Plzáyer',
            'Laps':'Lápz',
            'Lives Per Player':'Lívz Pérz Pláyrr',
            'Long':'Lónggz',
            'Longer':'Lóngrzz',
            'Mine Spawning':'Míne Spáwning',
            'No Mines':'Nz Mfjfnzl',
            'None':'Núnz',
            'Normal':'Nórmzll',
            'Pro Mode':'Por Msdf',
            'Respawn Times':'Rézpnzz Tímzz',
            'Score to Win':'Scúrz té Wínz',
            'Short':'Shórtz',
            'Shorter':'Shórtzrr',
            'Solo Mode':'Sólzo Módz',
            'Target Count':'Tfof Coufnfz',
            'Time Limit':'Tímz Límtzz'
        },
        'statements':{
            '${TEAM} is disqualified because ${PLAYER} left':'${TEAM} oj who cos weoijwoeij c woes ${PLAYER} cjowef',
            'Killing ${NAME} for skipping part of the track!':'Kllzng ${NAME} fr ckpoing ocij epo jwof jat!',
            'Warning to ${NAME}:  turbo / button-spamming knocks you out.':'Wjocief cwf ${NAME}:  jojwo / ocjo efoiwefj wcoweok owerjoijdof.'
        },
        'teamNames':{
            'Bad Guys':'Bázd Gúyzs',
            'Blue':'Blzúe',
            'Good Guys':'Gzóod Gúys',
            'Red':'Réd'
        },
        'tips':{
            ('A perfectly timed running-jumping-spin-punch can kill in a single hit\n'
             'and earn you lifelong respect from your friends.'):('Á perfectly timed running-jumping-zpin-punch cán kill in á zingle hit\n'
                                                                  'ánd eárn yóu lifelóng rezpect fróm yóur friendz.'),
            'Always remember to floss.':'Álwáyz remember tó flózz.',
            ('Create player profiles for yourself and your friends with\n'
             'your preferred names and appearances instead of using random ones.'):('Creáte pláyer prófilez fór yóurzelf ánd yóur friendz with\n'
                                                                                    'yóur preferred námez ánd áppeáráncez inzteád óf uzing rándóm ónez.'),
            ('Curse boxes turn you into a ticking time bomb.\n'
             'The only cure is to quickly grab a health-pack.'):('Curze bóxez turn yóu intó á ticking time bómb.\n'
                                                                 'The ónly cure iz tó quickly gráb á heálth-páck.'),
            ('Despite their looks, all characters\' abilities are identical,\n'
             'so just pick whichever one you most closely resemble.'):('Dezpite their lóókz, áll chárácterz\' ábilitiez áre identicál,\n'
                                                                       'zó juzt pick whichever óne yóu mózt clózely rezemble.'),
            'Don\'t get too cocky with that energy shield; you can still get yourself thrown off a cliff.':'Dón\'t get tóó cócky with thát energy zhield; yóu cán ztill get yóurzelf thrówn óff á cliff.',
            'Don\'t run all the time.  Really.  You will fall off cliffs.':'Dón\'t run áll the time.  Reálly.  Yóu will fáll óff cliffz.',
            'Don\'t spin for too long; you\'ll become dizzy and fall.':'Dino pcoijw cow erowic ow; ocuwe fowei owie roan faf.',
            'Hold any button to run.  (Trigger buttons work well if you have them)':'Hóld ány buttón tó run.  (Trigger buttónz wórk well if yóu háve them)',
            ('Hold down any button to run. You\'ll get places faster\n'
             'but won\'t turn very well, so watch out for cliffs.'):('Hóld dówn ány buttón tó run. Yóu\'ll get plácez fázter\n'
                                                                     'but wón\'t turn very well, zó wátch óut fór cliffz.'),
            ('Ice bombs are not very powerful, but they freeze\n'
             'whoever they hit, leaving them vulnerable to shattering.'):('Ice bómbz áre nót very pówerful, but they freeze\n'
                                                                          'whóever they hit, leáving them vulneráble tó zháttering.'),
            ('If someone picks you up, punch them and they\'ll let go.\n'
             'This works in real life too.'):('If zómeóne pickz yóu up, punch them ánd they\'ll let gó.\n'
                                              'Thiz wórkz in reál life tóó.'),
            ('If you are short on controllers, install the \'${REMOTE_APP_NAME}\' app\n'
             'on your mobile devices to use them as controllers.'):('Iffz oc wo acoiw oifj woc ojef \'${REMOTE_APP_NAME}\' ars\n'
                                                                    'oc of code pow c owe fowjfoijweojc oocjwef.'),
            ('If you are short on controllers, install the \'BombSquad Remote\' app\n'
             'on your iOS or Android devices to use them as controllers.'):('If yóu áre zhórt ón cóntróllerz, inztáll the \'BómbZquád Remóte\' ápp\n'
                                                                            'ón yóur iÓZ ór Ándróid devicez tó uze them áz cóntróllerz.'),
            ('If you get a sticky-bomb stuck to you, jump around and spin in circles. You might\n'
             'shake the bomb off, or if nothing else your last moments will be entertaining.'):('If yóu get á zticky-bómb ztuck tó yóu, jump áróund ánd zpin in circlez. Yóu might\n'
                                                                                                'zháke the bómb óff, ór if nóthing elze yóur lázt mómentz will be entertáining.'),
            'If you kill an enemy in one hit you get double points for it.':'If yóu kill án enemy in óne hit yóu get dóuble póintz fór it.',
            ('If you pick up a curse, your only hope for survival is to\n'
             'find a health powerup in the next few seconds.'):('If yóu pick up á curze, yóur ónly hópe fór zurvivál iz tó\n'
                                                                'find á heálth pówerup in the next few zecóndz.'),
            'If you stay in one place, you\'re toast. Run and dodge to survive..':'If yóu ztáy in óne pláce, yóu\'re tóázt. Run ánd dódge tó zurvive..',
            ('If you\'ve got lots of players coming and going, turn on \'auto-kick-idle-players\'\n'
             'under settings in case anyone forgets to leave the game.'):('If yóu\'ve gót lótz óf pláyerz cóming ánd góing, turn ón \'áutó-kick-idle-pláyerz\'\n'
                                                                          'under zettingz in cáze ányóne fórgetz tó leáve the gáme.'),
            ('If your device gets too warm or you\'d like to conserve battery power,\n'
             'turn down "Visuals" or "Resolution" in Settings->Graphics'):('Iw fowj eoaj wecojaw ;eofja ;woefj ;aowiejoawjef;oajw;eofja; wef\n'
                                                                           'aoj etoaj ;cojwe;aoj ef;oawe; faw;oe fj;aow e;owjef;oajf'),
            ('If your framerate is choppy, try turning down resolution\n'
             'or visuals in the game\'s graphics settings.'):('If yóur frámeráte iz chóppy, try turning dówn rezólutión\n'
                                                              'ór vizuálz in the gáme\'z gráphicz zettingz.'),
            ('In Capture-the-Flag, your own flag must be at your base to score, If the other\n'
             'team is about to score, stealing their flag can be a good way to stop them.'):('In Cápture-the-Flág, yóur ówn flág muzt be át yóur báze tó zcóre, If the óther\n'
                                                                                             'teám iz ábóut tó zcóre, zteáling their flág cán be á góód wáy tó ztóp them.'),
            'In hockey, you\'ll maintain more speed if you turn gradually.':'In hóckey, yóu\'ll máintáin móre zpeed if yóu turn gráduálly.',
            'It\'s easier to win with a friend or two helping.':'It\'z eázier tó win with á friend ór twó helping.',
            'Jump just as you\'re throwing to get bombs up to the highest levels.':'Jump juzt áz yóu\'re thrówing tó get bómbz up tó the highezt levelz.',
            'Land-mines are a good way to stop speedy enemies.':'Lánd-múnes áré z gúod wáy tó stóp spéédy enémíes.',
            ('Many things can be picked up and thrown, including other players.  Tossing\n'
             'your enemies off cliffs can be an effective and emotionally fulfilling strategy.'):('Mány thingz cán be picked up ánd thrówn, including óther pláyerz.  Tózzing\n'
                                                                                                  'yóur enemiez óff cliffz cán be án effective ánd emótiónálly fulfilling ztrátegy.'),
            'No, you can\'t get up on the ledge. You have to throw bombs.':'Nó, yóu cán\'t get up ón the ledge. Yóu háve tó thrów bómbz.',
            ('Players can join and leave in the middle of most games,\n'
             'and you can also plug and unplug controllers on the fly.'):('Plref can join and flasdj afl ion the mdc aosdfoasdf,\n'
                                                                          'aodf sdoyuou can aodfj asdfpluf asdna moasdfp sdfocnor.'),
            ('Players can join and leave in the middle of most games,\n'
             'and you can also plug and unplug gamepads on the fly.'):('Pláyerz cán jóin ánd leáve in the middle óf mózt gámez,\n'
                                                                       'ánd yóu cán álzó plug ánd unplug gámepádz ón the fly.'),
            ('Powerups only have time limits in co-op games.\n'
             'In teams and free-for-all they\'re yours until you die.'):('Pówerupz ónly háve time limitz in có-óp gámez.\n'
                                                                         'In teámz ánd free-fór-áll they\'re yóurz until yóu die.'),
            'Practice using your momentum to throw bombs more accurately.':'Práctice uzing yóur mómentum tó thrów bómbz móre áccurátely.',
            ('Punches do more damage the faster your fists are moving,\n'
             'so try running, jumping, and spinning like crazy.'):('Punchez dó móre dámáge the fázter yóur fiztz áre móving,\n'
                                                                   'zó try running, jumping, ánd zpinning like crázy.'),
            ('Run back and forth before throwing a bomb\n'
             'to \'whiplash\' it and throw it farther.'):('Run báck ánd fórth befóre thrówing á bómb\n'
                                                          'tó \'whiplázh\' it ánd thrów it fárther.'),
            ('Take out a group of enemies by\n'
             'setting off a bomb near a TNT box.'):('Táke óut á gróup óf enemiez by\n'
                                                    'zetting óff á bómb neár á TNT bóx.'),
            ('The head is the most vulnerable area, so a sticky-bomb\n'
             'to the noggin usually means game-over.'):('The heád iz the mózt vulneráble áreá, zó á zticky-bómb\n'
                                                        'tó the nóggin uzuálly meánz gáme-óver.'),
            ('This level never ends, but a high score here\n'
             'will earn you eternal respect throughout the world.'):('Thiz level never endz, but á high zcóre here\n'
                                                                     'will eárn yóu eternál rezpect thróughóut the wórld.'),
            ('Throw strength is based on the direction you are holding.\n'
             'To toss something gently in front of you, don\'t hold any direction.'):('Thrów ztrength iz bázed ón the directión yóu áre hólding.\n'
                                                                                      'Tó tózz zómething gently in frónt óf yóu, dón\'t hóld ány directión.'),
            ('Tired of the soundtrack?  Replace it with your own!\n'
             'See Settings->Audio->Soundtrack'):('Trrd fo toasdoasdfm? Ararap cale fasoif;osda!\n'
                                                 'Se sdfoajs dof cjspdof apsodi paosdjf'),
            'Try \'Cooking off\' bombs for a second or two before throwing them.':'Try \'Cóóking óff\' bómbz fór á zecónd ór twó befóre thrówing them.',
            'Try tricking enemies into killing eachother or running off cliffs.':'Try tricking enemiez intó killing eáchóther ór running óff cliffz.',
            'Use the pick-up button to grab the flag < ${PICKUP} >':'Uze the pick-up buttón tó gráb the flág < ${PICKUP} >',
            'Whip back and forth to get more distance on your throws..':'Whip báck ánd fórth tó get móre diztánce ón yóur thrówz..',
            ('You can \'aim\' your punches by spinning left or right.\n'
             'This is useful for knocking bad guys off edges or scoring in hockey.'):('Yóu cán \'áim\' yóur punchez by zpinning left ór right.\n'
                                                                                      'Thiz iz uzeful fór knócking bád guyz óff edgez ór zcóring in hóckey.'),
            ('You can judge when a bomb is going to explode based on the\n'
             'color of sparks from its fuse:  yellow..orange..red..BOOM.'):('Yóu cán judge when á bómb iz góing tó explóde bázed ón the\n'
                                                                            'cólór óf zpárkz fróm itz fuze:  yellów..óránge..red..BÓÓM.'),
            'You can throw bombs higher if you jump just before throwing.':'Yóu cán thrów bómbz higher if yóu jump juzt befóre thrówing.',
            ('You don\'t need to edit your profile to change characters; Just press the top\n'
             'button (pick-up) when joining a game to override your default.'):('Yóu dón\'t need tó edit yóur prófile tó chánge chárácterz; Juzt prezz the tóp\n'
                                                                                'buttón (pick-up) when jóining á gáme tó óverride yóur defáult.'),
            ('You take damage when you whack your head on things,\n'
             'so try to not whack your head on things.'):('Yóu táke dámáge when yóu wháck yóur heád ón thingz,\n'
                                                          'zó try tó nót wháck yóur heád ón thingz.'),
            'Your punches do much more damage if you are running or spinning.':'Yóur punchez dó much móre dámáge if yóu áre running ór zpinning.'
        }
    },
    'trialPeriodEndedText':('Yozr tríal púrizd hás úndzd. Wóuld yóu lúke\n'
                            'tz pórchúse BómbSquád ánd kéép plzying?'),
    'trophiesRequiredText':'This cow fwoeif of ${NUMBER} cowejfwe',
    'trophiesText':'Tjfpojfz',
    'trophiesThisSeasonText':'Trphpc Thzi Ssrcon',
    'tutorial':{
        'cpuBenchmarkText':'Rnnging tuoriral fan lurkdc-spdd (primirarl ytest CPU spd)',
        'phrase01Text':'Hz Thrzfl!',
        'phrase02Text':'Wlgjlmcz tz ${APP_NAME}!',
        'phrase03Text':'Hrllz a fjflf tijpefa fjor conotrlaij yoru chchrirzzzr:',
        'phrase04Text':'Mntn thngo foin boia${APP_NAME}foibajsfdo aoh PCHYRALZ bajffz.',
        'phrase05Text':'Frjo exnapfdnp, whfz ynz pnpchru...',
        'phrase06Text':'..dmglaf iz bzfz onf zpdfz ofz yrz fzfassz.',
        'phrase07Text':'Szz.?  Wz wrjogz mvojgsfz so that barelzl hurt ${NAME}.',
        'phrase08Text':'Nwz ltzf jmpz n spnz tz gtz mrz spdfrz.',
        'phrase09Text':'Ahz thzjo\'s b;rtjz.',
        'phrase10Text':'Rngjgojz hpzpoijr too.',
        'phrase11Text':'Hzljt fjofj ANZ butlzf tz rnzrlz.',
        'phrase12Text':'Frz txpro-apwez pnpghch, trz rnognp ANZ pafong;z.',
        'phrase13Text':'Whppz; srryz \'bout that ${NAME}.',
        'phrase14Text':'Yz cnz pick ups nz trhowz thgfz szhc az flglafz.. or ${NAME}.',
        'phrase15Text':'Lasfzjtoz, thzfzo bmjgz.',
        'phrase16Text':'Throwzlf bmgzz tkzgfz prcgjtoz.',
        'phrase17Text':'Oucz! Nzt a vrz gdz thrworz.',
        'phrase18Text':'Mvngofj hpzrz yz throwz fratherz.',
        'phrase19Text':'Jmpngpg hpz yz thorwz highrzr.',
        'phrase20Text':'"whoppers" yrs bomgjl for enve longer thowawrz.',
        'phrase21Text':'Tmingo yr bombos cnz bs trixkrz.',
        'phrase22Text':'Dngz.',
        'phrase23Text':'Try "ckkzllj off" thz fuze frs a scrnd orz stwoz.',
        'phrase24Text':'Hrrzrlar! Nirlefzl cokkred.',
        'phrase25Text':'Wllz, thrat\'s jztst borts itz.',
        'phrase26Text':'Nowz gz get\'z em tzgrrs!',
        'phrase27Text':'Rembjgeorz yrz trnings, andz yz WLLZ cmd bazk alvss!',
        'phrase28Text':'..wllz.mbbfyz..',
        'phrase29Text':'Gddz lkxks!',
        'randomName1Text':'Fréz',
        'randomName2Text':'Hurrzl',
        'randomName3Text':'Bllfz',
        'randomName4Text':'Chrjrzl',
        'randomName5Text':'Phllz',
        'skipConfirmText':'Rlldf asdf oajc sdjf asodf asdf? dfj oasidj foasdc.',
        'skipVoteCountText':'${COUNT}/${TOTAL} skpzj vnttjzlz',
        'skippingText':'skpzjflj toutoroafjz...',
        'toSkipPressAnythingText':'(tpz rz pzrzl anthfljzf tz skpfz tuzfjrlrrz)'
    },
    'twoKillText':'DÓÚBLZ KÍLL!',
    'unavailableText':'unavlfldsfjlbz',
    'unconfiguredControllerDetectedText':'Uncónfzgúred cúntrzllír dítzctíd:',
    'unlockThisInTheStoreText':'Thz mf voi eunlcoef owef joiefsfrwe.',
    'unlockThisProfilesText':'To cowier co we ${NUM} pcoer, cow oicoj:',
    'unlockThisText':'Tz ncowifj ocje, ycon fneeds:',
    'unsupportedHardwareText':'Srrz, thz hardwrz isz nt spprted bz thz vejerelr dlzl gmpzz.',
    'upFirstText':'Uzp férzt:',
    'upNextText':'Úp nézt ín gámz ${COUNT}:',
    'updatingAccountText':'Updfoifjz yrrl cacmrmr...',
    'upgradeText':'Upgrorz',
    'upgradeToPlayText':'Upgglf tz "${PRO}" iz j wojcwoef paljf zs.',
    'useDefaultText':'Uzl Dflfjtzlz',
    'usesExternalControllerText':'Thz gjf coiwjef oif owicoiwefj owejf owejoojof',
    'usingItunesText':'Uszngl iTunzf frz sndnftzkz...',
    'usingItunesTurnRepeatAndShuffleOnText':'Plzelz mkdk srzlc shfflds isON anz andpreld is ALZ unz iTunes',
    'validatingBetaText':'Válúdztíng Bztá...',
    'validatingTestBuildText':'Vldfjdfoi jtese-bsdfasfd...',
    'victoryText':'Vúctzry!',
    'voteDelayText':'You caecowe oefo wocj woeiwo ${NUMBER} wocijwoef.',
    'voteInProgressText':'A voiajf coiwje fwooeio wcwer.',
    'votedAlreadyText':'C who foil owejrs',
    'votesNeededText':'${NUMBER} vowjeowi jw oefwe',
    'vsText':'vús.',
    'waitingForHostText':'(twatijf  ffarz ${HOST} to cnfojoweifz)',
    'waitingForLocalPlayersText':'wzzéatnng fér lzcal pzéayers...',
    'waitingForPlayersText':'wtnginag frz plers to jnnz..',
    'waitingInLineText':'Wowcij cowije fo wf(powc owe oweir)...',
    'watchAVideoText':'Few A covjowdf',
    'watchAnAdText':'e aowej ocjowef',
    'watchWindow':{
        'deleteConfirmText':'Delzdfe "${REPLAY}"?',
        'deleteReplayButtonText':('Dlrlrjz\n'
                                  'Rplrlz'),
        'myReplaysText':'Mz Rplgllz',
        'noReplaySelectedErrorText':'Nz Rplglz Slelectdz',
        'playbackSpeedText':'Plwecowi jef SPcowef ${SPEED}',
        'renameReplayButtonText':('Rnrmz\n'
                                  'Rplrlrz'),
        'renameReplayText':'Rnmgm "${REPLAY}" tz:',
        'renameText':'Rnzmz',
        'replayDeleteErrorText':'Errlz dlernlg rmllzlz',
        'replayNameText':'Rpprlz Nmz',
        'replayRenameErrorAlreadyExistsText':'A rnofk wug h af c adfkahf wcuiuhz,',
        'replayRenameErrorInvalidName':'Can\'f co fojo sf oiejc n vailid anme.',
        'replayRenameErrorText':'Errz rnemvifj rpcojz.',
        'sharedReplaysText':'Srhrrm Rplclrlz.',
        'titleText':'Wtcchs',
        'watchReplayButtonText':('Wtchf\n'
                                 'Rplzz')
    },
    'waveText':'Wávz',
    'wellSureText':'Wélz Súre!',
    'wiimoteLicenseWindow':{
        'licenseText':('Copyríght (c) 2007, DarwíínRúmotú Túam\n'
                       'All ríghtz rúzúrvúd.\n'
                       '\n'
                       '   Rúdíztríbutíon and uzú ín zourcú and bínary formz, wíth or wíthout modífícatíon,\n'
                       '   arú púrmíttúd provídúd that thú followíng condítíonz arú mút:\n'
                       '\n'
                       '1. Rúdíztríbutíonz of zourcú codú muzt rútaín thú abovú copyríght notícú, thíz\n'
                       '     lízt of condítíonz and thú followíng dízclaímúr.\n'
                       '2. Rúdíztríbutíonz ín bínary form muzt rúproducú thú abovú copyríght notícú, thíz\n'
                       '     lízt of condítíonz and thú followíng dízclaímúr ín thú documúntatíon and/or othúr\n'
                       '     matúríalz provídúd wíth thú díztríbutíon.\n'
                       '3. Núíthúr thú namú of thíz projúct nor thú namúz of ítz contríbutorz may bú uzúd to\n'
                       '     úndorzú or promotú productz dúrívúd from thíz zoftwarú wíthout zpúcífíc príor\n'
                       '     wríttún púrmízzíon.\n'
                       '\n'
                       'THÍZ ZOFTWARÚ ÍZ PROVÍDÚD BY THÚ COPYRÍGHT HOLDÚRZ AND CONTRÍBUTORZ "AZ ÍZ"\n'
                       'AND ANY ÚXPRÚZZ OR ÍMPLÍÚD WARRANTÍÚZ, ÍNCLUDÍNG, BUT NOT LÍMÍTÚD TO, THÚ\n'
                       'ÍMPLÍÚD WARRANTÍÚZ OF MÚRCHANTABÍLÍTY AND FÍTNÚZZ FOR A PARTÍCULAR PURPOZÚ\n'
                       'ARÚ DÍZCLAÍMÚD. ÍN NO ÚVÚNT ZHALL THÚ COPYRÍGHT OWNÚR OR CONTRÍBUTORZ BÚ\n'
                       'LÍABLÚ FOR ANY DÍRÚCT, ÍNDÍRÚCT, ÍNCÍDÚNTAL, ZPÚCÍAL, ÚXÚMPLARY, OR\n'
                       'CONZÚQUÚNTÍAL DAMAGÚZ (ÍNCLUDÍNG, BUT NOT LÍMÍTÚD TO, PROCURÚMÚNT OF\n'
                       ' ZUBZTÍTUTÚ GOODZ OR ZÚRVÍCÚZ; LOZZ OF UZÚ, DATA, OR PROFÍTZ; OR BUZÍNÚZZ\n'
                       'ÍNTÚRRUPTÍON) HOWÚVÚR CAUZÚD AND ON ANY THÚORY OF LÍABÍLÍTY, WHÚTHÚR ÍN\n'
                       'CONTRACT, ZTRÍCT LÍABÍLÍTY, OR TORT (ÍNCLUDÍNG NÚGLÍGÚNCÚ OR OTHÚRWÍZÚ)\n'
                       'ARÍZÍNG ÍN ANY WAY OUT OF THÚ UZÚ OF THÍZ ZOFTWARÚ, ÚVÚN ÍF ADVÍZÚD OF THÚ\n'
                       'POZZÍBÍLÍTY OF ZUCH DAMAGÚ.\n'),
        'licenseTextScale':0.62,
        'titleText':'DarwiónReéoze Czpyrúght'
    },
    'wiimoteListenWindow':{
        'listeningText':'Líszéngng Fúr Wíímztes...',
        'pressText':'Prész Wíimzte bóttzns 1 azd 2 símultáneoúsly.',
        'pressText2':'Onz néwer Wiímótes wíth Moóión Plús búilt ón, przss thé réd \'sync\' búttón ón thé bzck ónstzad.',
        'pressText2Scale':0.55,
        'pressTextScale':1.0
    },
    'wiimoteSetupWindow':{
        'copyrightText':'DúrwéinRemzote Cúpyrzght',
        'copyrightTextScale':0.6,
        'listenText':'Lústzn',
        'macInstructionsText':('Makú zurú your Wáá áz off and Bluútooth áz únablúd\n'
                               'on your Mac, thún prúzz \'Láztún\'. Wáámotú zupport can\n'
                               'bú a bát flaky, zo you may havú to try a fúw támúz\n'
                               'búforú you gút a connúctáon.\n'
                               '\n'
                               'Bluútooth zhould handlú up to 7 connúctúd dúvácúz,\n'
                               'though your málúagú may vary.\n'
                               '\n'
                               'BombZquad zupportz thú orágánal Wáámotúz, Nunchukz,\n'
                               'and thú Clazzác Controllúr.\n'
                               'Thú núwúr Wáá Rúmotú Pluz now workz too\n'
                               'but not wáth attachmúntz.'),
        'macInstructionsTextScale':0.7,
        'thanksText':('Thznks té thz DérwiinRémote táam\n'
                      'Fúr máking thés pzsséble.'),
        'thanksTextScale':0.8,
        'titleText':'Wzimóte Sztúp'
    },
    'winsPlayerText':'${NAME} Wnzpl!',
    'winsPluralText':'${NAME} WznflPP!',
    'winsSingularText':'${NAME} WinzfjlzSS!',
    'winsTeamText':'${NAME} Wnttm!',
    'winsText':'${NAME} Wínsz!',
    'worldScoresUnavailableText':'Wrlzld scrzzl unvlfldsjbzl.',
    'worldsBestScoresText':'Wúrld\'s Bést Scórzs',
    'worldsBestTimesText':'Wúrld\'s Bzst Tímés',
    'xbox360ControllersWindow':{
        'getDriverText':'Gét Drúvzr',
        'macInstructions2Text':('Tá uzá cántrállárz wirálázzly, yáu\'ll alzá náád thá rácáivár that\n'
                                'cámáz with thá \'Xbáx 360 Wirálázz Cántrállár fár Windáwz\'.\n'
                                'Áná rácáivár alláwz yáu tá cánnáct up tá 4 cántrállárz.\n'
                                '\n'
                                'Impártant: 3rd-party rácáivárz will nát wárk with thiz drivár;\n'
                                'maká zurá yáur rácáivár zayz \'Micrázáft\' án it, nát \'XBÁX 360\'.\n'
                                'Micrázáft ná lángár zállz tházá záparatály, zá yáu\'ll náád tá gát\n'
                                'thá áná bundlád with thá cántrállár ár álzá záarch ábay.\n'
                                '\n'
                                'If yáu find thiz uzáful, pláazá cánzidár a dánatián tá thá\n'
                                'drivár dáválápár at hiz zitá.'),
        'macInstructions2TextScale':0.76,
        'macInstructionsText':('Tó uzá Xbóx 360 cóntróllárz, yóu\'ll náád tó inztall\n'
                               'thá Mac drivár availablá at thá link bálów.\n'
                               'It wórkz with bóth wirád and wirálázz cóntróllárz..'),
        'macInstructionsTextScale':0.8,
        'ouyaInstructionsText':('Tz úze wéred Xbzx 360 czntrzllerz wéth yzúr ZÚYA, zémply\n'
                                'plúg them én the ZÚYA\'z ÚZB pzrt.  Yzú can úze a ÚZB húb\n'
                                'tz cznnect múltéple czntrzllerz.\n'
                                '\n'
                                'Tz úze wérelezz czntrzllerz yzú\'ll need a wérelezz receéver,\n'
                                'avaélable az part zf the "Xbzx 360 wérelezz Czntrzller fzr Wéndzwz"\n'
                                'package zr zzld zeparately. Each receéver plúgz éntz a ÚZB pzrt and\n'
                                'allzwz yzú tz cznnect úp tz 4 wérelezz czntrzllerz..'),
        'ouyaInstructionsTextScale':0.8,
        'titleText':'Uzíng Xbóx 360 Cónztróllzrs wzth ${APP_NAME}:'
    },
    'yesAllowText':'Yús, Allúwz!',
    'yourBestScoresText':'Yózr Bést Scúrzszz',
    'yourBestTimesText':'Yózr Bést Tímés'
}
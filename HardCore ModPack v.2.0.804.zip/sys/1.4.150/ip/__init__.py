try:
    unicode
except NameError:
    def _is_unicode(x):
        return 0
else:
    def _is_unicode(x):
        return isinstance(x, unicode)

def toBytes(url):
    """toBytes(u"URL") --> 'URL'."""
    # Most URL schemes require ASCII. If that changes, the conversion
    # can be relaxed
    if _is_unicode(url):
        try:
            url = url.encode("ASCII")
        except UnicodeError:
            raise UnicodeError("URL contains non-ASCII characters")
    return url

try: from urllib import URLopener
except Exception: Opener = None
else:
    from urllib import *
    import socket
    class Opener(URLopener):
        def open(self, fullurl, data=None):
            fullurl = unwrap(toBytes(fullurl))
            fullurl = quote(fullurl, safe="%/:=&?~#+!$,;'@()*[]|")
            if self.tempcache and fullurl in self.tempcache:
                filename, headers = self.tempcache[fullurl]
                fp = open(filename, 'rb')
                return addinfourl(fp, headers, fullurl)
            urltype, url = splittype(fullurl)
            urltype = 'http'
            proxy = None
            name = 'open_' + urltype
            self.type = urltype
            name = name.replace('-', '_')
            #print(name)
            #print(url)
            try:
                return getattr(self, "open_http")(url)
            except socket.error, msg:
                raise IOError, ('socket error', msg), sys.exc_info()[2]
    import urllib
    urllib._urlopener = Opener()
    
local = None
static = None

def get_local_ip_address():
    global local
    import socket
    s = socket.socket(2, 2)
    s.settimeout(1.0)
    try: s.connect(("8.8.8.8", 80))
    except Exception: return 'localhost:8888'
    else:
        local = ip = s.getsockname()[0]
        s.close()
        return ip
    
def get_static_ip_address():
    global static
    import urllib
    try: s = urllib.urlopen("https://api.ipify.org")
    except Exception as E: 
        print(str(E))
        return '<no connection>'
    else:
        static = ip = s.readline()
        s.close()
        return ip

local, static = get_local_ip_address(), get_static_ip_address()
if local is not None: print("Local IP-Address: "+local)
if static is not None: print("Static IP-Address: "+static)
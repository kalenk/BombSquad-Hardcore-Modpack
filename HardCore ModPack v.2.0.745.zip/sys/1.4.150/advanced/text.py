def format_spaces(msg):
    if "  " in msg: return format_spaces(msg=msg.replace("  ", " "))
    elif msg.endswith(" "): return format_spaces(msg=msg[0:-1])
    elif msg.startswith(" "): return msg[1:]
    else: return msg

def word_equals(word="", exists_word="", max_mist=2):
    result=0
    if len(word) in range(len(exists_word) - 2, len(exists_word) + 2):
        for b in [word, exists_word]:
            for i in range(len(b)):
                if b == word: c=exists_word
                else: c=word
                if len(c) > i:
                    if b[i] == c[i]: result+=1
    if result >= (len(exists_word)+len(word))-max_mist*2: return True
    return False
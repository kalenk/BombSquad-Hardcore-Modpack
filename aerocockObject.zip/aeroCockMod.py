# -*- coding: utf-8 -*-
import bs
import shutil, os
import bsInternal
import random

version = 12

#writed by drov.drov

env = bs.getEnvironment()
gAndroid = env['platform'] == 'android'
gPath = 'data' if not gAndroid else '/data/data/net.froemling.bombsquad/files/bombsquad_files/data'

name = 'AeroCock'
working_path = os.path.join(env['userScriptsDirectory'], 'AeroCock')
data_path = os.path.join(gPath, 'aeroCockMod.data')
file_types = {'.ktx' if gAndroid else '.dds': 'textures', '.bob': 'models', '.ogg': 'audio', '.cob': 'models'}

translates = {
    "Russian": {
        "installStartedText": "Установка объекта \"{}\"",
        "copyingText": "Копирование файла {}",
        "installCompleteText": "Установка завершена!"},
    "English": {
        "installStartedText": "Installing object \"{}\"",
        "copyingText": "Copying file {}",
        "installCompleteText": "Install complete!"}
    }

time_skip = 200 # time rate while copying 
translates = translates.get(bs.getLanguage(), translates.get("English", {}))

def run(call=None):
    a = bsInternal._getForegroundHostActivity()
    if call is None: call = lambda x : True
    if a is not None: bs.realTimer(time_skip, bs.Call(call))
    else: bs.realTimer(time_skip, bs.Call(run, call))

def install():
    v = 0
    if os.path.exists(data_path): 
        with open(data_path, 'r') as f:
            v = f.read()
            f.close()
        try: v = int(v.replace('.', ''))
        except ValueError: v = 0
    if v < version: copyfiles()
    else: on_end()

def copyfiles():
    bs.screenMessage(translates.get("installStartedText", "installing object \"{}\"").format(name), color=(1,0.85,0))
    def copy(dst, src):
        filename = dst.split(os.path.sep)[-1]
        filepath = os.path.join(src, filename)
        if os.path.exists(filepath): os.remove(filepath)
        bs.screenMessage(translates.get("copyingText", "copying... {}").format(filename), color=(1, 1, 0))
        try: shutil.copy(dst, src)
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
    if os.path.exists(working_path) and os.path.isdir(working_path):
        try:
            files = os.listdir(working_path)
            for i in range(len(files)):
                file = os.path.join(working_path, files[i])
                type = None
                for c in file_types: 
                    if file.endswith(c): 
                        type = file_types[c]
                        break
                if type is not None and os.path.isfile(file): bs.realTimer(time_skip * i + time_skip, bs.Call(copy, file, os.path.join(gPath, type)))
        except Exception as E: bs.screenMessage(str(E), color=(1,0,0))
        else:
            with open(data_path, 'w+') as f:
                f.write(str(version))
                f.close()
            def end():
                on_end()
                bs.screenMessage(translates.get("installCompleteText", "install complete!").format(name), color=(1,0.85,0))
            bs.realTimer(time_skip * len(files) + time_skip * 2, bs.Call(end))
    else: bs.screenMessage("Can not find path: "+str(working_path), color=(1,0,0))


def on_end():
    class AeroCockFactory(object):
        def __init__(self):
            f = bs.Bomb.getFactory()
            p = bs.Powerup.getFactory()
            self.bombMaterial = f.bombMaterial
            self.sound = bs.getSound('AeroCockWorksSound')
            self.tex = bs.getTexture('AeroCockColor')
            self.burnTex = bs.getTexture('AeroCockColorBurn')
            self.modelUp = bs.getModel('AeroCockUp')
            self.modelDown = bs.getModel('AeroCockDown')
            self.model = bs.getModel('AeroCock')
            self.powerupTex = bs.getTexture('AeroCockIcon')
            self.powerupModel = p.model
            self.powerupModelSimple = p.modelSimple
            self.powerupMaterial = p.powerupMaterial
            del f, p
    class AeroCock(bs.Bomb):
        def __init__(self, position=(0,1,0), velocity=(0,0,0), owner=None):
            bs.Actor.__init__(self)
    
            self.factory = factory = self.getFactory()
            self.bombType = 'aeroCock'
            self._exploded = False
            self._shattered = False
            self.blastRadius = 8
            self._explodeCallbacks = []
            self.sourcePlayer = None
            self.hitType = 'explosion'
            self.hitSubType = self.bombType
            if owner is None: owner = bs.Node(None)
            self.owner = owner
            self.m = materials = (factory.bombMaterial,
                bs.getSharedObject('footingMaterial'),
                bs.getSharedObject('objectMaterial'))
            self.node = bs.newNode('prop', delegate=self, attrs={
                'position': position,
                'velocity': velocity,
                'model': factory.model,
                'lightModel': factory.model,
                'body':'crate',
                'bodyScale': 1,
                'density': 1.2,
                'shadowSize': 0.5,
                'colorTexture': factory.tex,
                'reflection': 'soft',
                'reflectionScale': [0.23],
                'materials': materials})
            sound = bs.newNode('sound', owner=self.node, attrs={'sound': factory.sound,'volume': 0})
            self.node.connectAttr('position', sound, 'position')
            def emit():
                if not self.node.exists(): return
                bs.animate(sound, "volume", {0:0, 100: 1, 500: 1, 650:0})
                bs.emitBGDynamics(position=self.node.position, 
                    velocity=(0, 1.5, 0), chunkType='spark', 
                    count=30+random.randint(0,10), spread=0.10)
                bs.emitBGDynamics(position=self.node.position, 
                    velocity=(0, 0, 0), emitType='tendrils', 
                    tendrilType='ice',
                    count=10, spread=10)
                bs.gameTimer(100*random.randint(10, 15), bs.Call(emit))
            bs.animate(self.node, "modelScale", {0:0, 200:1.3, 260:1})
            bs.gameTimer(1260, bs.Call(emit))
            
        @classmethod
        def getFactory(cls):
            activity = bs.getActivity()
            try: return activity._sharedAeroCockFactory
            except Exception:
                f = activity._sharedAeroCockFactory = AeroCockFactory()
                return f
        def _handleDie(self, m):
            t = self.node.position if self.node is not None and self.node.exists() else None
            bs.Bomb._handleDie(self, m=m)
            if t is not None and not self._shattered:
                self._shattered = True
                for type in ["nodeUp", "nodeDown"]:
                    node = bs.newNode('prop', delegate=self, attrs={
                        'position': t,
                        'velocity': (0, 0, 0),
                        'model': None,
                        'modelScale': 1.0,
                        'lightModel': None,
                        'body':'crate',
                        'bodyScale': 0.85,
                        'shadowSize': 0.5,
                        'colorTexture': None,
                        'reflection': 'soft',
                        'reflectionScale': [0.23],
                        'materials': self.m})
                    node.model = node.lightModel = self.factory.modelUp if type == 'nodeUp' else self.factory.modelDown
                    pos = (t[0], t[1]+random.uniform(0, 1), t[2])
                    node.position = pos
                    node.colorTexture = self.factory.burnTex
                    node.handleMessage("impulse", pos[0]-random.randint(-3,3), pos[1]+random.randint(-4, -2), pos[2]-random.randint(-3,3), 0, 0, 0, random.randint(10, 25)*100, 0, 200.0, 1, random.randint(-1,1)*100, 100, random.randint(-1,1)*100)
                    bs.gameTimer(10000, node.delete)
                    bs.animate(node, 'modelScale', {0: 1.0, 9000: 1.0, 10000: 0.0})

    import bsPowerup
    from bsPowerup import defaultPowerupInterval
    PowerupOld = bsPowerup.Powerup
    class Powerup(PowerupOld):
        def __init__(self,position=(0,1,0), powerupType='tripleBombs', expire=True):
            if powerupType == 'aeroCock':
                bs.Actor.__init__(self)
                factory = AeroCock.getFactory()
                self.powerupType = powerupType
                self._powersGiven = False
                refScale = [0.95]
                ref = 'powerup'
                self.node = bs.newNode('prop',
                    delegate=self,
                    attrs={'body': 'box',
                        'position': position,
                        'model': factory.powerupModel,
                        'lightModel': factory.powerupModelSimple,
                        'shadowSize': 0.48,
                        'colorTexture': factory.powerupTex,
                        'reflection': 'powerup',
                        'reflectionScale': [0.95],
                        'materials': (factory.powerupMaterial, bs.getSharedObject('objectMaterial'))})
                curve = bs.animate(self.node,"modelScale",{0:0,140:1.6,200:1})
                bs.gameTimer(200, curve.delete)
        
                if expire:
                    bs.gameTimer(defaultPowerupInterval-2500, bs.WeakCall(self._startFlashing))
                    bs.gameTimer(defaultPowerupInterval-1000, bs.WeakCall(self.handleMessage, bs.DieMessage()))
            else: PowerupOld.__init__(self, position=position, powerupType=powerupType, expire=expire)
    bs.Powerup = bsPowerup.Powerup = Powerup
    rndType = bsPowerup.PowerupFactory.getRandomPowerupType
    def getRandomPowerupType(self,forceType=None,excludeTypes=[]):
        """
        Returns a random powerup type (string).
        See bs.Powerup.powerupType for available type values.

        There are certain non-random aspects to this; a 'curse' powerup,
        for instance, is always followed by a 'health' powerup (to keep things
        interesting). Passing 'forceType' forces a given returned type while
        still properly interacting with the non-random aspects of the system
        (ie: forcing a 'curse' powerup will result
        in the next powerup being health).
        """
        t = None
        if 'aeroCock' not in self._powerupDist:
            for i in range(2): self._powerupDist.append('aeroCock')
        return rndType(self, forceType=forceType, excludeTypes=excludeTypes)
    bsPowerup.PowerupFactory.getRandomPowerupType = getRandomPowerupType

    import bsSpaz
    handleMessageOld = bsSpaz.Spaz.handleMessage
    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if isinstance(msg, bs.PowerupMessage) and msg.powerupType == 'aeroCock':
            if self._dead: return True
            if self.pickUpPowerupCallback is not None: self.pickUpPowerupCallback(self)
            t = self.node.position
            AeroCock(position=(t[0], t[1]+1.2, t[2]), velocity=(0,0,0), owner=self.node).autoRetain()
            self.node.handleMessage("flash")
            if msg.sourceNode.exists():
                msg.sourceNode.handleMessage(bs.PowerupAcceptMessage())
            return True
        else: handleMessageOld(self, msg=msg)
    bsSpaz.Spaz.handleMessage = handleMessage

run(install)
    
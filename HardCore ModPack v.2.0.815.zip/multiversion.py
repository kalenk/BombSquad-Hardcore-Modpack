# -*- coding: utf-8 -*-
import bs
import shutil, os
import time
import bsInternal
import json
import sys

env = bs.getEnvironment()
temp = os.path.join(env['userScriptsDirectory'], 'settings.json')

gSettingsEnabled = (hasattr(bs, "get_setting") and hasattr(bs, "set_setting"))
gAndroid = env['platform'] == 'android'
if gAndroid: gInstallPath = '/data/data/net.froemling.bombsquad/files/bombsquad_files/data/scripts'
else: gInstallPath = (os.path.sep).join([env['userScriptsDirectory'], 'sys', str(env["version"])])
gLang = bs.getLanguage()

path = (os.path.sep).join([env['userScriptsDirectory'], 'hardcore', '.data'])

installedVersion = 0
installingVersion = 20815
messages = {}
message_num = 0

def get_version():
    global installedVersion
    if gSettingsEnabled: installedVersion = bs.get_setting("installed_version", 0)
    else: installedVersion = st.get_setting("installed_version", 0)
    return installedVersion
    
def set_version(version=0):
    global installedVersion
    if gSettingsEnabled: 
        try: bs.set_setting("installed_version", version)
        except Exception: pass
    elif st is not None and hasattr(st, 'is_closed') and not st.is_closed():
        st.set_setting("installed_version", version)
    installedVersion = version

try: from bs import Settings, _gData, force_save
except Exception:
    _gData={"admins":[], "vips":[], "prefixes":{}, "banned": [], \
        "skins": {}, "lobby_connect_menu": False, "show_game_name": True, \
        "admins_prefix": True, "timer_the_disappearance_of_the_effect": True, \
        "powerup_lighting": True, "timer_the_disappearance_of_the_powerup": True, \
        "timer_before_the_bomb_explode": True, "chat_commands_enabled": True, \
        "standart_powerups": False, "auto-update": False, "internet_tab_search_text":"", \
        "in_menu_author_name": True, "party_search_log": False, "powerups": [], \
        "installed_version": get_version()}
    force_save=["admins", "vips", "banned", "prefixes", "powerups", "skins"]
    class Settings(object):
        def __init__(self, path=None):
            self.path = path if path is not None and os.path.exists(path) else env['configFilePath']
            self.closed = False
            self.load()
            self.mtime = os.path.getmtime(self.path)
        def load(self):
            if not self.closed:
                if not os.path.exists(self.path): raise Exception("Settings file path is not exists; cann\'t update settings data")
                m_time = os.path.getmtime(self.path)
                if hasattr(self, "mtime") and m_time == self.mtime: return
                start_time = time.time()
                try: self.data = json.load(open(self.path))
                except Exception as E:
                    self.data = _gData
                    print("Error loading settings json-file: "+str(E))
                print("loaded in "+str(time.time() - start_time))
            else: raise Exception("Settings were closed")
        def save(self, values=[]):
            if not self.closed:
                start_time = time.time()
                self.load()
                for i in values: self.data.update(i)
                try: json.dump(self.data, open(self.path, "w+"), indent=4, sort_keys=True)
                except Exception as E: print(str(E))
                self.mtime = os.path.getmtime(self.path)
                print("saved in "+str(time.time()-start_time))
                return self.data
            else: raise Exception("Settings were closed")
        def get_setting(self, name="test", default_value=None):
            if not self.closed:
                self.load()
                return self.data.get(name, default_value)
            else: raise Exception("Settings were closed")
        def set_setting(self, name="test", value=True):
            if not self.closed:
                if not hasattr(self, "call"): values = [{name: value}]
                else:
                    values = self.call[0]
                    values.append({name: value})
                if name not in force_save: self.call = [values, bs.Timer(750, bs.Call(self.save, values), timeType="real")]
                else: self.save(values=[{name: value}])
            else: raise Exception("Settings were closed")
        def get_settings(self):
            if not self.closed: return self.data
            else: raise Exception("Settings were closed")
        def close(self):
            if self.closed: return
            if hasattr(self, "data"): del self.data
            if hasattr(self, "path"): del self.path
        def is_closed(self):
            return self.closed

if not gSettingsEnabled: st = Settings(path=temp)

def add_message(msg='', color=(0,1,0)):
    global messages
    global message_num
    messages.update({message_num: {msg: color}})
    message_num += 1

def messages_sendall(msg=''):
    global messages
    global message_num
    for i in range(message_num): 
        try: bs.realTimer(100*i, bs.Call(bs.screenMessage, messages[i].keys()[0], messages[i].values()[0]))
        except Exception: pass
    messages = {}
    message_num = 0
    
installedVersion = get_version()
texts = {"Russian": {
    "installedText": "Успешно установлено за {} {}", "plsWaitText": "Пожалуйста, подождите...", \
    "thanksForInstallText": "Спасибо за установку!", "unsuccessfullInstall": "Неудачная установка. Попробуй снова", \
    "automaticQuit": "Автоматический выход через {}"},
    "English": {"installedText": "Successfully installed in {} {}", "plsWaitText": "Please, wait...", \
    "thanksForInstallText": "Thanks for installing!", "seconds": "seconds", \
    "unsuccessfullInstall": "Unsucessfull install. Try again", "automaticQuit": "Automatic quit in {}"}}

texts = texts.get(gLang, texts.get("English", {}))
if gLang == 'Russian':
    def get_article(num=0):
        num = int(str(num)[-1])
        if num == 0 or num in range(5, 10): return "секунд"
        elif num == 1: return "секунду"
        elif num in range(2, 5): return "секунды" 
else: 
    get_article = lambda num : texts.get("seconds", "seconds")

def get_string(val="test", default_val=None):
    if default_val is None: default_val = val
    return str(bs.Lstr(value=texts.get(val, default_val)).evaluate().encode('utf-8'))

def dir_is_empty(path=None):
    if path is not None and os.path.exists(path):
        is_dir = os.path.isdir(path)
        if not is_dir: return -1
        elif len(os.listdir(path)) == 0: return 1
        else: return 0
    else: return -2

def delpath(path=None):
    val = dir_is_empty(path)
    if val > -2:
        if val: os.rmdir(path)
        elif val == 0: shutil.rmtree(path)
        elif val == -1: os.remove(path)

def replace_scripts(path=None, temp_path=None, installing_dir=None):
    if path is None or (path is not None and not os.path.exists(path)): return False
    try:
        if gAndroid:
            delpath(temp_path) 
            shutil.copytree(path, temp_path)
            shutil.move(temp_path, installing_dir)
            delpath(temp_path)
        else:
            shutil.copytree(path, installing_dir)
        return True
    except Exception as E: 
        add_message(str(E))
        return False

def quit_with_message(seconds=3):
    for i in range(seconds+1): bs.realTimer(1000*i+1000, bs.Call(bs.screenMessage, get_string("automaticQuit").format(str(seconds-i)), (1,1,0)))
    bs.realTimer(seconds*1000+1000, bs.Call(sys.exit, 1))

def install():
    global timer
    timer = None   
    start_time = time.time()
    if installedVersion < installingVersion: 
        delpath(gInstallPath)
        result = replace_scripts(path=path, temp_path=gInstallPath+"_temp", installing_dir=gInstallPath)
        if result:
            end_time = int(time.time()-start_time)
            try: set_version(installingVersion)
            except: pass
            add_message(get_string("installedText").format(str(end_time), get_article(end_time)), color=(0,1,0))
            add_message(get_string("thanksForInstallText"), color=(0,1,0))
            add_message(bs.Lstr(resource='settingsWindowAdvanced.mustRestartText'), color=(1, 1, 0))
            if not gSettingsEnabled: 
                try: st.close()
                except: pass
            quit_with_message()
        else: add_message(get_string("unsuccessfullInstall"), color=(1,0,0))
    if 'android' in env['userAgentString'] and hasattr(bs, 'androidRefreshFiles'): bs.androidRefreshFiles()
    messages_sendall()
       
def run_with_fade():
    if installingVersion > installedVersion: 
        bs.screenMessage(get_string("plsWaitText"), color=(1, 1, 0))
        bs.realTimer(500, bs.Call(install))

timer = None  
def main():
    global timer
    b = bsInternal._getForegroundHostActivity()
    if b is not None: 
        if not bsInternal._havePermission("storage"):
            timer = bs.realTimer(2500, bs.Call(main))
            bs.playSound(bs.getSound('error'))
            bs.screenMessage(bs.Lstr(resource='storagePermissionAccessText'), color=(1, 0, 0))
            bsInternal._requestPermission("storage")
        else: timer = bs.realTimer(500, bs.Call(run_with_fade))
    else: timer = bs.realTimer(500, bs.Call(main))

try: version_int = int(env['version'].replace(".", ""))
except ValueError: version_int = 14150
if (__name__ == "__main__" and version_int in range(14150, 15000)) or (installedVersion < installingVersion): main()
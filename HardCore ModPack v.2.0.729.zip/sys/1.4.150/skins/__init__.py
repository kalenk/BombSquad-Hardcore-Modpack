from .setup import *
from .characters import *
from .prefix import PermissionEffect
import bs
import bsInternal
import __0 as prefix_codes0
import __1 as prefix_codes1
import bsUtils

def __init__(self, color=(1, 1, 1), highlight=(0.5, 0.5, 0.5), character="Spaz", player=None, powerupsExpire=True):
    a = bsInternal._getForegroundHostActivity()
    if player is None: player = bs.Player(None)
    if a is not None:
        with bs.Context(a):
            account = player.getInputDevice()._getAccountName(True)
            skin_is = skins.get(account)
            if skin_is is not None:
                skin_name = get_unformat_skin_name(skin_is)
                if skin_name is not None:
                    if skin_name in bsSpaz.appearances.keys(): character = skin_name
                    else: bsInternal._log("skin name isn\'t in appearances/\nsee more in prefix.__init__(), bsSpaz.get_unformat_skin_name(), chatCmd.skin()")
    Spaz.__init__(self, color=color, highlight=highlight, character=character, sourcePlayer=player,
                  startInvincible=True, powerupsExpire=powerupsExpire)
    self.lastPlayerAttackedBy = None
    self.lastAttackedTime = 0
    self.lastAttackedType = None
    self.heldCount = 0
    self.lastPlayerHeldBy = None
    self._player = player
    if skin_is not in ["invincible"]:
        vips = bs.get_setting(name="vips")
        admins = bs.get_setting(name="admins")
        host = self._player.getInputDevice().getClientID() == -1
        opt = [[prefix_codes0.prefix, prefix_codes0.code], [prefix_codes1.prefix, prefix_codes1.code]]
        profiles = self._player.getInputDevice()._getPlayerProfiles()
        if profiles == [] or profiles == {}: profiles = bs.getConfig()['Player Profiles']
        if bs.get_setting("prefixes", {}).get(account) is not None:
            prefix_info = bs.get_setting("prefixes")[account]
            if isinstance(prefix_info, list): prefix_info = {prefix_info[0]: prefix_info[1]}
            PermissionEffect(owner=self.node, prefix=prefix_info.values()[0],
                             prefixAnim={0: self.node.color, 5000: self.node.highlight, 10000: self.node.color},
                             type=prefix_info.keys()[0])
        elif bs.get_setting(name="admins_prefix", default_value=True):
            if host or (account in admins):
                PermissionEffect(owner=self.node, prefix='Admin',
                                 prefixAnim={0: (0, 1, 1), 2500: (1, 0, 1), 5000: (0, 1, 1)})
            elif (account in vips):
                PermissionEffect(owner=self.node, prefix='VIP',
                                 prefixAnim={0: (1, 1, 0), 2500: (1, 0.75, 0), 5000: (1, 1, 0)})
        else:
            for r in opt:
                for i in range(len(r[0])):
                    if r[0][i] in profiles: PermissionEffect(owner=self.node, prefix=r[1][i],
                                                             prefixAnim={0: self.node.color, 5000: self.node.highlight,
                                                                         10000: self.node.color})
    if player.exists():
        playerNode = bs.getActivity()._getPlayerNode(player)
        self.node.connectAttr('torsoPosition', playerNode, 'position')
        check_skin(account, self.node)

bsSpaz.PlayerSpaz.__init__ = __init__

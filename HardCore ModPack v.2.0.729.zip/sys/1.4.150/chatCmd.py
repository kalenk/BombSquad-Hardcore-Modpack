﻿# -*- coding: utf-8 -*-
import bs
import bsInternal
import bsPowerup
import bsUtils
import bsSpaz
from bsSpaz import *
import bsUI
import time
import random
from skins import PermissionEffect
import skins
import advanced

bsUtils._havePro = bsUtils._haveProOptions = lambda : True

def send_message(msg):
    if len(bsInternal._getGameRoster()) == 0:
        if bsUI.gPartyWindow is not None and bsUI.gPartyWindow() is not None:
            with bs.Context("UI"):
                bsUI.gPartyWindow()._addMsg(msg=msg, color=(1, 1, 1))
    else: bsInternal._chatMessage(msg)

maps={"Doom Shroom":(0.82, 1.10, 1.15), "Hockey Stadium":(1.2,1.3,1.33), \
    "Football Stadium":(1.3, 1.2, 1.0), "Big G":(1.1, 1.2, 1.3), \
    "Roundabout":(1.0, 1.05, 1.1), "Monkey Face":(1.1, 1.2, 1.2), \
    "Bridgit":(1.1, 1.2, 1.3), "Zigzag":(1.0, 1.15, 1.15), \
    "The Pad":(1.1, 1.1, 1.0), "Lake Frigid":(1, 1, 1), \
    "Tip Top":(0.8, 0.9, 1.3), "Crag Castle":(1.15, 1.05, 0.75), \
    "Tower D":(1.15, 1.11, 1.03), "Happy Thoughts":(1.3, 1.23, 1.0), \
    "Step Right Up":(1.2, 1.1, 1.0), "Courtyard":(1.2, 1.17, 1.1), \
    "Rampage":(1.2, 1.1, 0.97)}

commands=['/help','/summon','/s','/list', \
    '/l', '/punch','/ph', '/hp','/hitpoints',
    '/time','/timeset',\
    '/admin', '/ban','/kick', \
    '/prefix', '/vip', '/skin','/end']

def get_account_string(arg):
    if is_num(arg):
        if len(bsInternal._getForegroundHostActivity().players) > int(arg):
            return bsInternal._getForegroundHostActivity().players[int(arg)].getInputDevice()._getAccountName(True)
    elif is_account(arg): return arg
    elif isinstance(arg, bs.Player):
        if arg.exists(): return arg.getInputDevice()._getAccountName(True)
    return None

def is_num(num=""):
    if isinstance(num, str):
        if num.startswith("-") and len(num) > 1: num=num[1:]
        return True if num.isdigit() else False
    elif isinstance(num, int): return True

def is_account(account):
    if isinstance(account, str):
        try: account = account.decode("utf-8")
        except: pass
    if isinstance(account, unicode):
        for icon in ['googlePlusLogo', 'gameCenterLogo', 'gameCircleLogo', \
            'ouyaLogo', 'localAccount', 'alibabaLogo', \
            'oculusLogo', 'nvidiaLogo']:
            if bs.getSpecialChar(icon) in account: return True
    return False

def get_normal_tint():
    a=bsInternal._getForegroundHostActivity()
    if a is not None:
        import bsMainMenu
        if isinstance(bsInternal._getForegroundHostActivity(), bsMainMenu.MainMenuActivity): name = "The Pad"
        else: name = a.getMap().name
        if name is not None:
            if name in maps:
                for i in maps:
                    if i == name: globals().update({"tint_real": maps[i]})
            else: bsInternal._log("error map name: "+name+", see more in chatCmd.get_normal_tint()")
    return globals().get("tint_real", None)

def get_motion():
    a=bsInternal._getForegroundHostActivity()
    motion = False
    if a is not None:
        if "settings" in dir(a): motion = a.settings.get("Epic Mode", 0)
        else: motion = a._inheritsSlowMotion if globals().get("motion_normal", None) is None else globals().get("motion_normal", None)
    return motion

globals()["lr"] = {"admins": [], "vips":[], "prefixes": {}, "banned": []}
for i in globals()["lr"]:
    globals()[i] = bs.get_setting(i, globals()["lr"].get(i))
globals().update({"tint_normal": get_normal_tint()})
globals().update({"motion_normal": get_motion()})

def dayCycle():
    if bsInternal._getForegroundHostActivity() is not None:
        tint = get_tint()
        anim={0: tint, 7500:(1.25, 1.21, 1.075),
            30000: (1.25, 1.21, 1.075), 57500: (1.1, 0.86, 0.74),
            67500: (1.1, 0.86, 0.74), 90000: (0, 0.27, 0.51),
            120000: (0, 0.27, 0.51), 142500: (1.3, 1.06, 1.02),
            157500: (1.3, 1.06, 1.02), 180000: (1.3, 1.25, 1.2),
            195500: (1.3, 1.25, 1.2), 220000: tint}
        bsUtils.animateArray(bs.getSharedObject("globals"), "tint", 3, anim, loop=True)

class ChatOptions(object):
    def __init__(self):
        self.is_vip = False
        self.is_admin = False
        self.is_host = False
        self.server_search = False
        self._bots = None
        self.time={"normal":None, "sunrise": (1.3, 1.06, 1.02), "day": (1.3, 1.25, 1.2), "noon": (1.25, 1.21, 1.075), "sunset": (1.1, 0.86, 0.74), "night":(0, 0.27, 0.51)}

    def add_admin(self, admin=False, account=None):
        if account is not None:
            setting = "vips" if not admin else "admins"
            data = bs.get_setting(setting, [])
            if account not in data: data.append(account)
            bs.set_setting(setting, data)
            globals()[setting] = data

    def update(self):
        if bsInternal._getForegroundHostActivity() is not None:
            banned = globals().get("banned", [])
            for i in bsInternal._getGameRoster():
                account = i['displayString'].decode("utf-8")
                id = i['clientID']
                if len(banned) > 0:
                    if account in banned:
                        msg="" if banned.get(account) == "auto" else ("по причине: "+ banned.get(account))
                        bs.screenMessage(message=str(account)+" изгнан "+msg, color=(1,1,0), transient=True, clients=[id])
                        bsInternal._disconnectClient(id, banTime=300)
            
    def check_player(self, nickname):
        try: nickname=nickname.encode("utf-8")
        except UnicodeDecodeError: nickname=str(nickname)
        a = bsInternal._getForegroundHostActivity()
        host = bsInternal._getAccountDisplayString(True)
        if host not in globals()["admins"]: globals()["admins"].append(host)
        for i in ["admins", "vips"]:
            for c in bs.get_setting(i, [host]):
                if c not in globals()[i]: globals()[i].append(c)
        self.player=None
        self.is_vip, self.is_admin, self.is_host = False, False, False
        if a is not None:
            if len(bsInternal._getGameRoster()) > 0:
                players=[i["players"][0] for i in bsInternal._getGameRoster() if len(i["players"]) > 0]
                for i in bsInternal._getGameRoster():
                    account=i["displayString"].decode("utf-8")
                    profile_name=i["players"][0]["name"] if len(i["players"]) > 0 else i["displayString"]
                    if nickname == profile_name:
                        if account in globals()["vips"]: self.is_vip=True
                        elif account in globals()["admins"]: self.is_vip, self.is_admin = True, True
                        if account == host: self.is_host=True
                        self.player=[q for q in a.players if q.getID() == i["clientID"]]
                        self.player=self.player[0] if len(self.player) > 0 else None
            else:
                self.is_admin=True
                self.is_vip=True
                self.is_host=True
                self.player=a.players[0] if len(a.players) > 0 else None

    def get_player_position(self, command, arg):
        if self.player is not None:
            if command in ["tp", "teleport", "s", "summon"]:
                if ('~' in arg) or ('^' in arg):
                    if command in ["s", "summon"]: mult=4
                    elif command in ["tp", "teleport"]: mult=3
                    if len(arg) > mult:
                        for i in range(3):
                            if arg[mult-2+i] in ["~", "^"]:
                                if self.player.exists() and self.player.isAlive(): arg[mult-2+i]=self.player.actor.node.position[i]
        return arg

    def opt(self, nickname=" ", msg=" "):
        self.check_player(nickname=nickname)
        msg=msg.lower().replace("/", "")
        arg=msg.split(" ")[1:] if len(msg.split(" ")) > 1 else []
        command=msg.split(" ")[0]
        a=bsInternal._getForegroundHostActivity()
        if a is not None:
            with bs.Context(a):
                arg=self.get_player_position(command=command, arg=arg)
                if command in ["l","list"] and self.is_vip:
                    if len(bsInternal._getGameRoster()) > 0:
                        for i in bsInternal._getGameRoster():
                            ac=[[r["nameFull"] for r in i["players"]], [d["id"] for d in i["players"]]]
                            players_string=(", ").join(ac[0])
                            player_nums=(", ").join([str(i) for i in range(len(ac[1]))])
                            bsInternal._chatMessage(i["displayString"] +" : "+player_nums+" : "+players_string)
                    else:
                        pl = bsInternal._getForegroundHostActivity().players
                        if len(pl) > 0:
                            bsInternal._chatMessage(((", ").join([i.getInputDevice().getPlayer().getName(True) for i in pl]) + " : " + (", ").join([str(r) for r in range(len(pl))])))
                        else: send_message("-1")

                elif command in ['timeset', 'time'] and self.is_vip:
                    if len(arg) > 0:
                        tint = get_tint()
                        self.time.update({"normal": get_normal_tint()})
                        for i in self.time:
                            if arg[0] == i:
                                tint = self.time[i]
                                bs.getSharedObject("globals").tint = self.time[i]
                        if arg[0] == 'cycle':
                            tint = get_normal_tint()
                            bs.getSharedObject('globals').tint = tint
                        set_tint(tint=tint)
                    else:
                        bsInternal._chatMessage('time [normal|sunrise|day|noon|sunset|night|cycle]')
                        bsInternal._chatMessage('timeset cycle - дневной цикл(плавная смена времени)')
                        bsInternal._chatMessage('timeset noon - середина дня')
                        bsInternal._chatMessage('timeset sunset - закат')
    
                elif command in ['summon','s'] and self.is_admin:
                    if len(arg) > 0:
                        if arg[0] in ['bomb','b']:
                            bombs = ['ice', 'impact', 'landMine', 'normal', 'sticky', 'tnt', 'firework', 'killLaKill', 'qq', 'tp', 'poison', 'ball']
                            if len(arg) > 1:
                                spawn={"bombType":"normal", "pos":[0,5,0], "count":1}
                                for i in range(len(spawn)):
                                    if len(arg) > i+1:
                                        name=spawn.keys()[i]
                                        if name == "bombType": spawn.update({name:arg[i+1]})
                                        elif name == "count":
                                            if len(arg) > i+4:
                                                if is_num(arg[i+4]):
                                                    if int(arg[i+4]) > 0: spawn.update({name:int(arg[i+4])})
                                        else:
                                            for k in range(3):
                                                if len(arg) > i+k:
                                                    if is_num(arg[i+k]): spawn["pos"][k] = float(arg[i+k])
                                if spawn["bombType"] in bombs:
                                    for i in range(spawn["count"]):
                                        if i < 30:
                                            if self.player is not None:
                                                if self.player.exists(): bs.Bomb(position=tuple(spawn["pos"]), bombType=spawn["bombType"], owner=self.player.actor.node).autoRetain()
                                                else: bs.Bomb(position=tuple(spawn["pos"]), bombType=spawn["bombType"]).autoRetain()
                                            else: bs.Bomb(position=tuple(spawn["pos"]), bombType=spawn["bombType"]).autoRetain()
                            else:
                                for i in range(int(len(bombs) / 4)):
                                    bmstring = ""
                                    for r in range(4):
                                        if len(bombs) + 1 > (i*4+r): bmstring += (", "+bombs[i*4+r]) if r > 0 else bombs[i*4+r]
                                    send_message(bmstring)
                                send_message("s bomb [название] [позиция(3 числа)] [кол-во]")
                                send_message("s bomb normal 0 5 0 1")
                        elif arg[0] in ['bot']:
                            import inspect
                            bots=[i for i in dir(bsSpaz) if inspect.isclass(eval("bsSpaz."+i)) and issubclass(eval("bsSpaz."+i), bsSpaz.SpazBot)]
                            if len(arg) > 1:
                                spawn = {"botType": "BomberBot", "pos": [0, 5, 0], "count": 1}
                                for i in range(len(spawn)):
                                    name=spawn.keys()[i]
                                    if name == "botType":
                                        if len(arg) > 1:
                                            if not (arg[i+1]+" ").isspace(): spawn.update({name:arg[i+1]})
                                    elif name == "count":
                                        if len(arg) > i+4:
                                            if is_num(arg[i+4]):
                                                if int(arg[i+4]) > 0: spawn.update({name:int(arg[i+4])})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k:
                                                if is_num(arg[i+k]): spawn["pos"][k] = float(arg[i+k])
                                bot=eval([("bsSpaz."+i) for i in bots if i.lower() == spawn["botType"]][0] if len([i for i in bots if i.lower() == spawn["botType"]]) > 0 else "bsSpaz.BomberBot")
                                self._bots = bs.BotSet() if self._bots is None else self._bots
                                for i in range(spawn["count"]):
                                    if i < 31: self._bots.spawnBot(bot, pos=tuple(spawn["pos"]), spawnTime=1, onSpawnCall=self._on_spawn)
                            else:
                                for i in range(int(len(bots) / 4)):
                                    skstring = ""
                                    for r in range(4):
                                        if len(bots) + 1 > (i*4+r): skstring += (", "+bots[i*4+r]) if r > 0 else bots[i*4+r]
                                    send_message(skstring)
                                send_message("s bot [название] [позиция(3 числа)] [кол-во]")
                                send_message("s bot BomberBot 0 5 0 1")
                        elif arg[0] in ['flag','f']:
                            if len(arg) > 1:
                                spawn = {"time_out":20, "color":[1,1,0], "pos":[0, 5, 0], "count":1}
                                for i in range(len(spawn)):
                                    name=spawn.keys()[i]
                                    if name == "color":
                                        for k in range(3):
                                            if len(arg) > i+k+6:
                                                if is_num(arg[i+k+6]): spawn["color"][k] = float(arg[i+k+6])
                                    elif name == "count":
                                        if len(arg) > i+3:
                                            if is_num(arg[i+3]):
                                                if int(arg[i+3]) > 0: spawn.update({name:int(arg[i+3])})
                                    elif name == "time_out":
                                        if len(arg) > i+3:
                                            if is_num(arg[i+3]):
                                                if int(arg[i+3]) > 0: spawn.update({name:int(arg[i+3])})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k-2:
                                                if is_num(arg[i+k-2]): spawn["pos"][k] = float(arg[i+k-2])
                                for i in range(spawn["count"]):
                                    if i < 31: bs.Flag(position=tuple(spawn["pos"]), droppedTimeout=spawn["time_out"], color=spawn["color"]).autoRetain()
                            else:
                                send_message("s flag [название] [позиция(3 числа)] [кол-во]")
                                send_message("s bot BomberBot 0 5 0 1")
                                send_message("s bot [название] [позиция(3 числа)] [кол-во]")
                        elif arg[0] in ['powerup','p']:
                            powerups=[i[0] for i in list(bsPowerup.getDefaultPowerupDistribution(True))]
                            if len(arg) > 1:
                                spawn = {"powerupType": "punch", "pos": [0, 5, 0], "count": 1}
                                for i in range(len(spawn)):
                                    name = spawn.keys()[i]
                                    if name == "powerupType":
                                        if len(arg) > i-1:
                                            if not (arg[i-1] + " ").isspace() and arg[i-1] in [k.lower() for k in powerups]:
                                                spawn.update({name: [l for l in powerups if arg[i-1] == l.lower()][0]})
                                    elif name == "count":
                                        if len(arg) > i+5:
                                            if is_num(arg[i+5]):
                                                if int(arg[i+5]) > 0: spawn.update({name: int(arg[i+5])})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k+1:
                                                if is_num(arg[i+k+1]): spawn["pos"][k] = float(arg[i+k+1])
                                for i in range(spawn["count"]):
                                    if i < 31: bs.Powerup(position=tuple(spawn["pos"]),powerupType=spawn["powerupType"]).autoRetain()
                            else:
                                for i in range(int(len(powerups) / 4)):
                                    skstring = ""
                                    for r in range(4):
                                        if len(powerups) + 1 > (i*4+r): skstring += (", "+powerups[i*4+r]) if r > 0 else powerups[i*4+r]
                                    send_message(skstring)
                                send_message("s p [название] [позиция(3 числа)] [кол-во]")
                        elif arg[0] in ['box']:
                            if len(arg) > 1:
                                spawn = {"boxType": "small", "pos": [0, 5, 0], "count": 1, "owner":None}
                                for i in range(len(spawn)):
                                    name = spawn.keys()[i]
                                    if name == "boxType":
                                        if len(arg) > i+1:
                                            if not (arg[i+1] + " ").isspace() and arg[i+1] in ["small","s","big","b"]: spawn.update({name: arg[i+1]})
                                    elif name == "count":
                                        if len(arg) > i+4:
                                            if is_num(arg[i+4]):
                                                if int(arg[i+4]) > 0: spawn.update({name: int(arg[i+4])})
                                    elif name == "owner":
                                        if len(arg) > i+3:
                                            if is_num(arg[i+3]): spawn.update({name: bsInternal._getForegroundHostActivity().players[int(arg[i+3])].actor.node if len(bsInternal._getForegroundHostActivity().players) > int(arg[i+3]) else None})
                                    else:
                                        for k in range(3):
                                            if len(arg) > i+k-1:
                                                if is_num(arg[i+k-1]): spawn["pos"][k] = float(arg[i+k-1])
                                for i in range(spawn["count"]):
                                    if i < 31: Box(pos=tuple(spawn["pos"]), scale=1 if spawn["boxType"] in ["s","small"] else 1.35, owner=spawn["owner"]).autoRetain()
                        else:
                            for i in ["summon [bomb|powerup|bot|box|flag]", "bomb - вызвать бомбу.", "powerup - вызвать усилитель.", "bot - вызвать бота.", "box - вызвать коробку."]: send_message(i)

                elif command in ['skin'] and self.is_vip:
                    skin_names = [skins.get_format_skin_name(i) for i in bsSpaz.appearances.keys()]+["tnt", "shard", "invincible"]
                    if len(arg) > 0:
                        if len(arg) < 2: arg.append(self.player)
                        if arg[0] in skin_names:
                            if isinstance(arg[1], bs.Player): skins.change_skin(skin=arg[0], players=[arg[1]])
                            elif isinstance(arg[1], str):
                                if arg[1] == "all": skins.change_skin(skin=arg[0], players=[i for i in range(len(bsInternal._getForegroundHostActivity().players)-1)])
                                elif arg[1].isdigit(): skins.change_skin(skin=arg[0], players=[int(arg[1])])
                        elif arg[0] == "delete":
                            if isinstance(arg[1], bs.Player): skins.delete_skin(arg[1])
                            elif isinstance(arg[1], str):
                                if arg[1] == "all":
                                    if len(bsInternal._getForegroundHostActivity().players) > 0:
                                        for i in bsInternal._getForegroundHostActivity().players: skins.delete_skin(i)
                                elif arg[1].isdigit(): skins.delete_skin(arg[1])
                    else:
                        for i in range(int(len(skin_names)/4)):
                            skstring=""
                            for r in range(4):
                                if len(skin_names)+1 > (i*4+r): skstring+=(", "+skin_names[i*4+r]) if r > 0 else skin_names[i*4+r]
                            send_message(skstring)
                        send_message("skin [название] [номер игрока]")
                        send_message("skin bunny 0")
                        send_message("skin pixie")

                elif command in ['ph','punch','hp','hitpoints'] and self.is_admin:
                    if len(arg) > 0:
                        player = None
                        if len(bsInternal._getForegroundHostActivity().players) > 0:
                            if len(arg) < 2: player = [self.player]
                            else:
                                if arg[1].isdigit():
                                    player = [bsInternal._getForegroundHostActivity().players[int(arg[1])]] if len(bsInternal._getForegroundHostActivity().players) > int(arg[1]) else None
                                elif arg[1] == "all":
                                    player = bsInternal._getForegroundHostActivity().players
                            if player is not None:
                                if arg[0].isdigit():
                                    arg[0] = int(arg[0])
                                    if command in ["punch", "ph"]:
                                        if arg[0] > 10: arg[0] = 10
                                    else:
                                        if arg[0] < 1: arg[0] = 1
                                    for i in player:
                                        if i.exists and i.isAlive:
                                            if command in ["punch", "ph"]: i.actor._punchPowerScale = arg[0]
                                            else: i.actor.hitPointsMax, i.actor.hitPoints = arg[0], arg[0]
    
                elif command in ['admin','vip'] and self.is_admin:
                    if len(arg) > 0:
                        account = get_account_string(arg[0])
                        if account is not None:
                            self.add_admin(True if command == "admin" else False, account)

                elif command in ['prefix'] and self.is_admin:
                    if len(arg) > 0:
                        if arg[0] == "delete":
                            account = get_account_string(arg[1])
                            if account is not None and account in prefixes:
                                prefixes.pop(account)
                                bs.set_setting("prefixes", prefixes)
                        else:
                            type = "spark"
                            prefix = "prefix"
                            account = get_account_string(arg[0])
                            if len(arg) > 1: type = arg[1]
                            if len(arg) > 2: prefix = (" ").join(arg[2:])
                            if account is not None:
                                prefixes.update({account: {type: prefix}})
                                bs.set_setting("prefixes", prefixes)

                elif command in ['kick'] and self.is_vip:
                    if len(arg) > 0:
                        account = get_account_string(arg[0])
                        id = None
                        if account is not None:
                            for i in bsInternal._getGameRoster():
                                if i["displayString"] == account:
                                    id = i["clientID"]
                                    break
                        if id is not None:
                            bsInternal._disconnectClient(id, 300)
    
                elif command in ['ban'] and self.is_admin:
                    if len(arg) > 0:
                        account = get_account_string(arg[0])
                        if account is not None:
                            if account not in banned: banned.append(account)
                            bs.set_setting("banned", banned)
                    
                elif command in ['end'] and self.is_admin:
                    a = bsInternal._getForegroundHostActivity()
                    if "endGame" in dir(a): a.endGame()

                elif command in bs.get_settings() and self.is_admin:
                    a = bs.get_settings()
                    a = {i: a[i] for i in a if isinstance(a[i], bool)}
                    if command in a: bs.set_setting(command, not bool(a[command]))

    def _on_spawn(self, bot):
        bot.targetPointDefault = bs.Vector(0,0,0)

c = ChatOptions()
def cmd(msg):
    if bsInternal._getForegroundHostActivity() is not None:
        n = msg.split(': ')
        c.opt(n[0].split("/")[0],n[1])

def update():
    c.update()

def get_tint():
    return globals().get("tint_normal") if globals().get("tint_normal") is not None else get_normal_tint()

def set_tint(tint):
    if isinstance(tint, tuple) and len(tint) == 3: globals().update({"tint_normal": tint})

def set_motion(motion):
    if isinstance(motion, bool): globals().update({"motion_normal": motion})

class Box(bs.Actor):
    def __init__(self, pos=(0, 5, 0), scale=1.35, owner=None):
        self.owner = owner
        bs.Actor.__init__(self)
        box_material = bs.Material()
        box_material.addActions(
            conditions=((('weAreYoungerThan', 0),'or',('theyAreYoungerThan', 0)),
            'and', ('theyHaveMaterial', bs.getSharedObject('objectMaterial'))),
            actions=(('modifyNodeCollision', 'collide', True)))
        box_material.addActions(conditions=('theyHaveMaterial',
            bs.getSharedObject('pickupMaterial')),
            actions=(('modifyPartCollision', 'useNodeCollide', False)))
        box_material.addActions(actions=('modifyPartCollision','friction', 1000))
        self.node = bs.newNode('prop', delegate=self, attrs={
            'position': pos,
            'velocity': (0, 0, 0),
            'model': bs.getModel('tnt'),
            'modelScale': scale,
            'body': 'crate',
            'bodyScale': scale,
            'shadowSize': 0.26 * scale,
            'colorTexture': bs.getTexture(random.choice(["flagColor", "frameInset"])),
            'reflection': 'soft',
            'reflectionScale': [0.23],
            'materials': (bs.getSharedObject('footingMaterial'), bs.getSharedObject('objectMaterial'))})

    def getFactory(cls):
        return None

    def handleMessage(self, msg):
        self._handleMessageSanityCheck()
        if isinstance(msg, bs.PickedUpMessage):
            if self.owner is None:
                self.owner=msg.node
                self.node.handleMessage(ConnectToPlayerMessage(msg.node))
            else:
                self.owner=None
                self.node.connectAttr('position', self.node, 'position')
        elif isinstance(msg, ConnectToPlayerMessage):
            if msg.player is not None:
                if msg.player.exists():
                    self.owner=msg.player
                    self.owner.connectAttr('position', self.node, 'position')
        elif isinstance(msg, bs.OutOfBoundsMessage): self.node.delete()
        elif isinstance(msg, bs.DieMessage): self.node.delete()
        elif isinstance(msg, bs.HitMessage):
            self.node.handleMessage("impulse", msg.pos[0], msg.pos[1], msg.pos[2], msg.velocity[0], msg.velocity[1],
                msg.velocity[2], msg.magnitude * 0.2, msg.velocityMagnitude, msg.radius, 0,
                msg.forceDirection[0], msg.forceDirection[1], msg.forceDirection[2])
        else: bs.Actor.handleMessage(self, msg)

class ConnectToPlayerMessage(object):
    def __init__(self, player):
        self.player=player
